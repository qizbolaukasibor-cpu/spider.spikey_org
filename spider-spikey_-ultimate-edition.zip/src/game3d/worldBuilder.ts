import * as THREE from 'three';
import { CityCollider, SeasonTheme } from '../types/spider3d';
import { getSeasonPalette, ProceduralTextureSet } from './proceduralModels';

export interface WorldCollectible {
  id: string;
  mesh: THREE.Mesh;
  baseY: number;
  collected: boolean;
  kind: 'orb' | 'gem' | 'secret';
}

export interface CityEnemyDrone {
  id: string;
  group: THREE.Group;
  origin: THREE.Vector3;
  hp: number;
  maxHp: number;
  phaseOffset: number;
  koTimer: number;
  alive: boolean;
}

export interface CityVehicle3D {
  id: string;
  group: THREE.Group;
  axis: 'x' | 'z';
  dir: 1 | -1;
  laneCoord: number;
  speed: number;
  limit: number;
  wheels: THREE.Mesh[];
}

export interface BuiltWorld3D {
  worldGroup: THREE.Group;
  colliders: CityCollider[];
  raycastTargets: THREE.Object3D[];
  collectibles: WorldCollectible[];
  drones: CityEnemyDrone[];
  vehicles: CityVehicle3D[];
  seasonalDecorGroup: THREE.Group;
  cloudsGroup: THREE.Group;
  fireworksAnchors: THREE.Vector3[];
  secretZoneCenter: THREE.Vector3;
  bossArenaCenter: THREE.Vector3;
  groundYAt: (x: number, z: number) => number;
  applySeason: (season: SeasonTheme) => void;
  updateWorld: (elapsed: number, dt: number) => void;
  dispose: () => void;
}

export function buildCityWorld(
  textures: ProceduralTextureSet,
  initialSeason: SeasonTheme
): BuiltWorld3D {
  const worldGroup = new THREE.Group();
  const colliders: CityCollider[] = [];
  const raycastTargets: THREE.Object3D[] = [];
  const collectibles: WorldCollectible[] = [];
  const drones: CityEnemyDrone[] = [];
  const vehicles: CityVehicle3D[] = [];
  const disposableGeos: THREE.BufferGeometry[] = [];
  const disposableMats: THREE.Material[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    disposableGeos.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    disposableMats.push(m);
    return m;
  };

  const pal = getSeasonPalette(initialSeason);

  // Extended Horizon Ground (420m x 420m — outdoor never boxed in a void)
  const groundMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: pal.groundColor,
      map: textures.groundDetailMap,
      roughness: 0.88,
      metalness: 0.05,
    })
  );
  const groundMesh = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(420, 420)), groundMat);
  groundMesh.rotation.x = -Math.PI / 2;
  groundMesh.receiveShadow = true;
  worldGroup.add(groundMesh);
  raycastTargets.push(groundMesh);

  // Central Boulevard & Crossroad Asphalt Roads (+0.025 Y offset prevents Z-fighting)
  const roadMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#D4DCE8',
      map: textures.roadAsphaltMap,
      roughness: 0.94,
      metalness: 0.02,
    })
  );
  const roadNS = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(14, 240)), roadMat);
  roadNS.rotation.x = -Math.PI / 2;
  roadNS.position.y = 0.025;
  roadNS.receiveShadow = true;
  worldGroup.add(roadNS);

  const roadEW = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(240, 14)), roadMat);
  roadEW.rotation.x = -Math.PI / 2;
  roadEW.rotation.z = Math.PI / 2;
  roadEW.position.y = 0.032;
  roadEW.receiveShadow = true;
  worldGroup.add(roadEW);

  // Skyscraper Builder (Composite Multi-Tiered Group + Rooftop Props)
  const windowMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: textures.skyscraperWindowMap,
      roughness: 0.35,
      metalness: 0.45,
      emissive: '#0C4A6E',
      emissiveIntensity: 0.35,
    })
  );
  const concreteMat = trackMat(
    new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.78, metalness: 0.15 })
  );
  const roofTrimMat = trackMat(
    new THREE.MeshStandardMaterial({ color: '#E2E8F0', roughness: 0.5, metalness: 0.3 })
  );
  const beaconMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#F59E0B',
      emissive: '#F59E0B',
      emissiveIntensity: 1.2,
    })
  );

  const skyscraperSpecs = [
    // Frame the initial spawn vista down -Z avenue!
    { id: 'sky_1', x: -19, z: -26, w: 12, h: 36, d: 12 },
    { id: 'sky_2', x: 19, z: -28, w: 13, h: 42, d: 13 },
    { id: 'sky_3', x: -21, z: -56, w: 14, h: 48, d: 14 },
    { id: 'sky_4', x: 22, z: -58, w: 14, h: 34, d: 12 },
    { id: 'sky_5', x: -42, z: -18, w: 12, h: 28, d: 12 },
    { id: 'sky_6', x: 42, z: -20, w: 12, h: 32, d: 12 },
    { id: 'sky_7', x: -20, z: 22, w: 12, h: 26, d: 12 },
    { id: 'sky_8', x: 20, z: 24, w: 12, h: 30, d: 12 },
    { id: 'sky_9', x: 48, z: 24, w: 14, h: 38, d: 14 },
    { id: 'sky_10', x: -46, z: 26, w: 13, h: 24, d: 13 },
    { id: 'sky_11', x: 0, z: -78, w: 16, h: 54, d: 16 }, // Grand Central Spire visible from spawn!
  ];

  for (const b of skyscraperSpecs) {
    const grp = new THREE.Group();
    grp.position.set(b.x, 0, b.z);

    // Podium base
    const podium = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(b.w + 1.4, 3.2, b.d + 1.4)), concreteMat);
    podium.position.y = 1.6;
    podium.castShadow = true;
    podium.receiveShadow = true;
    grp.add(podium);

    // Main shaft
    const shaft = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(b.w, b.h - 3.2, b.d)), windowMat);
    shaft.position.y = 3.2 + (b.h - 3.2) / 2;
    shaft.castShadow = true;
    shaft.receiveShadow = true;
    grp.add(shaft);

    // Rooftop crown ledge & antenna
    const roofRim = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(b.w + 0.6, 0.8, b.d + 0.6)), roofTrimMat);
    roofRim.position.y = b.h - 0.4;
    grp.add(roofRim);

    const spire = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.18, 0.35, 6.5, 8)), concreteMat);
    spire.position.y = b.h + 3.25;
    grp.add(spire);

    const beacon = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.45, 8, 8)), beaconMat);
    beacon.position.y = b.h + 6.6;
    grp.add(beacon);

    worldGroup.add(grp);
    raycastTargets.push(shaft, podium, roofRim);
    colliders.push({
      id: b.id,
      x: b.x,
      y: 0,
      z: b.z,
      w: b.w,
      h: b.h,
      d: b.d,
      climbable: true,
      kind: 'building',
    });
  }

  // Residential Houses (East District)
  const houseWallMat = trackMat(new THREE.MeshStandardMaterial({ color: '#CBD5E1', roughness: 0.8 }));
  const roofPitchMat = trackMat(new THREE.MeshStandardMaterial({ color: '#B91C1C', roughness: 0.65 }));
  const houseSpots = [
    { x: 46, z: -48 },
    { x: 62, z: -48 },
    { x: 46, z: -64 },
    { x: 62, z: -64 },
  ];
  houseSpots.forEach((hs, idx) => {
    const hGrp = new THREE.Group();
    hGrp.position.set(hs.x, 0, hs.z);
    const body = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(8, 5, 7)), houseWallMat);
    body.position.y = 2.5;
    body.castShadow = true;
    body.receiveShadow = true;
    const roof = new THREE.Mesh(trackGeo(new THREE.ConeGeometry(6.2, 3.2, 4)), roofPitchMat);
    roof.rotation.y = Math.PI / 4;
    roof.position.y = 6.6;
    roof.castShadow = true;
    const chimney = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.9, 2.2, 0.9)), concreteMat);
    chimney.position.set(2.2, 6.8, 1.4);
    hGrp.add(body, roof, chimney);
    worldGroup.add(hGrp);
    raycastTargets.push(body, roof);
    colliders.push({
      id: `house_${idx}`,
      x: hs.x,
      y: 0,
      z: hs.z,
      w: 8,
      h: 5.2,
      d: 7,
      climbable: true,
      kind: 'house',
    });
  });

  // Elevated Suspension Arch Bridge spanning West Park -> Central District (clear of E-W traffic at z=0)
  const bridgeZ = 42;
  const bridgeDeckMat = trackMat(new THREE.MeshStandardMaterial({ color: '#475569', roughness: 0.7 }));
  const bridgeCableMat = trackMat(new THREE.MeshStandardMaterial({ color: '#F59E0B', metalness: 0.7, roughness: 0.25 }));
  const bridgeGrp = new THREE.Group();
  const bridgeDeck = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(34, 1.0, 9)), bridgeDeckMat);
  bridgeDeck.position.set(-48, 7.0, bridgeZ);
  bridgeDeck.castShadow = true;
  bridgeDeck.receiveShadow = true;
  bridgeGrp.add(bridgeDeck);

  // Ramps leading onto bridge from both ends
  const rampEast = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(16, 0.8, 9)), bridgeDeckMat);
  rampEast.position.set(-25, 3.5, bridgeZ);
  rampEast.rotation.z = -0.43;
  const rampWest = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(16, 0.8, 9)), bridgeDeckMat);
  rampWest.position.set(-71, 3.5, bridgeZ);
  rampWest.rotation.z = 0.43;
  bridgeGrp.add(rampEast, rampWest);

  // Bridge Pylons & Suspension Arches
  for (const px of [-36, -60]) {
    const pylonL = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(1.4, 15, 1.4)), bridgeCableMat);
    pylonL.position.set(px, 7.5, bridgeZ - 4.2);
    const pylonR = pylonL.clone();
    pylonR.position.z = bridgeZ + 4.2;
    bridgeGrp.add(pylonL, pylonR);
    raycastTargets.push(pylonL, pylonR);
  }
  worldGroup.add(bridgeGrp);
  raycastTargets.push(bridgeDeck);
  colliders.push({
    id: 'bridge_deck',
    x: -48,
    y: 0,
    z: bridgeZ,
    w: 34,
    h: 7.5,
    d: 9,
    climbable: true,
    kind: 'bridge',
  });

  // Hidden Mountain Cavern & Secret Treasure Location (-72, -64)
  const secretZoneCenter = new THREE.Vector3(-72, 0, -64);
  const caveMat = trackMat(new THREE.MeshStandardMaterial({ color: '#1E293B', roughness: 0.9 }));
  const crystalMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#2DD4BF',
      emissive: '#14B8A6',
      emissiveIntensity: 1.0,
      roughness: 0.15,
      metalness: 0.4,
    })
  );
  const caveArchL = new THREE.Mesh(trackGeo(new THREE.DodecahedronGeometry(6.5, 0)), caveMat);
  caveArchL.position.set(-78, 4.5, -64);
  const caveArchR = new THREE.Mesh(trackGeo(new THREE.DodecahedronGeometry(6.5, 0)), caveMat);
  caveArchR.position.set(-66, 4.5, -64);
  const caveRoof = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(14, 3.5, 12)), caveMat);
  caveRoof.position.set(-72, 9.2, -64);
  const treasureCrystal = new THREE.Mesh(trackGeo(new THREE.OctahedronGeometry(1.8, 0)), crystalMat);
  treasureCrystal.position.set(-72, 2.2, -64);
  worldGroup.add(caveArchL, caveArchR, caveRoof, treasureCrystal);
  raycastTargets.push(caveRoof, caveArchL, caveArchR);

  // Dedicated Boss Arena at (0, 0, 108)
  const bossArenaCenter = new THREE.Vector3(0, 0, 108);
  const arenaFloorMat = trackMat(
    new THREE.MeshStandardMaterial({ color: '#111827', roughness: 0.45, metalness: 0.5 })
  );
  const arenaFloor = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(30, 32, 0.8, 36)), arenaFloorMat);
  arenaFloor.position.set(0, 0.4, 108);
  arenaFloor.receiveShadow = true;
  const arenaGlowRing = new THREE.Mesh(
    trackGeo(new THREE.RingGeometry(27.5, 29.2, 48)),
    trackMat(
      new THREE.MeshBasicMaterial({
        color: '#F5C451',
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.7,
      })
    )
  );
  arenaGlowRing.rotation.x = -Math.PI / 2;
  arenaGlowRing.position.set(0, 0.83, 108);
  worldGroup.add(arenaFloor, arenaGlowRing);
  raycastTargets.push(arenaFloor);

  // 8 Towering Boss Arena Grapple Pillars
  for (let i = 0; i < 8; i++) {
    const ang = (Math.PI * 2 * i) / 8;
    const px = Math.cos(ang) * 26;
    const pz = 108 + Math.sin(ang) * 26;
    const pillar = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(1.4, 1.8, 18, 10)), concreteMat);
    pillar.position.set(px, 9, pz);
    pillar.castShadow = true;
    const cap = new THREE.Mesh(trackGeo(new THREE.OctahedronGeometry(1.4, 0)), beaconMat);
    cap.position.set(px, 18.8, pz);
    worldGroup.add(pillar, cap);
    raycastTargets.push(pillar);
    colliders.push({
      id: `arena_pillar_${i}`,
      x: px,
      y: 0,
      z: pz,
      w: 3.0,
      h: 18,
      d: 3.0,
      climbable: true,
      kind: 'pillar',
    });
  }

  // Park Trees & Perimeter Mountains using InstancedMesh (>20 repeated instances!)
  const treeCount = 44;
  const trunkMat = trackMat(new THREE.MeshStandardMaterial({ color: '#5C3A21', roughness: 0.9 }));
  const foliageMat = trackMat(new THREE.MeshStandardMaterial({ color: pal.foliageColor, roughness: 0.72 }));
  const trunkInst = new THREE.InstancedMesh(
    trackGeo(new THREE.CylinderGeometry(0.35, 0.5, 3.2, 8)),
    trunkMat,
    treeCount
  );
  const crownInst = new THREE.InstancedMesh(
    trackGeo(new THREE.ConeGeometry(2.3, 5.2, 8)),
    foliageMat,
    treeCount
  );
  const dummy = new THREE.Object3D();
  const colorHelper = new THREE.Color();
  for (let i = 0; i < treeCount; i++) {
    const isPark = i < 18;
    const tx = isPark ? -32 - ((i * 19) % 48) : Math.cos((i / 26) * Math.PI * 2) * 118;
    const tz = isPark ? -18 + ((i * 23) % 52) : Math.sin((i / 26) * Math.PI * 2) * 118;
    const sc = 0.85 + ((i * 7) % 10) * 0.03;
    dummy.position.set(tx, 1.6 * sc, tz);
    dummy.scale.setScalar(sc);
    dummy.updateMatrix();
    trunkInst.setMatrixAt(i, dummy.matrix);
    dummy.position.set(tx, 4.8 * sc, tz);
    dummy.updateMatrix();
    crownInst.setMatrixAt(i, dummy.matrix);
    colorHelper.set(pal.foliageColor).offsetHSL(0, 0, ((i % 5) - 2) * 0.03);
    crownInst.setColorAt(i, colorHelper);
  }
  trunkInst.computeBoundingSphere();
  crownInst.computeBoundingSphere();
  worldGroup.add(trunkInst, crownInst);

  // Outer Mountain Ring Perimeter (Natural horizon barrier)
  const mountainCount = 24;
  const mtnMat = trackMat(new THREE.MeshStandardMaterial({ color: '#1E293B', roughness: 0.92 }));
  const mtnInst = new THREE.InstancedMesh(
    trackGeo(new THREE.ConeGeometry(18, 42, 6)),
    mtnMat,
    mountainCount
  );
  for (let i = 0; i < mountainCount; i++) {
    const ang = (Math.PI * 2 * i) / mountainCount;
    const dist = 148 + (i % 3) * 14;
    dummy.position.set(Math.cos(ang) * dist, 19, Math.sin(ang) * dist);
    dummy.scale.set(1 + (i % 2) * 0.35, 0.85 + (i % 3) * 0.25, 1);
    dummy.rotation.y = ang;
    dummy.updateMatrix();
    mtnInst.setMatrixAt(i, dummy.matrix);
  }
  mtnInst.computeBoundingSphere();
  worldGroup.add(mtnInst);

  // Seasonal Plaza Decorations (Christmas Tree for New Year, Winter Fountain, Spring Gazebo, etc.)
  const seasonalDecorGroup = new THREE.Group();
  const fireworksAnchors: THREE.Vector3[] = [
    new THREE.Vector3(-12, 22, -16),
    new THREE.Vector3(12, 24, -18),
    new THREE.Vector3(0, 26, -32),
  ];
  worldGroup.add(seasonalDecorGroup);

  const rebuildSeasonalDecor = (season: SeasonTheme) => {
    while (seasonalDecorGroup.children.length > 0) {
      seasonalDecorGroup.remove(seasonalDecorGroup.children[0]);
    }
    if (season === 'NEW_YEAR' || season === 'WINTER') {
      // Festive Giant Christmas Tree / Winter Monument in Central Plaza (-11, 0, -11)
      const treeGrp = new THREE.Group();
      treeGrp.position.set(-10, 0, -10);
      const tTrunk = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(0.6, 0.8, 2.4, 8)),
        trunkMat
      );
      tTrunk.position.y = 1.2;
      treeGrp.add(tTrunk);
      const tierColors = season === 'NEW_YEAR' ? '#047857' : '#BAE6FD';
      const tierMat = trackMat(new THREE.MeshStandardMaterial({ color: tierColors, roughness: 0.6 }));
      for (let t = 0; t < 3; t++) {
        const cone = new THREE.Mesh(
          trackGeo(new THREE.ConeGeometry(3.2 - t * 0.8, 3.6, 10)),
          tierMat
        );
        cone.position.y = 3.6 + t * 2.1;
        cone.castShadow = true;
        treeGrp.add(cone);
      }
      const star = new THREE.Mesh(trackGeo(new THREE.OctahedronGeometry(0.75, 0)), beaconMat);
      star.position.y = 9.9;
      treeGrp.add(star);
      if (season === 'NEW_YEAR') {
        const colors = ['#EF4444', '#FBBF24', '#38BDF8', '#EC4899'];
        for (let o = 0; o < 12; o++) {
          const ang = (Math.PI * 2 * o) / 12;
          const tier = o % 3;
          const r = 2.4 - tier * 0.65;
          const orb = new THREE.Mesh(
            trackGeo(new THREE.SphereGeometry(0.24, 8, 8)),
            trackMat(
              new THREE.MeshBasicMaterial({ color: colors[o % colors.length] })
            )
          );
          orb.position.set(Math.cos(ang) * r, 3.2 + tier * 2.1, Math.sin(ang) * r);
          treeGrp.add(orb);
        }
      }
      seasonalDecorGroup.add(treeGrp);
    } else {
      // Sun / Spring / Autumn Plaza Pavilion
      const pavMat = trackMat(
        new THREE.MeshStandardMaterial({
          color: season === 'SPRING' ? '#EC4899' : season === 'SUMMER' ? '#FBBF24' : '#EA580C',
          roughness: 0.45,
        })
      );
      const pav = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(3.5, 4.2, 0.8, 12)), pavMat);
      pav.position.set(-10, 0.4, -10);
      seasonalDecorGroup.add(pav);
    }
  };
  rebuildSeasonalDecor(initialSeason);

  // Animated Sky Clouds
  const cloudsGroup = new THREE.Group();
  const cloudMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#F8FAFC',
      roughness: 0.95,
      transparent: true,
      opacity: 0.82,
    })
  );
  for (let i = 0; i < 14; i++) {
    const cg = new THREE.Group();
    const p1 = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(4.5, 10, 8)), cloudMat);
    const p2 = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(3.5, 10, 8)), cloudMat);
    p2.position.set(3.8, -0.4, 0.5);
    const p3 = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(3.2, 10, 8)), cloudMat);
    p3.position.set(-3.6, -0.5, -0.4);
    cg.add(p1, p2, p3);
    cg.position.set(((i * 37) % 220) - 110, 62 + (i % 4) * 6, ((i * 53) % 220) - 110);
    cloudsGroup.add(cg);
  }
  worldGroup.add(cloudsGroup);

  // Collectible Energy Orbs & Gems (Streets, Rooftops, Bridge & Secret Cave)
  const orbGeo = trackGeo(new THREE.OctahedronGeometry(0.65, 0));
  const orbMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#38BDF8',
      emissive: '#0284C7',
      emissiveIntensity: 0.95,
      roughness: 0.15,
    })
  );
  const gemMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#F5C451',
      emissive: '#F59E0B',
      emissiveIntensity: 1.0,
      roughness: 0.12,
    })
  );

  const orbPositions: Array<{ x: number; y: number; z: number; kind: 'orb' | 'gem' | 'secret' }> = [
    { x: 0, y: 1.4, z: -12, kind: 'orb' },
    { x: 0, y: 1.4, z: -24, kind: 'orb' },
    { x: 0, y: 1.4, z: -38, kind: 'gem' },
    { x: -19, y: 37.5, z: -26, kind: 'gem' }, // rooftop sky_1
    { x: 19, y: 43.5, z: -28, kind: 'gem' }, // rooftop sky_2
    { x: 0, y: 55.5, z: -78, kind: 'gem' }, // rooftop sky_11
    { x: -48, y: 8.8, z: 42, kind: 'orb' }, // bridge center
    { x: -38, y: 8.8, z: 42, kind: 'orb' },
    { x: -58, y: 8.8, z: 42, kind: 'orb' },
    { x: 46, y: 7.5, z: -48, kind: 'orb' }, // house rooftop
    { x: -72, y: 2.0, z: -64, kind: 'secret' }, // Secret cave crystal pickup!
    { x: 14, y: 1.4, z: 0, kind: 'orb' },
    { x: -14, y: 1.4, z: 0, kind: 'orb' },
    { x: 0, y: 1.4, z: 18, kind: 'orb' },
  ];

  orbPositions.forEach((op, idx) => {
    const mesh = new THREE.Mesh(orbGeo, op.kind === 'orb' ? orbMat : gemMat);
    mesh.position.set(op.x, op.y, op.z);
    worldGroup.add(mesh);
    collectibles.push({
      id: `orb_${idx}`,
      mesh,
      baseY: op.y,
      collected: false,
      kind: op.kind,
    });
  });

  // Patrolling City Robo-Drones to fight!
  const droneBodyMat = trackMat(new THREE.MeshStandardMaterial({ color: '#1E293B', metalness: 0.7, roughness: 0.25 }));
  const droneEyeMat = trackMat(new THREE.MeshStandardMaterial({ color: '#FB7185', emissive: '#E11D48', emissiveIntensity: 1.1 }));
  const droneSpots = [
    new THREE.Vector3(0, 1.8, -28),
    new THREE.Vector3(-8, 1.8, -46),
    new THREE.Vector3(10, 1.8, -42),
    new THREE.Vector3(-48, 9.2, 42),
    new THREE.Vector3(28, 1.8, -8),
    new THREE.Vector3(-28, 1.8, 16),
  ];
  droneSpots.forEach((sp, idx) => {
    const dg = new THREE.Group();
    const core = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.75, 12, 10)), droneBodyMat);
    const eye = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.28, 8, 8)), droneEyeMat);
    eye.position.z = -0.68;
    const rotorL = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(1.2, 0.12, 0.28)), droneEyeMat);
    rotorL.position.set(-0.9, 0.4, 0);
    const rotorR = rotorL.clone();
    rotorR.position.x = 0.9;
    dg.add(core, eye, rotorL, rotorR);
    dg.position.copy(sp);
    worldGroup.add(dg);
    drones.push({
      id: `drone_${idx}`,
      group: dg,
      origin: sp.clone(),
      hp: 60,
      maxHp: 60,
      phaseOffset: idx * 1.3,
      koTimer: 0,
      alive: true,
    });
  });

  // Animated Multi-Part Metropolis Traffic Vehicles (N-S and E-W lanes)
  const carPalette = ['#38BDF8', '#F59E0B', '#EF4444', '#10B981', '#A855F7', '#F97316', '#E2E8F0', '#22D3EE'];
  const cabinMat = trackMat(new THREE.MeshStandardMaterial({ color: '#0F172A', roughness: 0.15, metalness: 0.75 }));
  const tireMat = trackMat(new THREE.MeshStandardMaterial({ color: '#090D16', roughness: 0.85, metalness: 0.1 }));
  const headlightMat = trackMat(new THREE.MeshBasicMaterial({ color: '#FEF08A' }));
  const taillightMat = trackMat(new THREE.MeshBasicMaterial({ color: '#EF4444' }));
  const carShadowMat = trackMat(
    new THREE.MeshBasicMaterial({
      map: textures.contactShadowMap,
      transparent: true,
      opacity: 0.42,
      depthWrite: false,
    })
  );
  const chassisGeo = trackGeo(new THREE.BoxGeometry(1.9, 0.72, 3.9));
  const cabinGeo = trackGeo(new THREE.BoxGeometry(1.6, 0.58, 2.0));
  const wheelGeo = trackGeo(new THREE.CylinderGeometry(0.36, 0.36, 0.24, 10));
  const lampGeo = trackGeo(new THREE.BoxGeometry(0.36, 0.16, 0.1));
  const shadowPlaneGeo = trackGeo(new THREE.CircleGeometry(2.3, 12));

  const vehicleSpecs: Array<{ axis: 'x' | 'z'; dir: 1 | -1; lane: number; pos: number; speed: number }> = [
    { axis: 'z', dir: -1, lane: 3.6, pos: -18, speed: 12.5 },
    { axis: 'z', dir: -1, lane: 3.6, pos: -72, speed: 14.0 },
    { axis: 'z', dir: 1, lane: -3.6, pos: -45, speed: 13.0 },
    { axis: 'z', dir: 1, lane: -3.6, pos: 38, speed: 11.8 },
    { axis: 'x', dir: 1, lane: 3.6, pos: -52, speed: 12.2 },
    { axis: 'x', dir: 1, lane: 3.6, pos: 28, speed: 13.4 },
    { axis: 'x', dir: -1, lane: -3.6, pos: 64, speed: 12.0 },
    { axis: 'x', dir: -1, lane: -3.6, pos: -24, speed: 14.2 },
  ];

  vehicleSpecs.forEach((vs, idx) => {
    const carGrp = new THREE.Group();
    const paintMat = trackMat(
      new THREE.MeshStandardMaterial({
        color: carPalette[idx % carPalette.length],
        roughness: 0.28,
        metalness: 0.55,
      })
    );
    const body = new THREE.Mesh(chassisGeo, paintMat);
    body.position.y = 0.62;
    body.castShadow = true;

    const cabin = new THREE.Mesh(cabinGeo, cabinMat);
    cabin.position.set(0, 1.2, -0.15);

    const shadowDisc = new THREE.Mesh(shadowPlaneGeo, carShadowMat);
    shadowDisc.rotation.x = -Math.PI / 2;
    shadowDisc.position.y = 0.05;

    const hlL = new THREE.Mesh(lampGeo, headlightMat);
    hlL.position.set(-0.56, 0.64, 1.96);
    const hlR = hlL.clone();
    hlR.position.x = 0.56;

    const tlL = new THREE.Mesh(lampGeo, taillightMat);
    tlL.position.set(-0.56, 0.64, -1.96);
    const tlR = tlL.clone();
    tlR.position.x = 0.56;

    const wheels: THREE.Mesh[] = [];
    const wOffsets: Array<[number, number, number]> = [
      [-0.98, 0.36, 1.22],
      [0.98, 0.36, 1.22],
      [-0.98, 0.36, -1.22],
      [0.98, 0.36, -1.22],
    ];
    for (const [wx, wy, wz] of wOffsets) {
      const wMesh = new THREE.Mesh(wheelGeo, tireMat);
      wMesh.rotation.z = Math.PI / 2;
      wMesh.position.set(wx, wy, wz);
      carGrp.add(wMesh);
      wheels.push(wMesh);
    }

    carGrp.add(shadowDisc, body, cabin, hlL, hlR, tlL, tlR);

    if (vs.axis === 'z') {
      carGrp.position.set(vs.lane, 0, vs.pos);
      carGrp.rotation.y = vs.dir === 1 ? 0 : Math.PI;
    } else {
      carGrp.position.set(vs.pos, 0, vs.lane);
      carGrp.rotation.y = vs.dir === 1 ? Math.PI / 2 : -Math.PI / 2;
    }

    worldGroup.add(carGrp);
    vehicles.push({
      id: `car_${idx}`,
      group: carGrp,
      axis: vs.axis,
      dir: vs.dir,
      laneCoord: vs.lane,
      speed: vs.speed,
      limit: 108,
      wheels,
    });
  });

  const groundYAt = (x: number, z: number): number => {
    // Gentle hills beyond outer perimeter (>95m)
    const r = Math.hypot(x, z);
    if (r > 96) {
      return Math.min(8, (r - 96) * 0.18);
    }
    // Boss arena raised floor at (0, 108)
    if (Math.hypot(x - 0, z - 108) <= 31) {
      return 0.8;
    }
    return 0;
  };

  const applySeason = (season: SeasonTheme) => {
    const p = getSeasonPalette(season);
    groundMat.color.set(p.groundColor);
    foliageMat.color.set(p.foliageColor);
    for (let i = 0; i < treeCount; i++) {
      colorHelper.set(p.foliageColor).offsetHSL(0, 0, ((i % 5) - 2) * 0.03);
      crownInst.setColorAt(i, colorHelper);
    }
    if (crownInst.instanceColor) crownInst.instanceColor.needsUpdate = true;
    rebuildSeasonalDecor(season);
  };

  const updateWorld = (elapsed: number, dt: number) => {
    treasureCrystal.rotation.y = elapsed * 1.3;
    treasureCrystal.position.y = 2.2 + Math.sin(elapsed * 2.4) * 0.35;

    for (const v of vehicles) {
      if (v.axis === 'z') {
        v.group.position.z += v.dir * v.speed * dt;
        if (v.group.position.z > v.limit) v.group.position.z = -v.limit;
        if (v.group.position.z < -v.limit) v.group.position.z = v.limit;
      } else {
        v.group.position.x += v.dir * v.speed * dt;
        if (v.group.position.x > v.limit) v.group.position.x = -v.limit;
        if (v.group.position.x < -v.limit) v.group.position.x = v.limit;
      }
      for (const w of v.wheels) {
        w.rotation.x += v.speed * dt * 1.4;
      }
    }
  };

  return {
    worldGroup,
    colliders,
    raycastTargets,
    collectibles,
    drones,
    vehicles,
    seasonalDecorGroup,
    cloudsGroup,
    fireworksAnchors,
    secretZoneCenter,
    bossArenaCenter,
    groundYAt,
    applySeason,
    updateWorld,
    dispose: () => {
      disposableGeos.forEach((g) => g.dispose());
      disposableMats.forEach((m) => m.dispose());
    },
  };
}
