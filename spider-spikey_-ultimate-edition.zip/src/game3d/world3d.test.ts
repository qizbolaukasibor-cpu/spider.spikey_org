import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BOSS_CATALOG,
  CASE_CATALOG,
  SEASON_PASS_100,
  SKILL_CATALOG,
  SKIN_CATALOG,
  WEB_CATALOG,
} from '../data/world3dCatalog';
import { LEVEL_BY_ID, LEVELS_3D_CATALOG } from '../data/levels3d';
import {
  applyGraphicsPreset,
  applyXpAndLevel,
  assertAll3DCasesValid,
  buyCaseItem,
  buySkinItem,
  buyWebItem,
  claimSeasonPassReward,
  completeCampaignLevel,
  createDefaultSave,
  DEFAULT_KEY_BINDINGS,
  getSeasonPassLevel,
  openCaseFromSave,
  rollRarityFromCaseDef,
  upgradeSkillItem,
  xpForNextLevel,
} from '../utils/spider3dStorage';
import {
  checkPortalTrigger,
  computeFiveDirectionVector,
  computeWebReleaseBoost,
  findSkyscraperWebAnchor,
  getBossIndexForMatches,
  resolveCityCollision,
  shouldTriggerBossAfterMatch,
  stepAirFlightPhysics,
  stepWebSwingPhysics,
} from './worldRules';

test('all 8 case drop tables sum strictly to 100%', () => {
  assert.equal(CASE_CATALOG.length, 8);
  assert.doesNotThrow(() => assertAll3DCasesValid());
});

test('all 5 web directions compute distinct orthogonal unit vectors', () => {
  const dirs = ['FORWARD', 'BACKWARD', 'LEFT', 'RIGHT', 'UPWARD'] as const;
  const vecs = dirs.map((d) => computeFiveDirectionVector(d, 0, 0));
  for (const v of vecs) {
    const len = Math.hypot(v.x, v.y, v.z);
    assert.ok(Math.abs(len - 1) < 0.001, `expected unit length, got ${len}`);
  }
  assert.ok(vecs[0].z < -0.5, 'FORWARD should point -Z at yaw 0');
  assert.ok(vecs[1].z > 0.5, 'BACKWARD should point +Z at yaw 0');
  assert.ok(vecs[2].x < -0.5, 'LEFT should point -X at yaw 0');
  assert.ok(vecs[3].x > 0.5, 'RIGHT should point +X at yaw 0');
  assert.ok(vecs[4].y > 0.9, 'UPWARD should point strongly +Y');
});

test('city collision keeps player grounded on rooftops, ignores disabled platforms, and detects slippery ice', () => {
  const colliders = [
    { id: 'b1', x: 10, y: 0, z: 0, w: 8, h: 12, d: 8, climbable: true, kind: 'building' as const },
    { id: 'ice1', x: -10, y: 0, z: 0, w: 8, h: 4, d: 8, climbable: true, slippery: true, kind: 'platform' as const },
    { id: 'col_dead', x: 0, y: 0, z: -20, w: 8, h: 4, d: 8, disabled: true, kind: 'platform' as const },
  ];
  const groundZero = () => 0;

  // Landing on rooftop
  const onRoof = resolveCityCollision(
    { x: 10, y: 12.1, z: 0 },
    { x: 0, y: -6, z: 0 },
    0.55,
    2.0,
    colliders,
    groundZero,
    0.05
  );
  assert.equal(onRoof.grounded, true);
  assert.equal(onRoof.pos.y, 12);
  assert.equal(onRoof.standingColliderId, 'b1');

  // Landing on slippery ice platform
  const onIce = resolveCityCollision(
    { x: -10, y: 4.1, z: 0 },
    { x: 0, y: -4, z: 0 },
    0.55,
    2.0,
    colliders,
    groundZero,
    0.05
  );
  assert.equal(onIce.onSlipperySurface, true);
  assert.equal(onIce.standingColliderId, 'ice1');

  // Disabled collapsing platform does not support player
  const overDisabled = resolveCityCollision(
    { x: 0, y: 4.1, z: -20 },
    { x: 0, y: -4, z: 0 },
    0.55,
    2.0,
    colliders,
    groundZero,
    0.05
  );
  assert.equal(overDisabled.standingColliderId, null);

  // Pushing into side wall triggers climbable surface
  const againstWall = resolveCityCollision(
    { x: 5.4, y: 2, z: 0 },
    { x: 6, y: 0, z: 0 },
    0.55,
    2.0,
    colliders,
    groundZero,
    0.05
  );
  assert.equal(againstWall.touchingClimbableWall, true);
  assert.ok(againstWall.pos.x <= 5.46, 'player pushed cleanly outside building');
});

test('3D web swing physics pulls player toward anchor, constrains rope, and release launch boosts momentum', () => {
  const swung = stepWebSwingPhysics(
    { x: 0, y: 6, z: 12 },
    { x: 0, y: -2, z: 0 },
    { x: 0, y: 18, z: 0 },
    16,
    { x: 0, y: 0, z: -1 },
    true,
    1.2,
    0.05
  );
  assert.ok(swung.ropeLength < 16, 'pullActive reels rope shorter');
  assert.ok(swung.pos.z < 12, 'swing pulls player forward toward anchor');

  const released = computeWebReleaseBoost({ x: 0, y: 3, z: -16 }, 0, 1.2);
  assert.ok(released.z < -20, 'release launch boosts forward -Z momentum at yaw 0');
  assert.ok(released.y >= 12.2, 'release launch lifts player into aerial flight arc');

  // Skyscraper anchor finder locates elevated building facade inside 5-direction cone
  const skyColliders = [
    { id: 'flat_pad', x: 0, y: 0, z: -18, w: 10, h: 1.5, d: 10, climbable: true, kind: 'platform' as const },
    { id: 'sky_left', x: -16, y: 0, z: -20, w: 10, h: 42, d: 10, climbable: true, kind: 'building' as const },
    { id: 'sky_front', x: 4, y: 0, z: -34, w: 12, h: 52, d: 12, climbable: true, kind: 'building' as const },
  ];
  const leftAim = computeFiveDirectionVector('LEFT', 0, 0);
  const leftAnchor = findSkyscraperWebAnchor({ x: 0, y: 4, z: -20 }, leftAim, skyColliders, 95);
  assert.ok(leftAnchor !== null, 'LEFT shoot finds left skyscraper');
  assert.ok(leftAnchor.y >= 8 && leftAnchor.x < -5, 'anchors high on left skyscraper, never ground');

  const frontAim = computeFiveDirectionVector('FORWARD', 0, 0);
  const frontAnchor = findSkyscraperWebAnchor({ x: 0, y: 3, z: 0 }, frontAim, skyColliders, 95);
  assert.ok(frontAnchor !== null && frontAnchor.y >= 10, 'FORWARD shoot attaches high on skyscraper ahead');

  // Aerodynamic Spider Flight: holding Space glides with much slower sink rate and boost increases forward speed
  const fallingNoGlide = stepAirFlightPhysics(
    { x: 0, y: 0, z: -22 },
    { x: 0, y: 0, z: -1 },
    1,
    0,
    12,
    false,
    false,
    true,
    0.1
  );
  const gliding = stepAirFlightPhysics(
    { x: 0, y: 0, z: -22 },
    { x: 0, y: 0, z: -1 },
    1,
    0,
    12,
    true,
    true,
    true,
    0.1
  );
  assert.ok(gliding.y > fallingNoGlide.y, 'Web-Wings glide reduces gravity sink rate cleanly');
  assert.ok(Math.hypot(gliding.x, gliding.z) >= 22, 'air boost sustains/accelerates horizontal flight speed');

  const defSave = createDefaultSave();
  assert.equal(defSave.settings.keyBindings?.shootWeb, DEFAULT_KEY_BINDINGS.shootWeb);
  assert.equal(defSave.settings.keyBindings?.web5, 'Digit5');
});

test('10-level adventure campaign has sequential portals, obstacles, 6 enemy types, and unlocks next level cleanly', () => {
  assert.equal(LEVELS_3D_CATALOG.length, 10);
  const seenEnemyKinds = new Set<string>();
  for (let i = 0; i < 10; i++) {
    const lvl = LEVELS_3D_CATALOG[i];
    assert.equal(lvl.id, i + 1);
    assert.ok(lvl.platforms.length >= 5);
    assert.ok(lvl.obstacles.length >= 3);
    assert.ok(lvl.enemies.length >= 3);
    assert.ok(lvl.portalPos.z < lvl.startPos.z - 60);
    for (const e of lvl.enemies) seenEnemyKinds.add(e.kind);
  }
  assert.equal(seenEnemyKinds.size, 6);

  // Portal triggers only when physically inside radius
  const lvl1 = LEVEL_BY_ID[1];
  assert.equal(checkPortalTrigger(lvl1.startPos, lvl1.portalPos, 3.6), false);
  assert.equal(
    checkPortalTrigger({ x: lvl1.portalPos.x, y: lvl1.portalPos.y, z: lvl1.portalPos.z + 1.5 }, lvl1.portalPos, 3.6),
    true
  );

  // First clear unlocks level 2, replay gives reduced coins without duplicate clear
  const initialSave = createDefaultSave();
  assert.equal(initialSave.unlockedLevel, 1);
  const firstClear = completeCampaignLevel(initialSave, lvl1);
  assert.equal(firstClear.firstClear, true);
  assert.equal(firstClear.unlockedNextLevel, 2);
  assert.equal(firstClear.save.unlockedLevel, 2);
  assert.deepEqual(firstClear.save.completedLevels, [1]);

  const replayClear = completeCampaignLevel(firstClear.save, lvl1);
  assert.equal(replayClear.firstClear, false);
  assert.ok(replayClear.coinsEarned < firstClear.coinsEarned);
  assert.deepEqual(replayClear.save.completedLevels, [1]);
});

test('every 5 completed matches triggers progressive bosses', () => {
  assert.equal(shouldTriggerBossAfterMatch(0), false);
  assert.equal(shouldTriggerBossAfterMatch(4), false);
  assert.equal(shouldTriggerBossAfterMatch(5), true);
  assert.equal(shouldTriggerBossAfterMatch(10), true);
  assert.equal(getBossIndexForMatches(5, BOSS_CATALOG.length), 0);
  assert.equal(getBossIndexForMatches(10, BOSS_CATALOG.length), 1);
  // Boss HP strictly increases from Boss 1 to Boss 7
  for (let i = 1; i < BOSS_CATALOG.length; i++) {
    assert.ok(BOSS_CATALOG[i].maxHp > BOSS_CATALOG[i - 1].maxHp);
  }
});

test('100-level Season Pass has increasing XP curve and claimable milestones', () => {
  assert.equal(SEASON_PASS_100.length, 100);
  for (let i = 1; i < SEASON_PASS_100.length; i++) {
    assert.ok(SEASON_PASS_100[i].xpRequired > SEASON_PASS_100[i - 1].xpRequired);
  }
  let save = createDefaultSave();
  const tier1 = SEASON_PASS_100[0];
  save = { ...save, seasonPassXp: tier1.xpRequired, seasonPremiumUnlocked: true };
  assert.equal(getSeasonPassLevel(save.seasonPassXp), 1);
  const claimedFree = claimSeasonPassReward(save, tier1, 'free');
  assert.ok(claimedFree.coins > save.coins);
});

test('leveling XP curve grows strictly and expensive marketplace / skills / cases enforce balances', () => {
  assert.ok(xpForNextLevel(10) > xpForNextLevel(2));
  const skin = SKIN_CATALOG.find((s) => s.id === 'skin_urban_crawler')!;
  const basicCase = CASE_CATALOG[0];
  assert.equal(skin.coinPrice, 30000);
  assert.equal(basicCase.coinPrice, 15000);
  for (let i = 1; i < CASE_CATALOG.length; i++) {
    assert.ok(CASE_CATALOG[i].coinPrice >= basicCase.coinPrice);
  }

  // Low balance must be rejected cleanly
  const poorSave = createDefaultSave();
  assert.equal(buySkinItem(poorSave, skin).ok, false);
  assert.equal(buyCaseItem(poorSave, basicCase).ok, false);

  // High balance succeeds and opens cases cleanly
  const richSave = { ...poorSave, coins: 120000, gems: 100 };
  const boughtSkin = buySkinItem(richSave, skin);
  assert.equal(boughtSkin.ok, true);
  if (!boughtSkin.ok) return;

  const dupSkin = buySkinItem(boughtSkin.save, skin);
  assert.equal(dupSkin.ok, false);

  const web = WEB_CATALOG.find((w) => w.id === 'web_ice')!;
  const boughtWeb = buyWebItem(boughtSkin.save, web);
  assert.equal(boughtWeb.ok, true);
  if (!boughtWeb.ok) return;

  const skillRes = upgradeSkillItem(boughtWeb.save, SKILL_CATALOG[0].id);
  assert.equal(skillRes.ok, true);

  // Case buy & open
  const boughtCase = buyCaseItem(boughtWeb.save, basicCase);
  assert.equal(boughtCase.ok, true);
  if (!boughtCase.ok) return;
  const opened = openCaseFromSave(boughtCase.save, basicCase, () => 0.1);
  assert.equal(opened.ok, true);
  if (opened.ok) {
    assert.equal(opened.save.stats.casesOpened, 1);
    assert.ok(opened.itemId.length > 0);
  }
  assert.equal(rollRarityFromCaseDef(basicCase, 99.5), 'EPIC');

  const leveled = applyXpAndLevel(richSave, 1500, 300);
  assert.ok(leveled.leveledUp);
  assert.ok(leveled.save.level > 1);
});

test('catalogs cover all 14 skins across 8 rarities, Miles Morales abilities, 13 web styles, and 5 graphics presets calibrate cleanly', () => {
  assert.equal(SKIN_CATALOG.length, 14);
  assert.equal(WEB_CATALOG.length, 13);
  const rarities = new Set(SKIN_CATALOG.map((s) => s.rarity));
  assert.equal(rarities.size, 8);

  const miles = SKIN_CATALOG.find((s) => s.id === 'skin_miles_morales');
  assert.ok(miles, 'Miles Morales skin must exist in SKIN_CATALOG');
  assert.equal(miles.rarity, 'LEGENDARY');
  assert.equal(miles.variant, 'miles_morales');
  assert.ok(miles.abilities && miles.abilities.length === 5, 'Miles Morales must define 5 special abilities');
  assert.deepEqual(
    miles.abilities.map((a) => a.name),
    ['Venom Punch', 'Venom Jump', 'Camouflage', 'Venom Dash', 'Venom Strike']
  );

  const low = applyGraphicsPreset('low');
  assert.equal(low.shadows, false);
  assert.equal(low.bloom, false);
  assert.equal(low.viewDistance, 'near');

  const ultra = applyGraphicsPreset('ultra');
  assert.equal(ultra.shadows, true);
  assert.equal(ultra.bloom, true);
  assert.equal(ultra.viewDistance, 'ultra');

  const extreme = applyGraphicsPreset('extreme');
  assert.equal(extreme.graphicsQuality, 'extreme');
  assert.equal(extreme.resolutionScale, 1.25);

  const def = createDefaultSave();
  assert.equal(def.settings.showFps, true);
  assert.equal(def.settings.fpsMode, 'auto');
  assert.ok(def.ownedSkinIds.includes('skin_crimson_rookie'));
  assert.ok(def.ownedSkinIds.includes('skin_miles_morales'));
  assert.equal(def.equippedSkinId, 'skin_crimson_rookie');

  const withMiles = { ...def, equippedSkinId: 'skin_miles_morales' };
  assert.equal(withMiles.equippedSkinId, 'skin_miles_morales');
});
