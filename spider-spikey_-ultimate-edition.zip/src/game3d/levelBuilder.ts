import * as THREE from 'three';
import {
  CityCollider,
  LevelDef,
  LevelObstacleSpec,
} from '../types/spider3d';
import {
  buildEnemy3D,
  buildPortal3D,
  EnemyRig3D,
  PortalRig3D,
  ProceduralTextureSet,
} from './proceduralModels';

export interface ActiveObstacle3D {
  spec: LevelObstacleSpec;
  mesh: THREE.Group;
  collider: CityCollider | null;
  prevX: number;
  prevY: number;
  prevZ: number;
  deltaX: number;
  deltaY: number;
  deltaZ: number;
  collapseTimer: number; // >0 = shaking before collapse
  respawnTimer: number; // >0 = collapsed, waiting to respawn
  activeDangerBox: {
    x: number;
    y: number;
    z: number;
    w: number;
    h: number;
    d: number;
  } | null;
}

export interface ActiveLevelEnemy3D {
  id: string;
  rig: EnemyRig3D;
  origin: THREE.Vector3;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  patrolRadius: number;
  alive: boolean;
  koTimer: number;
  attackCooldown: number;
}

export interface LevelOrb3D {
  id: string;
  mesh: THREE.Mesh;
  baseY: number;
  collected: boolean;
  kind: 'orb' | 'gem';
}

export interface BuiltLevelWorld3D {
  levelDef: LevelDef;
  worldGroup: THREE.Group;
  colliders: CityCollider[];
  raycastTargets: THREE.Object3D[];
  obstacles: ActiveObstacle3D[];
  enemies: ActiveLevelEnemy3D[];
  orbs: LevelOrb3D[];
  portal: PortalRig3D;
  cloudsGroup: THREE.Group;
  groundYAt: (x: number, z: number) => number;
  updateDynamicObjects: (elapsed: number, dt: number) => void;
  dispose: () => void;
}

export function buildAdventureLevel3D(
  levelDef: LevelDef,
  textures: ProceduralTextureSet
): BuiltLevelWorld3D {
  const worldGroup = new THREE.Group();
  const colliders: CityCollider[] = [];
  const raycastTargets: THREE.Object3D[] = [];
  const obstacles: ActiveObstacle3D[] = [];
  const enemies: ActiveLevelEnemy3D[] = [];
  const orbs: LevelOrb3D[] = [];
  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    geos.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    mats.push(m);
    return m;
  };

  // 1. Extended Ground Plane (unless high-altitude void level)
  if (!levelDef.hasVoidPit) {
    const groundMat = trackMat(
      new THREE.MeshStandardMaterial({
        color: levelDef.groundColor,
        map: textures.groundDetailMap,
        roughness: levelDef.slipperyFloors ? 0.18 : 0.85,
        metalness: levelDef.slipperyFloors ? 0.25 : 0.05,
      })
    );
    const ground = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(420, 420)), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    worldGroup.add(ground);
    raycastTargets.push(ground);

    // Asphalt Boulevard + Raised Sidewalks & Streetlamps
    const roadMat = trackMat(
      new THREE.MeshStandardMaterial({
        color: '#FFFFFF',
        map: textures.roadAsphaltMap,
        roughness: 0.72,
      })
    );
    const road = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(14, 220)), roadMat);
    road.rotation.x = -Math.PI / 2;
    road.position.set(0, 0.03, -60);
    road.receiveShadow = true;
    worldGroup.add(road);

    const sidewalkMat = trackMat(
      new THREE.MeshStandardMaterial({ color: '#64748B', roughness: 0.85 })
    );
    const lampPoleMat = trackMat(
      new THREE.MeshStandardMaterial({ color: '#1E293B', metalness: 0.7, roughness: 0.3 })
    );
    const lampBulbMat = trackMat(
      new THREE.MeshBasicMaterial({ color: '#FEF08A' })
    );

    for (const side of [-1, 1]) {
      const curb = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(3.5, 0.24, 210)), sidewalkMat);
      curb.position.set(side * 8.8, 0.12, -55);
      curb.receiveShadow = true;
      worldGroup.add(curb);

      for (let z = 12; z >= -130; z -= 24) {
        const pole = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.12, 0.16, 5.2, 8)), lampPoleMat);
        pole.position.set(side * 9.5, 2.6, z);
        const bulb = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.32, 8, 8)), lampBulbMat);
        bulb.position.set(side * 8.7, 5.2, z);
        worldGroup.add(pole, bulb);
      }
    }
  }

  // 2. Platforms, Detailed Skyscrapers (with balconies & antennas), & Grapple Pillars
  const windowMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#FFFFFF',
      map: textures.skyscraperWindowMap,
      roughness: 0.35,
      metalness: 0.45,
      emissive: levelDef.accentColor,
      emissiveIntensity: 0.22,
    })
  );
  const trimMat = trackMat(
    new THREE.MeshStandardMaterial({ color: '#CBD5E1', roughness: 0.5, metalness: 0.35 })
  );
  const iceMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#BAE6FD',
      roughness: 0.14,
      metalness: 0.35,
    })
  );

  for (const p of levelDef.platforms) {
    const grp = new THREE.Group();
    grp.position.set(p.x, p.y, p.z);

    if (p.kind === 'building') {
      const shaftMat = p.color
        ? trackMat(
            new THREE.MeshStandardMaterial({
              color: p.color,
              map: textures.skyscraperWindowMap,
              roughness: 0.4,
              metalness: 0.4,
            })
          )
        : windowMat;
      const shaft = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(p.w, p.h, p.d)), shaftMat);
      shaft.position.y = p.h * 0.5;
      shaft.castShadow = true;
      shaft.receiveShadow = true;
      grp.add(shaft);

      // Architectural roof ledge + Balcony accents
      const ledge = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(p.w + 0.7, 0.55, p.d + 0.7)),
        trimMat
      );
      ledge.position.y = p.h - 0.25;
      grp.add(ledge);

      if (p.h >= 12) {
        const balcony = new THREE.Mesh(
          trackGeo(new THREE.BoxGeometry(p.w + 1.1, 0.35, 2.2)),
          trimMat
        );
        balcony.position.set(0, p.h * 0.55, p.d * 0.5 + 0.45);
        grp.add(balcony);
      }
      raycastTargets.push(shaft, ledge);
    } else if (p.kind === 'pillar') {
      const pillarMat = trackMat(
        new THREE.MeshStandardMaterial({
          color: p.color || '#334155',
          metalness: 0.65,
          roughness: 0.32,
        })
      );
      const col = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(p.w, p.h, p.d)), pillarMat);
      col.position.y = p.h * 0.5;
      col.castShadow = true;
      const cap = new THREE.Mesh(
        trackGeo(new THREE.OctahedronGeometry(p.w * 0.42, 0)),
        trackMat(
          new THREE.MeshStandardMaterial({
            color: levelDef.accentColor,
            emissive: levelDef.accentColor,
            emissiveIntensity: 0.9,
          })
        )
      );
      cap.position.y = p.h + 1.1;
      grp.add(col, cap);
      raycastTargets.push(col);
    } else {
      const platMat = p.slippery
        ? iceMat
        : trackMat(
            new THREE.MeshStandardMaterial({
              color: p.color || '#475569',
              roughness: 0.65,
              metalness: 0.15,
            })
          );
      const deck = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(p.w, p.h, p.d)), platMat);
      deck.position.y = p.h * 0.5;
      deck.castShadow = true;
      deck.receiveShadow = true;
      grp.add(deck);
      raycastTargets.push(deck);
    }

    worldGroup.add(grp);
    colliders.push({
      id: p.id,
      x: p.x,
      y: p.y,
      z: p.z,
      w: p.w,
      h: p.h,
      d: p.d,
      climbable: p.climbable !== false,
      slippery: p.slippery || levelDef.slipperyFloors,
      kind: p.kind || 'platform',
    });

    // Place a collectible Orb or Gem on main route platforms
    if (p.kind !== 'pillar' && p.z < 5 && p.z > levelDef.portalPos.z + 8) {
      const orbMesh = new THREE.Mesh(
        trackGeo(new THREE.OctahedronGeometry(0.62, 0)),
        trackMat(
          new THREE.MeshStandardMaterial({
            color: levelDef.accentColor,
            emissive: levelDef.accentColor,
            emissiveIntensity: 1.0,
          })
        )
      );
      const oy = p.y + p.h + 1.3;
      orbMesh.position.set(p.x, oy, p.z);
      worldGroup.add(orbMesh);
      orbs.push({
        id: `orb_${p.id}`,
        mesh: orbMesh,
        baseY: oy,
        collected: false,
        kind: p.id.includes('3') || p.id.includes('4') ? 'gem' : 'orb',
      });
    }
  }

  // 3. Scenic Perimeter Multi-Tier Trees & Overhead Web-Swinging Sky Arches
  const treeCount = 24;
  const trunkMat = trackMat(new THREE.MeshStandardMaterial({ color: '#5C3A21', roughness: 0.9 }));
  const folMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: levelDef.id === 4 ? '#16A34A' : levelDef.id === 5 ? '#E0F2FE' : '#334155',
      roughness: 0.78,
    })
  );
  const treeInst = new THREE.InstancedMesh(
    trackGeo(new THREE.ConeGeometry(2.3, 5.4, 8)),
    folMat,
    treeCount
  );
  const crownUpperInst = new THREE.InstancedMesh(
    trackGeo(new THREE.ConeGeometry(1.6, 4.0, 8)),
    folMat,
    treeCount
  );
  const trunkInst = new THREE.InstancedMesh(
    trackGeo(new THREE.CylinderGeometry(0.4, 0.55, 3.2, 8)),
    trunkMat,
    treeCount
  );
  const dummy = new THREE.Object3D();
  for (let i = 0; i < treeCount; i++) {
    const side = i % 2 === 0 ? -1 : 1;
    const tx = side * (24 + (i % 3) * 8);
    const tz = 10 - i * 6.5;
    const baseY = levelDef.hasVoidPit ? 4 : 0;
    const sc = 0.88 + ((i * 7) % 5) * 0.06;
    dummy.scale.set(sc, sc, sc);
    dummy.position.set(tx, baseY + 1.6 * sc, tz);
    dummy.updateMatrix();
    trunkInst.setMatrixAt(i, dummy.matrix);
    dummy.position.set(tx, baseY + 4.8 * sc, tz);
    dummy.updateMatrix();
    treeInst.setMatrixAt(i, dummy.matrix);
    dummy.position.set(tx, baseY + 7.2 * sc, tz);
    dummy.updateMatrix();
    crownUpperInst.setMatrixAt(i, dummy.matrix);
  }
  treeInst.computeBoundingSphere();
  crownUpperInst.computeBoundingSphere();
  trunkInst.computeBoundingSphere();
  worldGroup.add(trunkInst, treeInst, crownUpperInst);

  // Overhead Web-Swinging Sky-Cranes / Suspension Arches for seamless UP / LEFT / RIGHT / FRONT / BACK chains
  const archSteelMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#1E293B',
      metalness: 0.75,
      roughness: 0.28,
    })
  );
  const archBeaconMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: levelDef.accentColor,
      emissive: levelDef.accentColor,
      emissiveIntensity: 1.25,
    })
  );
  for (let az = 0; az >= levelDef.portalPos.z + 16; az -= 24) {
    const archY = Math.max(levelDef.startPos.y, levelDef.portalPos.y) + 14.5;
    const crossBeam = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(34, 1.5, 2.2)), archSteelMat);
    crossBeam.position.set(0, archY, az);
    crossBeam.castShadow = true;

    const beaconPod = new THREE.Mesh(trackGeo(new THREE.OctahedronGeometry(0.95, 0)), archBeaconMat);
    beaconPod.position.set(0, archY - 1.1, az);

    const postL = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.55, 0.7, archY + 4, 8)), archSteelMat);
    postL.position.set(-16.5, (archY - 4) * 0.5, az);
    const postR = postL.clone();
    postR.position.x = 16.5;

    worldGroup.add(crossBeam, beaconPod, postL, postR);
    raycastTargets.push(crossBeam, postL, postR);
  }

  // 4. Moving Obstacles & Environmental Hazards
  const dangerMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#EF4444',
      emissive: '#EF4444',
      emissiveIntensity: 1.4,
      roughness: 0.2,
    })
  );
  const electricMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#38BDF8',
      emissive: '#22D3EE',
      emissiveIntensity: 1.5,
      transparent: true,
      opacity: 0.85,
    })
  );
  const platMoveMat = trackMat(
    new THREE.MeshStandardMaterial({ color: '#F59E0B', metalness: 0.5, roughness: 0.35 })
  );
  const collapseMat = trackMat(
    new THREE.MeshStandardMaterial({ color: '#FB7185', roughness: 0.55 })
  );

  for (const spec of levelDef.obstacles) {
    const obsGroup = new THREE.Group();
    obsGroup.position.set(spec.x, spec.y, spec.z);

    let meshMat: THREE.Material = platMoveMat;
    if (spec.kind === 'laser_gate' || spec.kind === 'swinging_pendulum' || spec.kind === 'falling_object') {
      meshMat = dangerMat;
    } else if (spec.kind === 'electric_barrier') {
      meshMat = electricMat;
    } else if (spec.kind === 'collapsing_platform') {
      meshMat = collapseMat;
    } else if (spec.kind === 'wind_zone') {
      meshMat = trackMat(
        new THREE.MeshBasicMaterial({
          color: '#BAE6FD',
          wireframe: true,
          transparent: true,
          opacity: 0.25,
        })
      );
    }

    const body = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(spec.w, spec.h, spec.d)), meshMat);
    if (spec.kind !== 'wind_zone') {
      body.castShadow = true;
      body.receiveShadow = true;
    }
    obsGroup.add(body);
    worldGroup.add(obsGroup);

    const hasSolidCollider =
      spec.kind === 'moving_platform' ||
      spec.kind === 'rotating_platform' ||
      spec.kind === 'moving_wall' ||
      spec.kind === 'sliding_block' ||
      spec.kind === 'collapsing_platform' ||
      spec.kind === 'timed_door';

    let collider: CityCollider | null = null;
    if (hasSolidCollider) {
      collider = {
        id: spec.id,
        x: spec.x,
        y: spec.y - spec.h * 0.5,
        z: spec.z,
        w: spec.w,
        h: spec.h,
        d: spec.d,
        climbable: true,
        kind: 'platform',
      };
      colliders.push(collider);
      raycastTargets.push(body);
    }

    obstacles.push({
      spec,
      mesh: obsGroup,
      collider,
      prevX: spec.x,
      prevY: spec.y,
      prevZ: spec.z,
      deltaX: 0,
      deltaY: 0,
      deltaZ: 0,
      collapseTimer: 0,
      respawnTimer: 0,
      activeDangerBox: spec.lethal
        ? {
            x: spec.x,
            y: spec.y,
            z: spec.z,
            w: spec.w,
            h: spec.h,
            d: spec.d,
          }
        : null,
    });
  }

  // 5. Enemies
  for (const es of levelDef.enemies) {
    const rig = buildEnemy3D(es.kind, textures.contactShadowMap);
    rig.group.position.set(es.x, es.y, es.z);
    worldGroup.add(rig.group);
    enemies.push({
      id: es.id,
      rig,
      origin: new THREE.Vector3(es.x, es.y, es.z),
      hp: es.hp,
      maxHp: es.hp,
      speed: es.speed,
      damage: es.damage,
      patrolRadius: es.patrolRadius,
      alive: true,
      koTimer: 0,
      attackCooldown: 0,
    });
  }

  // 6. Final Animated Portal at levelDef.portalPos
  const portal = buildPortal3D(levelDef.portalColor, levelDef.portalGlowColor);
  portal.group.position.set(levelDef.portalPos.x, levelDef.portalPos.y, levelDef.portalPos.z);
  worldGroup.add(portal.group);

  // 7. Animated Clouds
  const cloudsGroup = new THREE.Group();
  const cloudMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#F8FAFC',
      roughness: 0.95,
      transparent: true,
      opacity: 0.78,
    })
  );
  for (let i = 0; i < 12; i++) {
    const cg = new THREE.Group();
    const p1 = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(4.5, 8, 8)), cloudMat);
    const p2 = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(3.4, 8, 8)), cloudMat);
    p2.position.set(3.5, -0.4, 0.4);
    cg.add(p1, p2);
    cg.position.set(((i * 39) % 180) - 90, 56 + (i % 3) * 7, 15 - i * 16);
    cloudsGroup.add(cg);
  }
  worldGroup.add(cloudsGroup);

  const groundYAt = (_x: number, _z: number): number => {
    return levelDef.hasVoidPit ? -35 : 0;
  };

  const updateDynamicObjects = (elapsed: number, dt: number) => {
    for (const obs of obstacles) {
      const s = obs.spec;
      obs.prevX = obs.mesh.position.x;
      obs.prevY = obs.mesh.position.y;
      obs.prevZ = obs.mesh.position.z;

      const spd = s.speed || 1.5;
      const amp = s.amplitude || 4.0;
      const phase = s.phase || 0;
      const wave = Math.sin(elapsed * spd + phase);

      if (
        s.kind === 'moving_platform' ||
        s.kind === 'moving_wall' ||
        s.kind === 'sliding_block' ||
        s.kind === 'laser_gate' ||
        s.kind === 'electric_barrier' ||
        s.kind === 'timed_door'
      ) {
        const ax = s.axis || 'x';
        obs.mesh.position.set(
          s.x + (ax === 'x' ? wave * amp : 0),
          s.y + (ax === 'y' ? wave * amp : 0),
          s.z + (ax === 'z' ? wave * amp : 0)
        );
      } else if (s.kind === 'rotating_platform') {
        obs.mesh.rotation.y = elapsed * spd;
      } else if (s.kind === 'swinging_pendulum') {
        obs.mesh.position.x = s.x + Math.sin(elapsed * spd) * amp;
        obs.mesh.position.y = s.y - Math.cos(elapsed * spd) * 2.2;
      } else if (s.kind === 'falling_object') {
        const cycle = (elapsed * spd * 0.45) % 1;
        obs.mesh.position.y = s.y - cycle * cycle * amp;
      } else if (s.kind === 'collapsing_platform') {
        if (obs.respawnTimer > 0) {
          obs.respawnTimer -= dt;
          obs.mesh.visible = false;
          if (obs.collider) obs.collider.disabled = true;
          if (obs.respawnTimer <= 0) {
            obs.mesh.visible = true;
            obs.mesh.position.set(s.x, s.y, s.z);
            if (obs.collider) obs.collider.disabled = false;
          }
        } else if (obs.collapseTimer > 0) {
          obs.collapseTimer -= dt;
          obs.mesh.position.x = s.x + Math.sin(elapsed * 45) * 0.14;
          if (obs.collapseTimer <= 0) {
            obs.respawnTimer = 3.2;
            obs.mesh.visible = false;
            if (obs.collider) obs.collider.disabled = true;
          }
        }
      }

      obs.deltaX = obs.mesh.position.x - obs.prevX;
      obs.deltaY = obs.mesh.position.y - obs.prevY;
      obs.deltaZ = obs.mesh.position.z - obs.prevZ;

      if (obs.collider) {
        obs.collider.x = obs.mesh.position.x;
        obs.collider.y = obs.mesh.position.y - s.h * 0.5;
        obs.collider.z = obs.mesh.position.z;
      }
      if (obs.activeDangerBox) {
        obs.activeDangerBox.x = obs.mesh.position.x;
        obs.activeDangerBox.y = obs.mesh.position.y;
        obs.activeDangerBox.z = obs.mesh.position.z;
      }
    }
  };

  return {
    levelDef,
    worldGroup,
    colliders,
    raycastTargets,
    obstacles,
    enemies,
    orbs,
    portal,
    cloudsGroup,
    groundYAt,
    updateDynamicObjects,
    dispose: () => {
      portal.dispose();
      geos.forEach((g) => g.dispose());
      mats.forEach((m) => m.dispose());
    },
  };
}
