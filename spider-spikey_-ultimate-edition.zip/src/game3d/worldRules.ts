import { CityCollider, WebDirection } from '../types/spider3d';

export interface Vec3Like {
  x: number;
  y: number;
  z: number;
}

/**
 * Computes normalized 3D shoot direction vector for all 5 Web Directions:
 * 1: FORWARD, 2: BACKWARD, 3: LEFT, 4: RIGHT, 5: UPWARD
 * Relative to camera/character yaw.
 */
export function computeFiveDirectionVector(
  direction: WebDirection,
  yaw: number,
  pitch = 0
): Vec3Like {
  const forwardX = -Math.sin(yaw);
  const forwardZ = -Math.cos(yaw);
  const rightX = Math.cos(yaw);
  const rightZ = -Math.sin(yaw);

  let vx = 0;
  let vy = 0.16;
  let vz = 0;

  switch (direction) {
    case 'FORWARD': {
      const horiz = Math.cos(Math.max(-0.4, Math.min(0.65, pitch)));
      vx = forwardX * horiz;
      vy = Math.sin(Math.max(-0.25, Math.min(0.65, pitch))) + 0.38;
      vz = forwardZ * horiz;
      break;
    }
    case 'BACKWARD':
      vx = -forwardX;
      vy = 0.22;
      vz = -forwardZ;
      break;
    case 'LEFT':
      vx = -rightX;
      vy = 0.24;
      vz = -rightZ;
      break;
    case 'RIGHT':
      vx = rightX;
      vy = 0.24;
      vz = rightZ;
      break;
    case 'UPWARD':
      vx = forwardX * 0.22;
      vy = 0.98;
      vz = forwardZ * 0.22;
      break;
  }

  const len = Math.hypot(vx, vy, vz) || 1;
  return { x: vx / len, y: vy / len, z: vz / len };
}

/**
 * Resolves 3D cylinder/AABB player collisions against city buildings, roofs, bridges & rocks.
 * Keeps the player standing cleanly on rooftops/bridges and detects climbable walls.
 */
export function resolveCityCollision(
  pos: Vec3Like,
  vel: Vec3Like,
  radius: number,
  height: number,
  colliders: CityCollider[],
  groundYAt: (x: number, z: number) => number,
  dt: number
): {
  pos: Vec3Like;
  vel: Vec3Like;
  grounded: boolean;
  touchingClimbableWall: boolean;
  wallNormal: Vec3Like;
  standingColliderId: string | null;
  onSlipperySurface: boolean;
} {
  let nx = pos.x + vel.x * dt;
  let ny = pos.y + vel.y * dt;
  let nz = pos.z + vel.z * dt;
  let vx = vel.x;
  let vy = vel.y;
  let vz = vel.z;
  let grounded = false;
  let touchingClimbableWall = false;
  let standingColliderId: string | null = null;
  let onSlipperySurface = false;
  const wallNormal = { x: 0, y: 0, z: 0 };

  const groundH = groundYAt(nx, nz);
  if (ny <= groundH) {
    ny = groundH;
    if (vy < 0) vy = 0;
    grounded = true;
  }

  for (let i = 0; i < colliders.length; i++) {
    const c = colliders[i];
    if (c.disabled) continue;
    const halfW = c.w * 0.5 + radius;
    const halfD = c.d * 0.5 + radius;
    const dx = nx - c.x;
    const dz = nz - c.z;
    const topY = c.y + c.h;

    if (Math.abs(dx) >= halfW || Math.abs(dz) >= halfD) continue;
    if (ny >= topY + 0.05 || ny + height <= c.y) continue;

    // Check if landing on top surface (rooftop / bridge deck / moving platform)
    const prevFeetY = pos.y;
    if (prevFeetY >= topY - 0.75 && vy <= 0) {
      ny = topY;
      vy = 0;
      grounded = true;
      standingColliderId = c.id;
      onSlipperySurface = Boolean(c.slippery);
      continue;
    }

    // Check head bump
    if (pos.y + height <= c.y + 0.45 && vy > 0) {
      ny = c.y - height;
      vy = 0;
      continue;
    }

    // Horizontal push-out along minimum penetration axis
    const overlapX = halfW - Math.abs(dx);
    const overlapZ = halfD - Math.abs(dz);
    if (overlapX < overlapZ) {
      const sign = dx >= 0 ? 1 : -1;
      nx = c.x + sign * halfW;
      vx = 0;
      if (c.climbable !== false) {
        touchingClimbableWall = true;
        wallNormal.x = sign;
        wallNormal.z = 0;
      }
    } else {
      const sign = dz >= 0 ? 1 : -1;
      nz = c.z + sign * halfD;
      vz = 0;
      if (c.climbable !== false) {
        touchingClimbableWall = true;
        wallNormal.x = 0;
        wallNormal.z = sign;
      }
    }
  }

  return {
    pos: { x: nx, y: ny, z: nz },
    vel: { x: vx, y: vy, z: vz },
    grounded,
    touchingClimbableWall,
    wallNormal,
    standingColliderId,
    onSlipperySurface,
  };
}

export function checkPortalTrigger(
  playerPos: Vec3Like,
  portalPos: Vec3Like,
  triggerRadius = 3.2
): boolean {
  const dx = playerPos.x - portalPos.x;
  const dz = playerPos.z - portalPos.z;
  const dy = Math.abs(playerPos.y + 1.0 - (portalPos.y + 2.2));
  return Math.hypot(dx, dz) <= triggerRadius && dy <= 3.8;
}

/**
 * Computes the superhero aerial launch boost when releasing a taut web mid-swing.
 * Converts swing tangential velocity into an exhilarating Spider-Man launch arc.
 */
export function computeWebReleaseBoost(
  vel: Vec3Like,
  yaw: number,
  speedMult = 1.0
): Vec3Like {
  const fX = -Math.sin(yaw);
  const fZ = -Math.cos(yaw);
  const horizSpeed = Math.hypot(vel.x, vel.z);
  const forwardBoost = Math.max(8.5, horizSpeed * 0.28 + 5.0) * speedMult;
  return {
    x: vel.x * 1.12 + fX * forwardBoost,
    y: Math.max(vel.y + 6.5, 12.2),
    z: vel.z * 1.12 + fZ * forwardBoost,
  };
}

/**
 * Finds an elevated skyscraper/building/pillar anchor inside the 5-direction aiming cone
 * when a thin center ray travels down an open avenue without intersecting a facade directly.
 * Never attaches to flat ground below the player.
 */
export function findSkyscraperWebAnchor(
  origin: Vec3Like,
  aimDir: Vec3Like,
  colliders: CityCollider[],
  maxRange = 95
): Vec3Like | null {
  let bestScore = Infinity;
  let bestPoint: Vec3Like | null = null;

  for (let i = 0; i < colliders.length; i++) {
    const c = colliders[i];
    if (c.disabled) continue;
    const topY = c.y + c.h;
    // Only latch onto tall skyscrapers, towers, bridges or elevated platforms
    if (topY < Math.max(5.5, origin.y - 1.5)) continue;

    // Pick nearest facade point facing the player along the structure perimeter
    const clampedX = Math.max(c.x - c.w * 0.5, Math.min(c.x + c.w * 0.5, origin.x));
    const clampedZ = Math.max(c.z - c.d * 0.5, Math.min(c.z + c.d * 0.5, origin.z));
    const horizDist = Math.hypot(clampedX - origin.x, clampedZ - origin.z);
    const desiredRise =
      aimDir.y > 0.75
        ? 26
        : Math.max(6.5, horizDist * Math.max(0.34, aimDir.y + 0.28));
    const minAnchorY = Math.min(topY - 0.8, Math.max(4.5, origin.y + 4.0));
    const anchorY = Math.min(topY - 0.8, Math.max(minAnchorY, origin.y + desiredRise));

    const dx = clampedX - origin.x;
    const dy = anchorY - origin.y;
    const dz = clampedZ - origin.z;
    const dist = Math.hypot(dx, dy, dz);
    if (dist < 4 || dist > maxRange) continue;

    const dot = (dx * aimDir.x + dy * aimDir.y + dz * aimDir.z) / dist;
    if (dot < 0.55) continue;

    // Prefer tight directional alignment and comfortable swinging distance (~16-48m)
    const idealDistPenalty = Math.abs(dist - 24) * 0.015;
    const score = (1 - dot) * 3.0 + idealDistPenalty;
    if (score < bestScore) {
      bestScore = score;
      bestPoint = { x: clampedX, y: anchorY, z: clampedZ };
    }
  }

  return bestPoint;
}

/**
 * Aerodynamic Spider-Man flight & web-wings glide physics when airborne.
 * Supports diving to gain speed, holding glide for sustained forward soaring,
 * and responsive mid-air carving/banking.
 */
export function stepAirFlightPhysics(
  vel: Vec3Like,
  wishDir: Vec3Like,
  wishMag: number,
  yaw: number,
  baseSpeed: number,
  glideHeld: boolean,
  boostHeld: boolean,
  hasLaunchMomentum: boolean,
  dt: number
): Vec3Like {
  let vx = vel.x;
  let vy = vel.y;
  let vz = vel.z;

  const horizSpd = Math.hypot(vx, vz);
  const isGliding = glideHeld || (hasLaunchMomentum && horizSpd > 14.5);

  // Horizontal air steering & thrust
  const forwardX = -Math.sin(yaw);
  const forwardZ = -Math.cos(yaw);
  const steerX = wishMag > 0.05 ? wishDir.x : isGliding ? forwardX : 0;
  const steerZ = wishMag > 0.05 ? wishDir.z : isGliding ? forwardZ : 0;
  const steerLen = Math.hypot(steerX, steerZ);

  if (steerLen > 0.01) {
    const targetCruise = Math.max(
      baseSpeed * (boostHeld ? 1.45 : 1.05),
      horizSpd * (isGliding ? 0.996 : 0.96)
    );
    const maxFlightSpeed = boostHeld ? 44 : 36;
    const desiredSpeed = Math.min(maxFlightSpeed, targetCruise + (isGliding ? 6.5 * dt : 0));
    const turnRate = isGliding ? 4.4 : 5.8;
    const blend = Math.min(1, turnRate * dt);
    vx = vx + ((steerX / steerLen) * desiredSpeed - vx) * blend;
    vz = vz + ((steerZ / steerLen) * desiredSpeed - vz) * blend;
  } else {
    const coastDamp = Math.max(0, 1 - 0.18 * dt);
    vx *= coastDamp;
    vz *= coastDamp;
  }

  // Aerodynamic gravity & lift: faster horizontal speed generates upward Web-Wings lift!
  const newHorizSpd = Math.hypot(vx, vz);
  if (glideHeld && newHorizSpd > 9) {
    const liftRatio = Math.min(0.84, (newHorizSpd / 28) * 0.78);
    const netGravity = 26 * (1 - liftRatio);
    vy -= netGravity * dt;
    // Gentle floor on sink rate while gliding smoothly
    if (vy < -5.8) {
      vy = vy + (-5.8 - vy) * Math.min(1, 5 * dt);
    }
    // Slight pitch boost if boosting while airborne
    if (boostHeld && vy < 1.5) {
      vy += 6.2 * dt;
    }
  } else {
    vy -= (hasLaunchMomentum ? 23.5 : 27.5) * dt;
  }

  return { x: vx, y: vy, z: vz };
}

/**
 * True 3D pendulum web swinging + tension + momentum pump + reel-in pull physics.
 */
export function stepWebSwingPhysics(
  pos: Vec3Like,
  vel: Vec3Like,
  anchor: Vec3Like,
  ropeLength: number,
  wishDir: Vec3Like,
  pullActive: boolean,
  swingBoostMult: number,
  dt: number
): {
  pos: Vec3Like;
  vel: Vec3Like;
  ropeLength: number;
} {
  let nextRope = ropeLength;
  if (pullActive) {
    nextRope = Math.max(3.2, ropeLength - 22 * swingBoostMult * dt);
  }

  // Gravity & directional swing pump
  let vx = vel.x + wishDir.x * 34 * swingBoostMult * dt;
  let vy = vel.y - 23.5 * dt; // 3D gravity
  let vz = vel.z + wishDir.z * 34 * swingBoostMult * dt;

  // Mild quadratic air resistance (caps runaway velocity while keeping high speed thrilling)
  const spd = Math.hypot(vx, vy, vz);
  if (spd > 1) {
    const drag = Math.min(0.32, 0.004 * spd) * dt;
    vx *= 1 - drag;
    vy *= 1 - drag * 0.45;
    vz *= 1 - drag;
  }

  // Pull acceleration toward anchor when reeling in
  const dx0 = anchor.x - pos.x;
  const dy0 = anchor.y - (pos.y + 1.2);
  const dz0 = anchor.z - pos.z;
  const dist0 = Math.hypot(dx0, dy0, dz0) || 1;
  if (pullActive) {
    const pullAccel = 42 * swingBoostMult;
    vx += (dx0 / dist0) * pullAccel * dt;
    vy += (dy0 / dist0) * pullAccel * dt;
    vz += (dz0 / dist0) * pullAccel * dt;
  }

  let nx = pos.x + vx * dt;
  let ny = pos.y + vy * dt;
  let nz = pos.z + vz * dt;

  // Rope constraint when taut (preserves tangential swing speed & converts drop into forward arc)
  const rx = nx - anchor.x;
  const ry = ny + 1.2 - anchor.y;
  const rz = nz - anchor.z;
  const dist = Math.hypot(rx, ry, rz) || 0.001;
  if (dist > nextRope) {
    const dirX = rx / dist;
    const dirY = ry / dist;
    const dirZ = rz / dist;
    nx = anchor.x + dirX * nextRope;
    ny = anchor.y + dirY * nextRope - 1.2;
    nz = anchor.z + dirZ * nextRope;

    const radialVel = vx * dirX + vy * dirY + vz * dirZ;
    if (radialVel > 0) {
      vx -= radialVel * dirX;
      vy -= radialVel * dirY;
      vz -= radialVel * dirZ;
    }
    // Pendulum arc pump when swinging near the bottom of the arc to build exciting momentum
    if (dirY < -0.18 && (Math.abs(vx) + Math.abs(vz) > 1.5)) {
      const pump = 1 + Math.min(0.09, 0.78 * dt * swingBoostMult);
      vx *= pump;
      vz *= pump;
    }
  }

  return {
    pos: { x: nx, y: ny, z: nz },
    vel: { x: vx, y: vy, z: vz },
    ropeLength: nextRope,
  };
}

export function shouldTriggerBossAfterMatch(matchesCompleted: number): boolean {
  return matchesCompleted > 0 && matchesCompleted % 5 === 0;
}

export function getBossIndexForMatches(matchesCompleted: number, bossCount: number): number {
  if (bossCount <= 0) return 0;
  const cycle = Math.max(0, Math.floor((Math.max(1, matchesCompleted) - 1) / 5));
  return cycle % bossCount;
}
