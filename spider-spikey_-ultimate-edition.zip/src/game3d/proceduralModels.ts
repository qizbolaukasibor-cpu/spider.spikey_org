import * as THREE from 'three';
import { BossDef, EnemyKind, SeasonTheme, SkinDef, SpiderAnimState } from '../types/spider3d';

export interface ProceduralTextureSet {
  skyscraperWindowMap: THREE.CanvasTexture;
  roadAsphaltMap: THREE.CanvasTexture;
  contactShadowMap: THREE.CanvasTexture;
  groundDetailMap: THREE.CanvasTexture;
  dispose: () => void;
}

export function createProceduralTextures(maxAnisotropy: number): ProceduralTextureSet {
  // 1. Skyscraper Illuminated Window Grid
  const winCanvas = document.createElement('canvas');
  winCanvas.width = 256;
  winCanvas.height = 512;
  const wCtx = winCanvas.getContext('2d')!;
  wCtx.fillStyle = '#0F172A';
  wCtx.fillRect(0, 0, 256, 512);
  for (let y = 12; y < 500; y += 26) {
    for (let x = 14; x < 242; x += 28) {
      const lit = ((x * 13 + y * 7) % 11) > 2;
      wCtx.fillStyle = lit
        ? (x + y) % 5 === 0
          ? '#FDE68A'
          : '#7DD3FC'
        : '#1E293B';
      wCtx.fillRect(x, y, 16, 16);
    }
  }
  const skyscraperWindowMap = new THREE.CanvasTexture(winCanvas);
  skyscraperWindowMap.colorSpace = THREE.SRGBColorSpace;
  skyscraperWindowMap.wrapS = THREE.RepeatWrapping;
  skyscraperWindowMap.wrapT = THREE.RepeatWrapping;
  skyscraperWindowMap.anisotropy = maxAnisotropy;

  // 2. Road Asphalt + Lane Striping
  const roadCanvas = document.createElement('canvas');
  roadCanvas.width = 256;
  roadCanvas.height = 256;
  const rCtx = roadCanvas.getContext('2d')!;
  rCtx.fillStyle = '#18202C';
  rCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 650; i++) {
    const rx = (i * 73) % 256;
    const ry = (i * 139) % 256;
    rCtx.fillStyle = i % 2 === 0 ? '#1E293B' : '#111827';
    rCtx.fillRect(rx, ry, 2, 2);
  }
  rCtx.fillStyle = '#F59E0B';
  rCtx.fillRect(124, 0, 8, 256);
  rCtx.fillStyle = '#E2E8F0';
  rCtx.fillRect(10, 0, 6, 256);
  rCtx.fillRect(240, 0, 6, 256);
  const roadAsphaltMap = new THREE.CanvasTexture(roadCanvas);
  roadAsphaltMap.colorSpace = THREE.SRGBColorSpace;
  roadAsphaltMap.wrapS = THREE.RepeatWrapping;
  roadAsphaltMap.wrapT = THREE.RepeatWrapping;
  roadAsphaltMap.repeat.set(1, 16);
  roadAsphaltMap.anisotropy = maxAnisotropy;

  // 3. Soft Radial Contact Shadow Disc
  const shCanvas = document.createElement('canvas');
  shCanvas.width = 128;
  shCanvas.height = 128;
  const sCtx = shCanvas.getContext('2d')!;
  const grad = sCtx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.72)');
  grad.addColorStop(0.6, 'rgba(0, 0, 0, 0.28)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  sCtx.fillStyle = grad;
  sCtx.fillRect(0, 0, 128, 128);
  const contactShadowMap = new THREE.CanvasTexture(shCanvas);
  contactShadowMap.colorSpace = THREE.SRGBColorSpace;

  // 4. Subtle Ground Detail Tile (balanced mid-tone so snow/turf never washes out highlights)
  const gCanvas = document.createElement('canvas');
  gCanvas.width = 256;
  gCanvas.height = 256;
  const gCtx = gCanvas.getContext('2d')!;
  gCtx.fillStyle = '#B8C4D4';
  gCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 400; i++) {
    const gx = (i * 61) % 256;
    const gy = (i * 97) % 256;
    gCtx.fillStyle = i % 3 === 0 ? '#94A3B8' : '#CBD5E1';
    gCtx.fillRect(gx, gy, 6, 6);
  }
  const groundDetailMap = new THREE.CanvasTexture(gCanvas);
  groundDetailMap.colorSpace = THREE.SRGBColorSpace;
  groundDetailMap.wrapS = THREE.RepeatWrapping;
  groundDetailMap.wrapT = THREE.RepeatWrapping;
  groundDetailMap.repeat.set(28, 28);
  groundDetailMap.anisotropy = maxAnisotropy;

  return {
    skyscraperWindowMap,
    roadAsphaltMap,
    contactShadowMap,
    groundDetailMap,
    dispose: () => {
      skyscraperWindowMap.dispose();
      roadAsphaltMap.dispose();
      contactShadowMap.dispose();
      groundDetailMap.dispose();
    },
  };
}

export function createSkyDomeTexture(
  zenithColor: THREE.ColorRepresentation = '#0B1B3B',
  midColor: THREE.ColorRepresentation = '#1E40AF',
  horizonColor: THREE.ColorRepresentation = '#F59E0B'
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 16;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0.0, new THREE.Color(zenithColor).getStyle());
  grad.addColorStop(0.45, new THREE.Color(midColor).getStyle());
  grad.addColorStop(0.76, new THREE.Color(horizonColor).getStyle());
  grad.addColorStop(1.0, '#0F172A');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 16, 256);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export interface SpiderRig3D {
  root: THREE.Group;
  bodyPivot: THREE.Group;
  torso: THREE.Mesh;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  backSpiderLegs: THREE.Group[];
  shieldMesh: THREE.Mesh;
  auraRing: THREE.Mesh;
  contactShadow: THREE.Mesh;
  updateSkin: (skin: SkinDef) => void;
  animate: (
    state: SpiderAnimState,
    time: number,
    dt: number,
    speedNorm: number,
    shieldActive: boolean,
    shadowCloak: boolean
  ) => void;
}

interface MilesTextureBundle {
  suitMap: THREE.CanvasTexture;
  maskMap: THREE.CanvasTexture;
  limbMap: THREE.CanvasTexture;
  spiderEmblemMap: THREE.CanvasTexture;
}

let cachedMilesTextures: MilesTextureBundle | null = null;

function getMilesMoralesTextures(): MilesTextureBundle {
  if (cachedMilesTextures) return cachedMilesTextures;

  // 1. Detailed carbon-weave black fabric texture
  const suitCanvas = document.createElement('canvas');
  suitCanvas.width = 256;
  suitCanvas.height = 256;
  const sCtx = suitCanvas.getContext('2d')!;
  sCtx.fillStyle = '#0B0D14';
  sCtx.fillRect(0, 0, 256, 256);
  // Micro honeycomb/carbon weave
  for (let y = 0; y < 256; y += 8) {
    for (let x = 0; x < 256; x += 8) {
      sCtx.fillStyle = ((x + y) / 8) % 2 === 0 ? '#121622' : '#090B11';
      sCtx.fillRect(x, y, 4, 4);
    }
  }
  // Crimson suit shoulder & side seam lines
  sCtx.strokeStyle = '#DC2626';
  sCtx.lineWidth = 5;
  sCtx.strokeRect(6, 6, 244, 244);
  sCtx.lineWidth = 2;
  for (let r = 32; r < 224; r += 36) {
    sCtx.beginPath();
    sCtx.moveTo(0, r);
    sCtx.lineTo(256, r + 14);
    sCtx.stroke();
  }
  const suitMap = new THREE.CanvasTexture(suitCanvas);
  suitMap.colorSpace = THREE.SRGBColorSpace;

  // 2. Mask texture with bright crimson web pattern across brow and cheeks
  const maskCanvas = document.createElement('canvas');
  maskCanvas.width = 256;
  maskCanvas.height = 256;
  const mCtx = maskCanvas.getContext('2d')!;
  mCtx.fillStyle = '#090B10';
  mCtx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 6) {
    for (let x = 0; x < 256; x += 6) {
      if (((x + y) / 6) % 2 === 0) {
        mCtx.fillStyle = '#111520';
        mCtx.fillRect(x, y, 3, 3);
      }
    }
  }
  mCtx.strokeStyle = '#EF4444';
  mCtx.lineWidth = 2.6;
  const cx = 128;
  const cy = 128;
  for (let a = 0; a < 14; a++) {
    const ang = (a / 14) * Math.PI * 2;
    mCtx.beginPath();
    mCtx.moveTo(cx, cy);
    mCtx.lineTo(cx + Math.cos(ang) * 140, cy + Math.sin(ang) * 140);
    mCtx.stroke();
  }
  for (let rad = 26; rad <= 122; rad += 24) {
    mCtx.beginPath();
    mCtx.arc(cx, cy, rad, 0, Math.PI * 2);
    mCtx.stroke();
  }
  const maskMap = new THREE.CanvasTexture(maskCanvas);
  maskMap.colorSpace = THREE.SRGBColorSpace;

  // 3. Arms & gloves black fabric with crimson red webbing & racing stripe
  const limbCanvas = document.createElement('canvas');
  limbCanvas.width = 256;
  limbCanvas.height = 256;
  const lCtx = limbCanvas.getContext('2d')!;
  lCtx.fillStyle = '#0C0E16';
  lCtx.fillRect(0, 0, 256, 256);
  lCtx.fillStyle = '#991B1B';
  lCtx.fillRect(0, 185, 256, 71);
  lCtx.strokeStyle = '#EF4444';
  lCtx.lineWidth = 3;
  for (let x = 0; x <= 256; x += 32) {
    lCtx.beginPath();
    lCtx.moveTo(x, 0);
    lCtx.lineTo(x, 256);
    lCtx.stroke();
  }
  for (let y = 24; y <= 240; y += 36) {
    lCtx.beginPath();
    lCtx.moveTo(0, y);
    lCtx.lineTo(256, y);
    lCtx.stroke();
  }
  const limbMap = new THREE.CanvasTexture(limbCanvas);
  limbMap.colorSpace = THREE.SRGBColorSpace;

  // 4. Stylized Spray-Paint Crimson Spider Symbol for Chest & Back
  const embCanvas = document.createElement('canvas');
  embCanvas.width = 256;
  embCanvas.height = 256;
  const eCtx = embCanvas.getContext('2d')!;
  eCtx.clearRect(0, 0, 256, 256);
  eCtx.fillStyle = '#FF2442';
  eCtx.strokeStyle = '#FF2442';
  eCtx.lineWidth = 13;
  eCtx.lineCap = 'round';
  eCtx.lineJoin = 'round';
  // Spider abdomen & thorax
  eCtx.beginPath();
  eCtx.ellipse(128, 140, 22, 34, 0, 0, Math.PI * 2);
  eCtx.fill();
  eCtx.beginPath();
  eCtx.ellipse(128, 98, 16, 18, 0, 0, Math.PI * 2);
  eCtx.fill();
  // 8 jagged spider legs
  const legPairs = [
    [-22, -26, -68, -72, -88, -110],
    [-24, -12, -84, -36, -108, -78],
    [-24, 6, -86, 28, -106, 86],
    [-18, 22, -62, 62, -74, 114],
  ];
  for (const [x1, y1, x2, y2, x3, y3] of legPairs) {
    // Left
    eCtx.beginPath();
    eCtx.moveTo(128 + x1, 120 + y1);
    eCtx.lineTo(128 + x2, 120 + y2);
    eCtx.lineTo(128 + x3, 120 + y3);
    eCtx.stroke();
    // Right
    eCtx.beginPath();
    eCtx.moveTo(128 - x1, 120 + y1);
    eCtx.lineTo(128 - x2, 120 + y2);
    eCtx.lineTo(128 - x3, 120 + y3);
    eCtx.stroke();
  }
  const spiderEmblemMap = new THREE.CanvasTexture(embCanvas);
  spiderEmblemMap.colorSpace = THREE.SRGBColorSpace;

  cachedMilesTextures = { suitMap, maskMap, limbMap, spiderEmblemMap };
  return cachedMilesTextures;
}

export function buildSpiderCharacter3D(
  initialSkin: SkinDef,
  shadowMapTex: THREE.CanvasTexture
): SpiderRig3D {
  const root = new THREE.Group();
  const bodyPivot = new THREE.Group();
  root.add(bodyPivot);
  const milesTex = getMilesMoralesTextures();

  const primaryMat = new THREE.MeshStandardMaterial({
    color: initialSkin.primaryColor,
    metalness: initialSkin.metalness,
    roughness: initialSkin.roughness,
  });
  const secondaryMat = new THREE.MeshStandardMaterial({
    color: initialSkin.secondaryColor,
    metalness: Math.min(0.9, initialSkin.metalness + 0.1),
    roughness: Math.min(0.95, initialSkin.roughness + 0.25),
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: initialSkin.accentColor,
    emissive: initialSkin.emissiveColor,
    emissiveIntensity: 0.7,
    metalness: 0.6,
    roughness: 0.2,
  });
  const milesMaskMat = new THREE.MeshStandardMaterial({
    color: '#FFFFFF',
    map: milesTex.maskMap,
    metalness: 0.22,
    roughness: 0.52,
  });
  const milesLimbMat = new THREE.MeshStandardMaterial({
    color: '#FFFFFF',
    map: milesTex.limbMap,
    metalness: 0.25,
    roughness: 0.5,
  });

  // Contact shadow disc grounded at y = 0.02
  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(1.7, 1.7),
    new THREE.MeshBasicMaterial({
      map: shadowMapTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.55,
    })
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.02;
  root.add(contactShadow);

  // Pelvis & Utility Web Belt
  const pelvis = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.26, 0.36), secondaryMat);
  pelvis.position.y = 0.92;
  pelvis.castShadow = true;
  bodyPivot.add(pelvis);

  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.08, 0.39), accentMat);
  belt.position.y = 1.04;
  bodyPivot.add(belt);

  // Torso (sculpted taper + chest armor plates)
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.68, 0.42), primaryMat);
  torso.position.y = 1.38;
  torso.castShadow = true;
  bodyPivot.add(torso);

  const chestPlate = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.34, 0.45), secondaryMat);
  chestPlate.position.y = 1.48;
  bodyPivot.add(chestPlate);

  // Shoulder pauldrons
  const lPauldron = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 10), secondaryMat);
  lPauldron.position.set(-0.4, 1.62, 0);
  bodyPivot.add(lPauldron);
  const rPauldron = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 10), secondaryMat);
  rPauldron.position.set(0.4, 1.62, 0);
  bodyPivot.add(rPauldron);

  // Chest Spider Emblem (standard faceted gem + Miles spray-painted crimson Chest/Back spider badge)
  const emblem = new THREE.Mesh(new THREE.OctahedronGeometry(0.13, 0), accentMat);
  emblem.scale.set(1, 1.25, 0.4);
  emblem.position.set(0, 1.44, -0.24);
  bodyPivot.add(emblem);

  const milesEmblemMat = new THREE.MeshBasicMaterial({
    map: milesTex.spiderEmblemMap,
    transparent: true,
    depthWrite: false,
  });
  const milesFrontEmblem = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.46), milesEmblemMat);
  milesFrontEmblem.position.set(0, 1.44, -0.245);
  milesFrontEmblem.rotation.y = Math.PI;
  const milesBackEmblem = new THREE.Mesh(new THREE.PlaneGeometry(0.44, 0.44), milesEmblemMat);
  milesBackEmblem.position.set(0, 1.44, 0.245);
  milesFrontEmblem.visible = false;
  milesBackEmblem.visible = false;
  bodyPivot.add(milesFrontEmblem, milesBackEmblem);

  // Head + Goggles (Standard + Expressive Miles Morales Large White Lenses with Red Trim)
  const head = new THREE.Group();
  head.position.set(0, 1.92, 0);
  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.27, 16, 14), primaryMat);
  cranium.scale.set(0.92, 1.05, 0.98);
  cranium.castShadow = true;
  head.add(cranium);

  const eyeGeo = new THREE.BoxGeometry(0.14, 0.08, 0.07);
  const eyeL = new THREE.Mesh(eyeGeo, accentMat);
  eyeL.position.set(-0.11, 0.03, -0.23);
  eyeL.rotation.z = -0.25;
  eyeL.rotation.y = 0.2;
  const eyeR = new THREE.Mesh(eyeGeo, accentMat);
  eyeR.position.set(0.11, 0.03, -0.23);
  eyeR.rotation.z = 0.25;
  eyeR.rotation.y = -0.2;
  head.add(eyeL, eyeR);

  // Expressive oversized white Spider-Eyes with red mask rims for Miles Morales
  const milesEyesGroup = new THREE.Group();
  const whiteLensMat = new THREE.MeshBasicMaterial({ color: '#FFFFFF' });
  const redRimMat = new THREE.MeshBasicMaterial({ color: '#EF4444' });
  for (const side of [-1, 1] as const) {
    const eyePivot = new THREE.Group();
    eyePivot.position.set(side * 0.105, 0.035, -0.235);
    eyePivot.rotation.z = side * 0.34;
    eyePivot.rotation.y = -side * 0.26;
    const rim = new THREE.Mesh(new THREE.BoxGeometry(0.175, 0.125, 0.045), redRimMat);
    const lens = new THREE.Mesh(new THREE.BoxGeometry(0.142, 0.095, 0.055), whiteLensMat);
    lens.position.z = -0.008;
    eyePivot.add(rim, lens);
    milesEyesGroup.add(eyePivot);
  }
  milesEyesGroup.visible = false;
  head.add(milesEyesGroup);
  bodyPivot.add(head);

  // Arms + Web-Shooter Cuffs + Red-Tipped Webbed Fingers (Miles variant)
  const armMeshList: THREE.Mesh[] = [];
  const milesHandGroups: THREE.Group[] = [];
  const makeArm = (side: -1 | 1) => {
    const pivot = new THREE.Group();
    pivot.position.set(side * 0.44, 1.62, 0);
    const upper = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.09, 0.42, 10), primaryMat);
    upper.position.y = -0.21;
    upper.castShadow = true;
    armMeshList.push(upper);
    const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.14, 10), accentMat);
    cuff.position.y = -0.45;
    const fist = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 10), secondaryMat);
    fist.position.y = -0.56;

    // Articulated webbed glove fingers for Miles Morales
    const handGroup = new THREE.Group();
    handGroup.position.set(0, -0.58, 0);
    const gloveRed = new THREE.MeshBasicMaterial({ color: '#EF4444' });
    const gloveBlack = new THREE.MeshStandardMaterial({ color: '#0B0D14', roughness: 0.45 });
    for (let f = 0; f < 4; f++) {
      const fx = (f - 1.5) * 0.036;
      const knuckle = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.065, 0.028), gloveBlack);
      knuckle.position.set(fx, -0.04, -0.01);
      const tip = new THREE.Mesh(new THREE.BoxGeometry(0.026, 0.045, 0.026), gloveRed);
      tip.position.set(fx, -0.088, -0.015);
      handGroup.add(knuckle, tip);
    }
    handGroup.visible = false;
    milesHandGroups.push(handGroup);

    pivot.add(upper, cuff, fist, handGroup);
    return pivot;
  };
  const leftArm = makeArm(-1);
  const rightArm = makeArm(1);
  bodyPivot.add(leftArm, rightArm);

  // Legs + Knee Pads + Boots / High-Top Black & Red Sneakers (Miles variant)
  const classicBoots: THREE.Mesh[] = [];
  const sneakerGroups: THREE.Group[] = [];
  const legMeshList: THREE.Mesh[] = [];
  const makeLeg = (side: -1 | 1) => {
    const pivot = new THREE.Group();
    pivot.position.set(side * 0.18, 0.85, 0);
    const thigh = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.1, 0.44, 10), secondaryMat);
    thigh.position.y = -0.22;
    thigh.castShadow = true;
    legMeshList.push(thigh);
    const knee = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 8), accentMat);
    knee.position.set(0, -0.44, -0.05);
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.42, 0.28), primaryMat);
    boot.position.set(0, -0.62, -0.02);
    boot.castShadow = true;
    classicBoots.push(boot);

    // High-top Black & Red Sneakers with white rubber sole
    const sneaker = new THREE.Group();
    sneaker.position.set(0, -0.61, -0.035);
    const blackShoeMat = new THREE.MeshStandardMaterial({ color: '#0F111A', roughness: 0.45 });
    const redShoeMat = new THREE.MeshStandardMaterial({ color: '#DC2626', roughness: 0.35 });
    const whiteSoleMat = new THREE.MeshStandardMaterial({ color: '#F8FAFC', roughness: 0.28 });
    const upperHi = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.27, 0.27), blackShoeMat);
    upperHi.position.set(0, 0.02, 0.02);
    const collar = new THREE.Mesh(new THREE.BoxGeometry(0.255, 0.095, 0.285), redShoeMat);
    collar.position.set(0, 0.14, 0.02);
    const heelRed = new THREE.Mesh(new THREE.BoxGeometry(0.245, 0.14, 0.09), redShoeMat);
    heelRed.position.set(0, -0.04, 0.115);
    const toeBox = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.13, 0.16), redShoeMat);
    toeBox.position.set(0, -0.05, -0.11);
    const sole = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.075, 0.38), whiteSoleMat);
    sole.position.set(0, -0.13, -0.025);
    sneaker.add(upperHi, collar, heelRed, toeBox, sole);
    sneaker.visible = false;
    sneakerGroups.push(sneaker);

    pivot.add(thigh, knee, boot, sneaker);
    return pivot;
  };
  const leftLeg = makeLeg(-1);
  const rightLeg = makeLeg(1);
  bodyPivot.add(leftLeg, rightLeg);

  // Back Spider Pack + 4 Articulated Mechanical Spider Legs
  const pack = new THREE.Mesh(new THREE.OctahedronGeometry(0.22, 0), secondaryMat);
  pack.position.set(0, 1.44, 0.25);
  pack.scale.set(1.1, 1.2, 0.65);
  bodyPivot.add(pack);

  const backSpiderLegs: THREE.Group[] = [];
  for (let i = 0; i < 4; i++) {
    const side = i % 2 === 0 ? -1 : 1;
    const upper = i < 2 ? 1 : -1;
    const legRoot = new THREE.Group();
    legRoot.position.set(side * 0.15, 1.45 + upper * 0.12, 0.25);
    const seg1 = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.03, 0.55, 8), secondaryMat);
    seg1.rotation.z = side * -0.9;
    seg1.rotation.x = upper * 0.35;
    seg1.position.set(side * 0.22, upper * 0.18, 0.14);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.48, 8), accentMat);
    tip.rotation.z = side * -2.2;
    tip.position.set(side * 0.52, upper * 0.12, 0.18);
    legRoot.add(seg1, tip);
    bodyPivot.add(legRoot);
    backSpiderLegs.push(legRoot);
  }

  // Deployable translucent Web-Wings (visible during Spider Flight / Glide)
  const webWings = new THREE.Group();
  const wingShape = new THREE.Shape();
  wingShape.moveTo(0, 0.08);
  wingShape.lineTo(0.88, 0.36);
  wingShape.lineTo(0.18, -0.58);
  wingShape.closePath();
  const wingGeo = new THREE.ShapeGeometry(wingShape);
  const wingMat = new THREE.MeshBasicMaterial({
    color: '#E0F2FE',
    transparent: true,
    opacity: 0.65,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const rightWing = new THREE.Mesh(wingGeo, wingMat);
  rightWing.position.set(0.28, 1.46, 0.08);
  const leftWing = new THREE.Mesh(wingGeo, wingMat);
  leftWing.scale.x = -1;
  leftWing.position.set(-0.28, 1.46, 0.08);
  webWings.add(leftWing, rightWing);
  webWings.visible = false;
  bodyPivot.add(webWings);

  // Venom Bio-Electricity Red & Purple Lightning Arcs (Miles Morales Exclusive Aura)
  const venomArcsGroup = new THREE.Group();
  const venomRedMat = new THREE.MeshBasicMaterial({
    color: '#FF2E4D',
    transparent: true,
    opacity: 0.92,
  });
  const venomPurpleMat = new THREE.MeshBasicMaterial({
    color: '#A855F7',
    transparent: true,
    opacity: 0.92,
  });
  const venomArcs: THREE.Mesh[] = [];
  for (let i = 0; i < 6; i++) {
    const arc = new THREE.Mesh(
      new THREE.TorusGeometry(0.28 + (i % 3) * 0.14, 0.016, 6, 16, Math.PI * 1.1),
      i % 2 === 0 ? venomRedMat : venomPurpleMat
    );
    arc.position.set(
      (i % 2 === 0 ? -1 : 1) * (0.28 + (i % 2) * 0.18),
      1.25 + (i % 3) * 0.22,
      (i % 2 === 0 ? -0.15 : 0.15)
    );
    venomArcsGroup.add(arc);
    venomArcs.push(arc);
  }
  venomArcsGroup.visible = false;
  bodyPivot.add(venomArcsGroup);

  // Web Shield translucent dome
  const shieldMesh = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.45, 1),
    new THREE.MeshBasicMaterial({
      color: '#2DD4BF',
      wireframe: true,
      transparent: true,
      opacity: 0.42,
    })
  );
  shieldMesh.position.y = 1.25;
  shieldMesh.visible = false;
  root.add(shieldMesh);

  // Skin/Ult Aura ring on ground
  const auraRing = new THREE.Mesh(
    new THREE.RingGeometry(0.85, 1.05, 32),
    new THREE.MeshBasicMaterial({
      color: initialSkin.emissiveColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    })
  );
  auraRing.rotation.x = -Math.PI / 2;
  auraRing.position.y = 0.04;
  root.add(auraRing);

  let isMilesActive = initialSkin.variant === 'miles_morales';

  const updateSkin = (skin: SkinDef) => {
    isMilesActive = skin.variant === 'miles_morales';
    primaryMat.color.set(skin.primaryColor);
    primaryMat.metalness = skin.metalness;
    primaryMat.roughness = skin.roughness;
    primaryMat.map = isMilesActive ? milesTex.suitMap : null;
    primaryMat.needsUpdate = true;

    secondaryMat.color.set(skin.secondaryColor);
    accentMat.color.set(skin.accentColor);
    accentMat.emissive.set(skin.emissiveColor);
    (auraRing.material as THREE.MeshBasicMaterial).color.set(skin.emissiveColor);
    auraRing.visible = skin.rarity !== 'COMMON';

    // Toggle Miles Morales structural details cleanly
    cranium.material = isMilesActive ? milesMaskMat : primaryMat;
    for (const am of armMeshList) {
      am.material = isMilesActive ? milesLimbMat : primaryMat;
    }
    for (const hg of milesHandGroups) {
      hg.visible = isMilesActive;
    }
    for (const boot of classicBoots) {
      boot.visible = !isMilesActive;
    }
    for (const sn of sneakerGroups) {
      sn.visible = isMilesActive;
    }
    for (const bl of backSpiderLegs) {
      bl.visible = !isMilesActive;
    }
    eyeL.visible = !isMilesActive;
    eyeR.visible = !isMilesActive;
    milesEyesGroup.visible = isMilesActive;
    emblem.visible = !isMilesActive;
    milesFrontEmblem.visible = isMilesActive;
    milesBackEmblem.visible = isMilesActive;
    venomArcsGroup.visible = isMilesActive;
    wingMat.color.set(isMilesActive ? '#FCA5A5' : '#E0F2FE');
  };
  updateSkin(initialSkin);

  const cloakMaterials: THREE.Material[] = [
    primaryMat,
    secondaryMat,
    accentMat,
    milesMaskMat,
    milesLimbMat,
    whiteLensMat,
    redRimMat,
    milesEmblemMat,
  ];
  for (const hg of milesHandGroups) {
    for (const ch of hg.children) {
      const m = (ch as THREE.Mesh).material;
      if (m && !Array.isArray(m) && !cloakMaterials.includes(m)) cloakMaterials.push(m);
    }
  }
  for (const sn of sneakerGroups) {
    for (const ch of sn.children) {
      const m = (ch as THREE.Mesh).material;
      if (m && !Array.isArray(m) && !cloakMaterials.includes(m)) cloakMaterials.push(m);
    }
  }

  const animate = (
    state: SpiderAnimState,
    time: number,
    dt: number,
    speedNorm: number,
    shieldActive: boolean,
    shadowCloak: boolean
  ) => {
    const blend = Math.min(1, dt * 12);

    let targetBodyY = 0;
    let targetBodyRotX = 0;
    let targetBodyRotZ = 0;
    let targetLArmX = 0;
    let targetRArmX = 0;
    let targetLArmZ = 0.15;
    let targetRArmZ = -0.15;
    let targetLLegX = 0;
    let targetRLegX = 0;

    if (state === 'idle') {
      targetBodyY = Math.sin(time * 2.5) * 0.035;
      targetLArmX = Math.sin(time * 2.5) * 0.06;
      targetRArmX = -Math.sin(time * 2.5) * 0.06;
    } else if (state === 'walk' || state === 'run' || state === 'sprint') {
      const freq = state === 'sprint' ? 14 : state === 'run' ? 10 : 6.5;
      const amp = state === 'sprint' ? 0.95 : state === 'run' ? 0.72 : 0.42;
      const phase = time * freq;
      targetBodyY = Math.abs(Math.sin(phase)) * (state === 'sprint' ? 0.12 : 0.06);
      targetBodyRotX = state === 'sprint' ? -0.26 : -0.12 * speedNorm;
      targetLLegX = Math.sin(phase) * amp;
      targetRLegX = -Math.sin(phase) * amp;
      targetLArmX = -Math.sin(phase) * amp * 0.85;
      targetRArmX = Math.sin(phase) * amp * 0.85;
    } else if (state === 'jump' || state === 'doubleJump') {
      targetBodyRotX = state === 'doubleJump' ? -Math.PI * 2 * ((time * 2.5) % 1) : -0.15;
      targetLArmX = -1.2;
      targetRArmX = -1.2;
      targetLLegX = 0.45;
      targetRLegX = -0.35;
    } else if (state === 'fall') {
      const fastGlide = speedNorm > 0.65;
      targetBodyRotX = fastGlide ? -0.58 : 0.14;
      targetLArmX = fastGlide ? 0.65 : 0;
      targetRArmX = fastGlide ? 0.65 : 0;
      targetLArmZ = fastGlide ? 0.45 : 0.85;
      targetRArmZ = fastGlide ? -0.45 : -0.85;
      targetLLegX = fastGlide ? 0.42 : -0.25;
      targetRLegX = fastGlide ? 0.22 : 0.25;
    } else if (state === 'land') {
      targetBodyY = -0.24;
      targetBodyRotX = -0.35;
      targetLLegX = 0.5;
      targetRLegX = 0.5;
    } else if (state === 'wallClimb' || state === 'crawl') {
      const climbPhase = time * 11;
      targetBodyRotX = state === 'crawl' ? -1.15 : -0.2;
      targetLArmX = -1.35 + Math.sin(climbPhase) * 0.5;
      targetRArmX = -1.35 - Math.sin(climbPhase) * 0.5;
      targetLLegX = Math.sin(climbPhase) * 0.5;
      targetRLegX = -Math.sin(climbPhase) * 0.5;
    } else if (state === 'webShoot') {
      targetRArmX = -1.65;
      targetLArmX = 0.4;
      targetBodyRotX = -0.22;
    } else if (state === 'webSwing') {
      targetBodyRotX = -0.52 - speedNorm * 0.22;
      targetLArmX = -2.35;
      targetRArmX = -2.35;
      targetLLegX = 0.68;
      targetRLegX = 0.32;
    } else if (state === 'webFly') {
      targetBodyRotX = -1.06 - Math.min(0.2, speedNorm * 0.12);
      targetLArmX = 0.25;
      targetRArmX = 0.25;
      targetLArmZ = 1.32;
      targetRArmZ = -1.32;
      targetLLegX = 0.42 + Math.sin(time * 7) * 0.08;
      targetRLegX = 0.18 - Math.sin(time * 7) * 0.08;
    } else if (state === 'fight') {
      targetRArmX = -1.8 + Math.sin(time * 24) * 0.6;
      targetLArmX = -0.9;
      targetBodyRotZ = 0.22;
    } else if (state === 'dodge') {
      targetBodyRotZ = 0.55;
      targetBodyY = -0.2;
    } else if (state === 'skill' || state === 'levelUp' || state === 'victory') {
      if (isMilesActive && state === 'victory') {
        targetBodyY = 0.22 + Math.sin(time * 6.5) * 0.1;
        targetBodyRotZ = Math.sin(time * 3.2) * 0.14;
        targetLArmZ = 1.45;
        targetRArmZ = -1.45;
        targetLArmX = -1.35;
        targetRArmX = -0.65;
        targetLLegX = 0.35;
        targetRLegX = -0.25;
      } else {
        targetBodyY = 0.15 + Math.sin(time * 6) * 0.08;
        targetLArmZ = 1.3;
        targetRArmZ = -1.3;
        targetLArmX = -0.8;
        targetRArmX = -0.8;
      }
    } else if (state === 'previewSelect') {
      targetBodyY = Math.sin(time * 3.0) * 0.045;
      targetBodyRotX = -0.14;
      targetBodyRotZ = -0.08;
      targetRArmX = -0.95 + Math.sin(time * 4.5) * 0.12;
      targetLArmX = -1.25;
      targetLArmZ = 0.35;
      targetRArmZ = -0.52;
      targetLLegX = 0.18;
      targetRLegX = -0.18;
    } else if (state === 'defeat') {
      targetBodyY = -0.65;
      targetBodyRotX = 1.25;
    } else if (state === 'entrance') {
      if (isMilesActive) {
        targetBodyY = -0.16 + Math.abs(Math.sin(time * 8)) * 0.18;
        targetBodyRotX = -0.45;
        targetLArmZ = 1.05;
        targetRArmZ = -1.05;
        targetLArmX = 0.45;
        targetRArmX = -0.95;
        targetLLegX = 0.65;
        targetRLegX = -0.5;
      } else {
        targetBodyY = 0.1;
        targetBodyRotX = -0.32;
        targetLArmZ = 0.8;
        targetRArmZ = -0.8;
      }
    }

    bodyPivot.position.y = THREE.MathUtils.lerp(bodyPivot.position.y, targetBodyY, blend);
    bodyPivot.rotation.x = THREE.MathUtils.lerp(bodyPivot.rotation.x, targetBodyRotX, blend);
    bodyPivot.rotation.z = THREE.MathUtils.lerp(bodyPivot.rotation.z, targetBodyRotZ, blend);
    leftArm.rotation.x = THREE.MathUtils.lerp(leftArm.rotation.x, targetLArmX, blend);
    rightArm.rotation.x = THREE.MathUtils.lerp(rightArm.rotation.x, targetRArmX, blend);
    leftArm.rotation.z = THREE.MathUtils.lerp(leftArm.rotation.z, targetLArmZ, blend);
    rightArm.rotation.z = THREE.MathUtils.lerp(rightArm.rotation.z, targetRArmZ, blend);
    leftLeg.rotation.x = THREE.MathUtils.lerp(leftLeg.rotation.x, targetLLegX, blend);
    rightLeg.rotation.x = THREE.MathUtils.lerp(rightLeg.rotation.x, targetRLegX, blend);

    webWings.visible = state === 'webFly';
    if (webWings.visible) {
      leftWing.rotation.y = Math.sin(time * 18) * 0.08;
      rightWing.rotation.y = -Math.sin(time * 18) * 0.08;
    }

    for (let i = 0; i < backSpiderLegs.length; i++) {
      const wave =
        Math.sin(time * 4 + i * 1.4) *
        (state === 'webSwing' || state === 'webFly' || state === 'skill' ? 0.36 : 0.1);
      backSpiderLegs[i].rotation.y = wave;
    }

    if (isMilesActive) {
      venomArcsGroup.visible = !shadowCloak;
      const energized =
        state === 'fight' ||
        state === 'skill' ||
        state === 'victory' ||
        state === 'entrance' ||
        state === 'previewSelect' ||
        state === 'webSwing' ||
        state === 'webFly';
      const arcOpacity = energized ? 0.95 : 0.45 + Math.abs(Math.sin(time * 9)) * 0.35;
      venomRedMat.opacity = arcOpacity;
      venomPurpleMat.opacity = arcOpacity;
      for (let i = 0; i < venomArcs.length; i++) {
        const arc = venomArcs[i];
        arc.rotation.x = time * (5.5 + i) * (i % 2 === 0 ? 1 : -1);
        arc.rotation.y = time * (4.2 + i * 0.7);
        arc.rotation.z = Math.sin(time * 11 + i) * 0.8;
        const sc = energized ? 1.15 + Math.sin(time * 18 + i) * 0.25 : 0.85 + Math.sin(time * 10 + i) * 0.12;
        arc.scale.setScalar(sc);
      }
    } else {
      venomArcsGroup.visible = false;
    }

    shieldMesh.visible = shieldActive;
    if (shieldActive) {
      shieldMesh.rotation.y += dt * 1.6;
    }

    const cloakOpacity = isMilesActive ? 0.22 : 0.42;
    for (const mat of cloakMaterials) {
      const wantTransparent = shadowCloak || mat === milesEmblemMat;
      if (mat.transparent !== wantTransparent) {
        mat.transparent = wantTransparent;
        mat.needsUpdate = true;
      }
      mat.opacity = shadowCloak ? cloakOpacity : 1;
    }
    auraRing.rotation.z += dt * 0.8;
  };

  return {
    root,
    bodyPivot,
    torso,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    backSpiderLegs,
    shieldMesh,
    auraRing,
    contactShadow,
    updateSkin,
    animate,
  };
}

export interface BossRig3D {
  root: THREE.Group;
  legs: THREE.Group[];
  headGroup: THREE.Group;
  auraRing: THREE.Mesh;
  animate: (time: number, dt: number, telegraphing: boolean, defeated: boolean) => void;
}

export function buildBoss3D(boss: BossDef, shadowMapTex: THREE.CanvasTexture): BossRig3D {
  const root = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({
    color: boss.primaryColor,
    metalness: 0.65,
    roughness: 0.32,
  });
  const glowMat = new THREE.MeshStandardMaterial({
    color: boss.accentColor,
    emissive: boss.emissiveColor,
    emissiveIntensity: 0.9,
    metalness: 0.5,
    roughness: 0.2,
  });

  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(5.5 * boss.scale, 5.5 * boss.scale),
    new THREE.MeshBasicMaterial({
      map: shadowMapTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.6,
    })
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.03;
  root.add(contactShadow);

  // Thorax & Abdomen
  const thorax = new THREE.Mesh(new THREE.SphereGeometry(0.95, 16, 12), bodyMat);
  thorax.position.set(0, 1.5, 0);
  thorax.scale.set(1.1, 0.85, 1.25);
  thorax.castShadow = true;
  root.add(thorax);

  const abdomen = new THREE.Mesh(new THREE.SphereGeometry(1.35, 16, 12), bodyMat);
  abdomen.position.set(0, 1.95, 1.75);
  abdomen.scale.set(1.05, 0.92, 1.35);
  abdomen.castShadow = true;
  root.add(abdomen);

  const crown = new THREE.Mesh(new THREE.OctahedronGeometry(0.55, 0), glowMat);
  crown.position.set(0, 2.75, 1.65);
  root.add(crown);

  // Head + 4 Eyes + Mandibles
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.6, -1.2);
  const skull = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.85, 0.9), bodyMat);
  headGroup.add(skull);
  for (let i = 0; i < 4; i++) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), glowMat);
    eye.position.set(-0.33 + i * 0.22, 0.14 + (i === 1 || i === 2 ? 0.08 : 0), -0.46);
    headGroup.add(eye);
  }
  const fangL = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.65, 8), glowMat);
  fangL.rotation.x = Math.PI * 0.85;
  fangL.position.set(-0.32, -0.35, -0.45);
  const fangR = fangL.clone();
  fangR.position.x = 0.32;
  headGroup.add(fangL, fangR);
  root.add(headGroup);

  // 8 Articulated Spider Legs
  const legs: THREE.Group[] = [];
  for (let i = 0; i < 8; i++) {
    const side = i < 4 ? -1 : 1;
    const row = i % 4;
    const legGroup = new THREE.Group();
    legGroup.position.set(side * 0.85, 1.45, -0.5 + row * 0.68);
    const femur = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.11, 1.65, 8), bodyMat);
    femur.rotation.z = side * -0.95;
    femur.position.set(side * 0.72, 0.38, 0);
    const tibia = new THREE.Mesh(new THREE.ConeGeometry(0.12, 2.0, 8), glowMat);
    tibia.rotation.z = side * Math.PI;
    tibia.position.set(side * 1.45, -0.45, 0);
    legGroup.add(femur, tibia);
    root.add(legGroup);
    legs.push(legGroup);
  }

  const auraRing = new THREE.Mesh(
    new THREE.RingGeometry(2.3, 2.65, 36),
    new THREE.MeshBasicMaterial({
      color: boss.emissiveColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    })
  );
  auraRing.rotation.x = -Math.PI / 2;
  auraRing.position.y = 0.05;
  root.add(auraRing);

  root.scale.setScalar(boss.scale * 0.72);

  const animate = (time: number, dt: number, telegraphing: boolean, defeated: boolean) => {
    if (defeated) {
      root.position.y = Math.max(-1.2, root.position.y - dt * 2.5);
      root.rotation.x += dt * 1.5;
      return;
    }
    headGroup.position.y = 1.6 + Math.sin(time * (telegraphing ? 14 : 4)) * (telegraphing ? 0.2 : 0.08);
    auraRing.rotation.z += dt * (telegraphing ? 4.5 : 1.1);
    glowMat.emissiveIntensity = telegraphing ? 1.8 + Math.sin(time * 24) * 0.6 : 0.9;
    for (let i = 0; i < legs.length; i++) {
      const side = i < 4 ? -1 : 1;
      legs[i].rotation.y = Math.sin(time * 6.5 + i * 0.9) * 0.22;
      legs[i].rotation.z = telegraphing ? side * -0.25 : Math.cos(time * 6.5 + i) * 0.1;
    }
  };

  return { root, legs, headGroup, auraRing, animate };
}

export function getSeasonPalette(season: SeasonTheme) {
  switch (season) {
    case 'WINTER':
      return {
        skyColor: 0x091426,
        fogColor: 0x102038,
        groundColor: '#8EA2BA',
        foliageColor: '#94B8D7',
        sunColor: 0xcbd5e1,
        sunIntensity: 1.0,
        hemiSky: 0x64748b,
        hemiGround: 0x111827,
      };
    case 'NEW_YEAR':
      return {
        skyColor: 0x070b1a,
        fogColor: 0x0f172a,
        groundColor: '#7D92AC',
        foliageColor: '#059669',
        sunColor: 0xfcd34d,
        sunIntensity: 1.02,
        hemiSky: 0x6366f1,
        hemiGround: 0x111827,
      };
    case 'SPRING':
      return {
        skyColor: 0x0369a1,
        fogColor: 0x0ea5e9,
        groundColor: '#4D7C0F',
        foliageColor: '#DB2777',
        sunColor: 0xfef3c7,
        sunIntensity: 1.12,
        hemiSky: 0x7dd3fc,
        hemiGround: 0x1a2e05,
      };
    case 'SUMMER':
      return {
        skyColor: 0x075985,
        fogColor: 0x0284c7,
        groundColor: '#A16207',
        foliageColor: '#15803D',
        sunColor: 0xfde68a,
        sunIntensity: 1.18,
        hemiSky: 0x38bdf8,
        hemiGround: 0x451a03,
      };
    case 'AUTUMN':
      return {
        skyColor: 0x381504,
        fogColor: 0x5c210b,
        groundColor: '#7C2D12',
        foliageColor: '#EA580C',
        sunColor: 0xfdba74,
        sunIntensity: 1.05,
        hemiSky: 0xfb923c,
        hemiGround: 0x270e04,
      };
  }
}

export interface EnemyRig3D {
  group: THREE.Group;
  animate: (time: number, dt: number, alert: boolean) => void;
}

export function buildEnemy3D(kind: EnemyKind, shadowMapTex: THREE.CanvasTexture): EnemyRig3D {
  const group = new THREE.Group();
  const darkMetal = new THREE.MeshStandardMaterial({ color: '#1E293B', metalness: 0.72, roughness: 0.28 });
  const accentColors: Record<EnemyKind, string> = {
    small_robot: '#38BDF8',
    security_drone: '#FB7185',
    spider_hunter: '#F59E0B',
    mechanical_guard: '#F97316',
    flying_enemy: '#34D399',
    shadow_creature: '#C084FC',
  };
  const glowMat = new THREE.MeshStandardMaterial({
    color: accentColors[kind],
    emissive: accentColors[kind],
    emissiveIntensity: 1.15,
    metalness: 0.4,
    roughness: 0.2,
  });

  const shadowDisc = new THREE.Mesh(
    new THREE.PlaneGeometry(1.9, 1.9),
    new THREE.MeshBasicMaterial({ map: shadowMapTex, transparent: true, depthWrite: false, opacity: 0.5 })
  );
  shadowDisc.rotation.x = -Math.PI / 2;
  shadowDisc.position.y = 0.03;
  group.add(shadowDisc);

  const spinners: THREE.Object3D[] = [];
  const limbs: THREE.Object3D[] = [];

  if (kind === 'small_robot') {
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.9, 0.9), darkMetal);
    body.position.y = 0.85;
    const eye = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.22, 0.14), glowMat);
    eye.position.set(0, 0.95, -0.46);
    const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.85, 10), darkMetal);
    wheel.rotation.z = Math.PI / 2;
    wheel.position.y = 0.32;
    group.add(body, eye, wheel);
  } else if (kind === 'security_drone' || kind === 'flying_enemy') {
    const hull = new THREE.Mesh(new THREE.SphereGeometry(kind === 'flying_enemy' ? 0.65 : 0.75, 12, 10), darkMetal);
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), glowMat);
    eye.position.z = -0.64;
    const wingL = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.1, 0.36), glowMat);
    wingL.position.set(-0.95, 0.2, 0);
    const wingR = wingL.clone();
    wingR.position.x = 0.95;
    group.add(hull, eye, wingL, wingR);
    spinners.push(wingL, wingR);
  } else if (kind === 'spider_hunter') {
    const thorax = new THREE.Mesh(new THREE.SphereGeometry(0.65, 12, 10), darkMetal);
    thorax.position.y = 0.95;
    const eye = new THREE.Mesh(new THREE.OctahedronGeometry(0.26, 0), glowMat);
    eye.position.set(0, 1.0, -0.62);
    group.add(thorax, eye);
    for (let i = 0; i < 4; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const zOff = i < 2 ? -0.35 : 0.35;
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.06, 1.15, 6), glowMat);
      leg.position.set(side * 0.75, 0.6, zOff);
      leg.rotation.z = side * 0.55;
      group.add(leg);
      limbs.push(leg);
    }
  } else if (kind === 'mechanical_guard') {
    const torso = new THREE.Mesh(new THREE.BoxGeometry(1.3, 1.5, 0.95), darkMetal);
    torso.position.y = 1.45;
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.25, 0.15), glowMat);
    visor.position.set(0, 1.85, -0.48);
    const shieldArm = new THREE.Mesh(new THREE.BoxGeometry(0.35, 1.1, 0.8), glowMat);
    shieldArm.position.set(-0.85, 1.35, -0.15);
    group.add(torso, visor, shieldArm);
    limbs.push(shieldArm);
  } else {
    // shadow_creature
    const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.85, 0), darkMetal);
    core.position.y = 1.25;
    const halo = new THREE.Mesh(new THREE.TorusGeometry(0.95, 0.08, 8, 20), glowMat);
    halo.position.y = 1.25;
    group.add(core, halo);
    spinners.push(halo, core);
  }

  const animate = (time: number, dt: number, alert: boolean) => {
    glowMat.emissiveIntensity = alert ? 1.85 : 1.05;
    for (let i = 0; i < spinners.length; i++) {
      spinners[i].rotation.y += dt * (alert ? 5.2 : 2.2);
    }
    for (let i = 0; i < limbs.length; i++) {
      limbs[i].rotation.x = Math.sin(time * (alert ? 9 : 4.5) + i) * 0.28;
    }
  };

  return { group, animate };
}

export interface PortalRig3D {
  group: THREE.Group;
  animate: (time: number, dt: number, warping: boolean) => void;
  dispose: () => void;
}

export function buildPortal3D(portalColor: string, glowColor: string): PortalRig3D {
  const group = new THREE.Group();
  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];

  const frameMat = new THREE.MeshStandardMaterial({
    color: '#1E293B',
    metalness: 0.85,
    roughness: 0.2,
  });
  const ringMat1 = new THREE.MeshStandardMaterial({
    color: portalColor,
    emissive: portalColor,
    emissiveIntensity: 1.5,
    metalness: 0.5,
    roughness: 0.15,
  });
  const ringMat2 = new THREE.MeshStandardMaterial({
    color: glowColor,
    emissive: glowColor,
    emissiveIntensity: 1.8,
    metalness: 0.3,
    roughness: 0.15,
  });
  const vortexMat = new THREE.MeshBasicMaterial({
    color: portalColor,
    transparent: true,
    opacity: 0.72,
    side: THREE.DoubleSide,
  });
  mats.push(frameMat, ringMat1, ringMat2, vortexMat);

  // Outer Stone/Tech Gate Torus
  const outerGeo = new THREE.TorusGeometry(3.6, 0.38, 12, 36);
  const outerMesh = new THREE.Mesh(outerGeo, frameMat);
  outerMesh.position.y = 3.8;
  group.add(outerMesh);
  geos.push(outerGeo);

  // Counter-Rotating Energy Rings
  const innerGeo1 = new THREE.TorusGeometry(3.15, 0.14, 10, 32);
  const innerRing1 = new THREE.Mesh(innerGeo1, ringMat1);
  innerRing1.position.y = 3.8;
  group.add(innerRing1);
  geos.push(innerGeo1);

  const innerGeo2 = new THREE.TorusGeometry(2.55, 0.11, 10, 28);
  const innerRing2 = new THREE.Mesh(innerGeo2, ringMat2);
  innerRing2.position.y = 3.8;
  group.add(innerRing2);
  geos.push(innerGeo2);

  // Swirling Energy Core Disc
  const discGeo = new THREE.CircleGeometry(2.85, 32);
  const disc = new THREE.Mesh(discGeo, vortexMat);
  disc.position.y = 3.8;
  group.add(disc);
  geos.push(discGeo);

  // Orbiting Portal Particle Ring
  const pCount = 48;
  const pArr = new Float32Array(pCount * 3);
  for (let i = 0; i < pCount; i++) {
    const ang = (i / pCount) * Math.PI * 2;
    const rad = 2.6 + (i % 3) * 0.45;
    pArr[i * 3] = Math.cos(ang) * rad;
    pArr[i * 3 + 1] = Math.sin(ang) * rad;
    pArr[i * 3 + 2] = ((i % 5) - 2) * 0.25;
  }
  const pGeo = new THREE.BufferGeometry();
  pGeo.setAttribute('position', new THREE.BufferAttribute(pArr, 3));
  const pMat = new THREE.PointsMaterial({
    color: glowColor,
    size: 0.38,
    transparent: true,
    opacity: 0.92,
    depthWrite: false,
  });
  const particleRing = new THREE.Points(pGeo, pMat);
  particleRing.position.y = 3.8;
  group.add(particleRing);
  geos.push(pGeo);
  mats.push(pMat);

  // Base Pedestal & Light Emission
  const pedGeo = new THREE.CylinderGeometry(4.4, 4.9, 0.55, 24);
  const ped = new THREE.Mesh(pedGeo, frameMat);
  ped.position.y = 0.28;
  group.add(ped);
  geos.push(pedGeo);

  const pLight = new THREE.PointLight(portalColor, 4.5, 26);
  pLight.position.set(0, 3.8, 1.5);
  group.add(pLight);

  const animate = (time: number, dt: number, warping: boolean) => {
    const mult = warping ? 4.5 : 1.0;
    innerRing1.rotation.z += dt * 1.6 * mult;
    innerRing1.rotation.x = Math.sin(time * 1.4) * 0.22;
    innerRing2.rotation.z -= dt * 2.2 * mult;
    innerRing2.rotation.y = Math.cos(time * 1.7) * 0.28;
    particleRing.rotation.z += dt * 1.1 * mult;
    vortexMat.opacity = 0.6 + Math.sin(time * 5.0) * 0.16;
    pLight.intensity = warping ? 9.0 : 4.2 + Math.sin(time * 4.0) * 0.8;
  };

  return {
    group,
    animate,
    dispose: () => {
      geos.forEach((g) => g.dispose());
      mats.forEach((m) => m.dispose());
    },
  };
}

