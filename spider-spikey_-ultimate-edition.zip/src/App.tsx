import { useCallback, useEffect, useRef, useState } from 'react';
import { LEVEL_BY_ID } from './data/levels3d';
import {
  BOSS_CATALOG,
  CASE_BY_ID,
  SEASON_PASS_100,
  SKIN_BY_ID,
  SKIN_CATALOG,
  WEB_BY_ID,
} from './data/world3dCatalog';
import { shouldTriggerBossAfterMatch } from './game3d/worldRules';
import {
  AchievementDef,
  BossDef,
  CaseDef,
  Game3DSettings,
  LevelDef,
  MissionDef,
  PlayerSaveData,
  Screen3D,
  SeasonPassTier,
  SeasonTheme,
  SkillId,
  WebDirection,
} from './types/spider3d';
import { audio3d } from './utils/spider3dAudio';
import {
  applyXpAndLevel,
  assertAll3DCasesValid,
  buyCaseItem,
  buySkinItem,
  buyWebItem,
  claimAchievementReward,
  claimMissionReward,
  claimSeasonPassReward,
  clear3DSave,
  completeCampaignLevel,
  getNextBossForSave,
  load3DSave,
  openCaseFromSave,
  save3DProgress,
  upgradeSkillItem,
} from './utils/spider3dStorage';
import { BossArenaScreen } from './components/world3d/BossArenaScreen';
import { Cases3DScreen } from './components/world3d/Cases3DScreen';
import { CosmeticsScreen } from './components/world3d/CosmeticsScreen';
import { EntryCinematic } from './components/world3d/EntryCinematic';
import { GameHud3D, GameOutcome3D } from './components/world3d/GameHud3D';
import { LevelsScreen } from './components/world3d/LevelsScreen';
import { MainMenu3D } from './components/world3d/MainMenu3D';
import { MissionsRankScreen } from './components/world3d/MissionsRankScreen';
import { ProfileSettingsScreen } from './components/world3d/ProfileSettingsScreen';
import { SeasonPass100Screen } from './components/world3d/SeasonPass100Screen';
import { ShopScreen } from './components/world3d/ShopScreen';
import { SkillsScreen } from './components/world3d/SkillsScreen';
import {
  HudSnapshot3D,
  SpiderWorldCanvas,
  SpiderWorldHandle,
} from './components/world3d/SpiderWorldCanvas';

assertAll3DCasesValid();

const INITIAL_HUD: HudSnapshot3D = {
  hp: 100,
  maxHp: 100,
  shieldTimer: 0,
  shadowTimer: 0,
  ultTimer: 0,
  dashCooldown: 0,
  strikeCooldown: 0,
  trapCooldown: 0,
  shieldCooldown: 0,
  shadowCooldown: 0,
  ultCooldown: 0,
  webAttached: false,
  webPulling: false,
  activeDirection: 'FORWARD',
  matchScore: 0,
  matchTarget: 5,
  orbsRun: 0,
  dronesRun: 0,
  bossHp: 900,
  bossMaxHp: 900,
  bossTelegraph: false,
  timePhase: 'DAY',
  secretFound: false,
  animState: 'idle',
  movementStyle: 'GROUNDED',
  isFlying: false,
  altitude: 0,
  speedKmh: 0,
  bannerText: null,
  levelId: 1,
  levelName: 'Modern City',
  portalDistance: 130,
  warpingPortal: false,
  fps: 60,
};

export default function App() {
  const isAutostart =
    typeof window !== 'undefined' &&
    new URLSearchParams(window.location.search).get('autostart') === '1';

  const [save, setSave] = useState<PlayerSaveData>(() => load3DSave());
  const [screen, setScreen] = useState<Screen3D>(isAutostart ? 'PLAYING' : 'ENTRY');
  const [playMode, setPlayMode] = useState<'LEVEL_MATCH' | 'CITY_MATCH' | 'BOSS_ARENA'>('LEVEL_MATCH');
  const [activeLevel, setActiveLevel] = useState<LevelDef | null>(
    () => LEVEL_BY_ID[save.selectedLevelId || save.unlockedLevel || 1] || LEVEL_BY_ID[1]
  );
  const [activeBoss, setActiveBoss] = useState<BossDef | null>(null);
  const [paused, setPaused] = useState(false);
  const [runKey, setRunKey] = useState(1);
  const [activeDirection, setActiveDirection] = useState<WebDirection>('FORWARD');
  const [hud, setHud] = useState<HudSnapshot3D>(INITIAL_HUD);
  const [outcome, setOutcome] = useState<GameOutcome3D>(null);

  const canvasRef = useRef<SpiderWorldHandle>(null);
  const saveRef = useRef(save);
  saveRef.current = save;

  // Sync persistence + audio engine
  useEffect(() => {
    save3DProgress(save);
    audio3d.sync(
      save.settings.musicVolume,
      save.settings.soundVolume,
      save.settings.muted,
      save.settings.activeSeason
    );
  }, [save]);

  // Sync body dataset.state for accessibility & automated telemetry
  useEffect(() => {
    if (screen === 'ENTRY' || screen === 'MAIN_MENU') {
      document.body.dataset.state = 'title';
    } else if (screen === 'PLAYING') {
      if (outcome) document.body.dataset.state = 'gameover';
      else if (paused) document.body.dataset.state = 'paused';
      else document.body.dataset.state = 'playing';
    } else {
      document.body.dataset.state = 'menu';
    }
  }, [screen, paused, outcome]);

  // Ambient music transitions
  useEffect(() => {
    if (screen === 'PLAYING' && playMode === 'BOSS_ARENA' && !outcome) {
      audio3d.startMusic('boss');
    } else if (screen === 'MAIN_MENU') {
      audio3d.startMusic('menu');
    } else if (screen !== 'PLAYING') {
      audio3d.stopMusic();
    }
    return () => {};
  }, [screen, playMode, outcome]);

  const equippedSkin = SKIN_BY_ID[save.equippedSkinId] || SKIN_CATALOG[0];

  const startLevel = useCallback((lvl: LevelDef) => {
    audio3d.playClick();
    setSave((prev) => ({ ...prev, selectedLevelId: lvl.id }));
    setPlayMode('LEVEL_MATCH');
    setActiveLevel(lvl);
    setActiveBoss(null);
    setPaused(false);
    setOutcome(null);
    setRunKey((k) => k + 1);
    setScreen('PLAYING');
  }, []);

  const startCurrentLevel = useCallback(() => {
    const lvl =
      LEVEL_BY_ID[save.selectedLevelId || save.unlockedLevel || 1] || LEVEL_BY_ID[1];
    startLevel(lvl);
  }, [save.selectedLevelId, save.unlockedLevel, startLevel]);

  const startCityFreeRoam = useCallback(() => {
    audio3d.playClick();
    setPlayMode('CITY_MATCH');
    setActiveBoss(null);
    setPaused(false);
    setOutcome(null);
    setRunKey((k) => k + 1);
    setScreen('PLAYING');
  }, []);

  const launchBossBattle = useCallback((boss: BossDef) => {
    audio3d.playClick();
    setPlayMode('BOSS_ARENA');
    setActiveBoss(boss);
    setPaused(false);
    setOutcome(null);
    setRunKey((k) => k + 1);
    setScreen('PLAYING');
  }, []);

  const handleCollectOrb = useCallback((kind: 'orb' | 'gem' | 'secret') => {
    setSave((prev) => {
      const bonusCoins = kind === 'gem' ? 45 : kind === 'secret' ? 300 : 25;
      const bonusGems = kind === 'secret' ? 15 : kind === 'gem' ? 2 : 0;
      const xpGain = kind === 'secret' ? 150 : 22;
      const next = applyXpAndLevel(prev, xpGain, kind === 'secret' ? 180 : 25).save;
      return {
        ...next,
        coins: next.coins + bonusCoins,
        gems: next.gems + bonusGems,
        stats: {
          ...next.stats,
          orbsCollected: next.stats.orbsCollected + 1,
          secretVisited:
            kind === 'secret' ? Math.max(1, next.stats.secretVisited + 1) : next.stats.secretVisited,
        },
      };
    });
  }, []);

  const handleShootWebStat = useCallback(() => {
    setSave((prev) => ({
      ...prev,
      stats: { ...prev.stats, websShot: prev.stats.websShot + 1 },
    }));
  }, []);

  const handleUseSkillStat = useCallback(() => {
    setSave((prev) => ({
      ...prev,
      stats: { ...prev.stats, skillsUsed: prev.stats.skillsUsed + 1 },
    }));
  }, []);

  const handleDistanceStat = useCallback((meters: number) => {
    setSave((prev) => ({
      ...prev,
      stats: { ...prev.stats, distanceMeters: prev.stats.distanceMeters + meters },
    }));
  }, []);

  const handleMatchVictory = useCallback(
    (summary: { orbs: number; drones: number; coins: number; xp: number }) => {
      setSave((prev) => {
        const nextMatches = prev.matchesCompleted + 1;
        const bossTriggered = shouldTriggerBossAfterMatch(nextMatches);
        const leveled = applyXpAndLevel(prev, summary.xp, Math.round(summary.xp * 1.15));
        if (leveled.leveledUp) audio3d.playLevelUp();

        setOutcome({
          type: 'MATCH_WIN',
          orbs: summary.orbs,
          drones: summary.drones,
          coins: summary.coins,
          xp: summary.xp,
          bossTriggered,
        });

        return {
          ...leveled.save,
          coins: leveled.save.coins + summary.coins,
          matchesCompleted: nextMatches,
          wins: leveled.save.wins + 1,
          rankPoints: leveled.save.rankPoints + 45,
        };
      });
    },
    []
  );

  const handleLevelCompleted = useCallback(
    (levelDef: LevelDef, stats: { orbs: number; enemies: number }) => {
      setSave((prev) => {
        const res = completeCampaignLevel(prev, levelDef);
        if (res.leveledUp) audio3d.playLevelUp();
        audio3d.playVictory();
        const bossTriggered = shouldTriggerBossAfterMatch(res.save.matchesCompleted);

        setOutcome({
          type: 'LEVEL_WIN',
          level: levelDef,
          orbs: stats.orbs,
          enemies: stats.enemies,
          coins: res.coinsEarned,
          gems: res.gemsEarned,
          xp: res.xpEarned,
          firstClear: res.firstClear,
          unlockedNextLevel: res.unlockedNextLevel,
          bossTriggered,
        });

        return res.save;
      });
    },
    []
  );

  const handleBossVictory = useCallback((boss: BossDef) => {
    setSave((prev) => {
      const leveled = applyXpAndLevel(prev, boss.xpReward, Math.round(boss.xpReward * 1.2));
      if (leveled.leveledUp) audio3d.playLevelUp();
      const nextCases = { ...leveled.save.casesOwned };
      if (CASE_BY_ID[boss.rewardCaseId]) {
        nextCases[boss.rewardCaseId] = (nextCases[boss.rewardCaseId] || 0) + 1;
      }
      const nextSkins = [...leveled.save.ownedSkinIds];
      if (boss.rewardSkinId && !nextSkins.includes(boss.rewardSkinId)) {
        nextSkins.push(boss.rewardSkinId);
      }
      const nextTitles = leveled.save.unlockedTitles.includes(boss.rewardTitle)
        ? leveled.save.unlockedTitles
        : [...leveled.save.unlockedTitles, boss.rewardTitle];

      return {
        ...leveled.save,
        coins: leveled.save.coins + boss.coinReward,
        gems: leveled.save.gems + boss.gemReward,
        rankPoints: leveled.save.rankPoints + 120,
        wins: leveled.save.wins + 1,
        bossesDefeatedCount: leveled.save.bossesDefeatedCount + 1,
        defeatedBossIds: leveled.save.defeatedBossIds.includes(boss.id)
          ? leveled.save.defeatedBossIds
          : [...leveled.save.defeatedBossIds, boss.id],
        casesOwned: nextCases,
        ownedSkinIds: nextSkins,
        unlockedTitles: nextTitles,
      };
    });
    setOutcome({ type: 'BOSS_WIN', boss });
  }, []);

  const handlePlayerDefeat = useCallback((fromBoss: boolean, reason?: string) => {
    setOutcome({ type: 'DEFEAT', fromBoss, reason });
  }, []);

  // Economy & Collection Actions
  const handleBuySkin = (skinId: string) => {
    const skin = SKIN_BY_ID[skinId];
    if (!skin) return;
    const res = buySkinItem(save, skin);
    if (res.ok) {
      audio3d.playPickup();
      setSave({ ...res.save, equippedSkinId: skin.id });
    }
  };

  const handleBuyWeb = (webId: string) => {
    const web = WEB_BY_ID[webId];
    if (!web) return;
    const res = buyWebItem(save, web);
    if (res.ok) {
      audio3d.playPickup();
      setSave({ ...res.save, equippedWebId: web.id });
    }
  };

  const handleBuyCase = useCallback((caseId: string) => {
    const c = CASE_BY_ID[caseId];
    if (!c) return false;
    const res = buyCaseItem(saveRef.current, c);
    if (res.ok) {
      audio3d.playPickup();
      saveRef.current = res.save;
      setSave(res.save);
      return true;
    }
    return false;
  }, []);

  const handleOpenCase = useCallback((c: CaseDef) => {
    const res = openCaseFromSave(saveRef.current, c);
    if (!res.ok) {
      return { ok: false as const, error: res.error };
    }
    audio3d.playRareReveal(
      res.rarity === 'MYTHIC' || res.rarity === 'SECRET' || res.rarity === 'EXCLUSIVE'
    );
    saveRef.current = res.save;
    setSave(res.save);
    return {
      ok: true as const,
      itemKind: res.itemKind,
      itemId: res.itemId,
      itemName: res.itemName,
      rarity: res.rarity,
      wasDuplicate: res.wasDuplicate,
      bonusCoins: res.bonusCoins,
    };
  }, []);

  const handleBuyAndOpenCase = useCallback((c: CaseDef) => {
    let working = saveRef.current;
    if ((working.casesOwned[c.id] || 0) <= 0) {
      const bought = buyCaseItem(working, c);
      if (!bought.ok) {
        return { ok: false as const, error: bought.error };
      }
      working = bought.save;
    }
    const res = openCaseFromSave(working, c);
    if (!res.ok) {
      return { ok: false as const, error: res.error };
    }
    audio3d.playRareReveal(
      res.rarity === 'MYTHIC' || res.rarity === 'SECRET' || res.rarity === 'EXCLUSIVE'
    );
    saveRef.current = res.save;
    setSave(res.save);
    return {
      ok: true as const,
      itemKind: res.itemKind,
      itemId: res.itemId,
      itemName: res.itemName,
      rarity: res.rarity,
      wasDuplicate: res.wasDuplicate,
      bonusCoins: res.bonusCoins,
    };
  }, []);

  const handleUpgradeSkill = (skillId: SkillId) => {
    const res = upgradeSkillItem(save, skillId);
    if (res.ok) {
      audio3d.playSkill(true);
      setSave(res.save);
    }
  };

  const handleUnlockPremiumPass = () => {
    if (save.seasonPremiumUnlocked || save.gems < 180) return;
    audio3d.playRareReveal(true);
    setSave((prev) => ({
      ...prev,
      gems: prev.gems - 180,
      seasonPremiumUnlocked: true,
    }));
  };

  const handleClaimSeasonTier = (tier: SeasonPassTier, track: 'free' | 'premium') => {
    audio3d.playPickup();
    setSave((prev) => claimSeasonPassReward(prev, tier, track));
  };

  const handleClaimAllSeason = () => {
    audio3d.playVictory();
    setSave((prev) => {
      let cur = prev;
      for (const tier of SEASON_PASS_100) {
        if (cur.seasonPassXp >= tier.xpRequired) {
          cur = claimSeasonPassReward(cur, tier, 'free');
          if (cur.seasonPremiumUnlocked) {
            cur = claimSeasonPassReward(cur, tier, 'premium');
          }
        }
      }
      return cur;
    });
  };

  const handleClaimMission = (m: MissionDef) => {
    audio3d.playPickup();
    setSave((prev) => claimMissionReward(prev, m));
  };

  const handleClaimAchievement = (a: AchievementDef) => {
    audio3d.playRareReveal(false);
    setSave((prev) => claimAchievementReward(prev, a));
  };

  const handleUpdateSettings = (patch: Partial<Game3DSettings>) => {
    setSave((prev) => ({
      ...prev,
      settings: { ...prev.settings, ...patch },
    }));
  };

  const canvasMode = screen === 'PLAYING' ? playMode : 'MENU_IDLE';

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-[#060912] text-slate-100">
      {/* Persistent Single Three.js WebGL Stage */}
      <SpiderWorldCanvas
        ref={canvasRef}
        mode={canvasMode}
        paused={paused || Boolean(outcome)}
        save={save}
        activeDirection={activeDirection}
        activeBoss={activeBoss}
        activeLevel={activeLevel}
        runKey={runKey}
        onChangeDirection={setActiveDirection}
        onHudUpdate={setHud}
        onCollectOrb={handleCollectOrb}
        onShootWebStat={handleShootWebStat}
        onUseSkillStat={handleUseSkillStat}
        onDistanceStat={handleDistanceStat}
        onMatchVictory={handleMatchVictory}
        onLevelCompleted={handleLevelCompleted}
        onBossVictory={handleBossVictory}
        onPlayerDefeat={handlePlayerDefeat}
        onTogglePause={() => setPaused((p) => !p)}
      />

      {screen === 'ENTRY' && (
        <EntryCinematic
          equippedSkin={equippedSkin}
          season={save.settings.activeSeason}
          onEnterWorld={() => {
            audio3d.playClick();
            setScreen('MAIN_MENU');
          }}
        />
      )}

      {screen === 'MAIN_MENU' && (
        <MainMenu3D
          save={save}
          onNavigate={(target) => {
            audio3d.playClick();
            setScreen(target);
          }}
          onStartCityMatch={startCurrentLevel}
          onStartCityFreeRoam={startCityFreeRoam}
          onSelectSeason={(s: SeasonTheme) => {
            audio3d.playClick();
            handleUpdateSettings({ activeSeason: s });
          }}
        />
      )}

      {screen === 'LEVELS' && (
        <LevelsScreen
          save={save}
          onBack={() => setScreen('MAIN_MENU')}
          onPlayLevel={startLevel}
        />
      )}

      {screen === 'PLAYING' && (
        <GameHud3D
          mode={playMode}
          paused={paused}
          save={save}
          hud={hud}
          activeBoss={activeBoss}
          activeLevel={activeLevel}
          outcome={outcome}
          onSelectDirection={(dir) => setActiveDirection(dir)}
          onShootWeb={() => canvasRef.current?.shootWeb()}
          onReleaseWeb={() => canvasRef.current?.releaseWeb()}
          onPullChange={(active) => canvasRef.current?.setPulling(active)}
          onJump={() => canvasRef.current?.triggerJump()}
          onFight={() => canvasRef.current?.triggerFight()}
          onSkill={(k) => canvasRef.current?.triggerSkill(k)}
          onTogglePause={() => setPaused((p) => !p)}
          onExitToMenu={() => {
            setPaused(false);
            setOutcome(null);
            setScreen('MAIN_MENU');
          }}
          onReplay={() => {
            if (playMode === 'BOSS_ARENA' && activeBoss) launchBossBattle(activeBoss);
            else if (playMode === 'CITY_MATCH') startCityFreeRoam();
            else if (activeLevel) startLevel(activeLevel);
            else startCurrentLevel();
          }}
          onContinueNextLevel={() => {
            const nextId = Math.min(10, (activeLevel?.id || 1) + 1);
            const nextLvl = LEVEL_BY_ID[nextId] || LEVEL_BY_ID[1];
            startLevel(nextLvl);
          }}
          onLaunchNextBoss={() => {
            const nextB = getNextBossForSave(save) || BOSS_CATALOG[0];
            launchBossBattle(nextB);
          }}
        />
      )}

      {(screen === 'SKINS' || screen === 'WEBS' || screen === 'INVENTORY') && (
        <CosmeticsScreen
          initialTab={screen}
          save={save}
          onBack={() => setScreen('MAIN_MENU')}
          onEquipSkin={(id) => {
            audio3d.playClick();
            setSave((prev) => ({ ...prev, equippedSkinId: id }));
          }}
          onToggleFavoriteSkin={(id) => {
            setSave((prev) => ({
              ...prev,
              favoriteSkinIds: prev.favoriteSkinIds.includes(id)
                ? prev.favoriteSkinIds.filter((f) => f !== id)
                : [...prev.favoriteSkinIds, id],
            }));
          }}
          onBuySkin={handleBuySkin}
          onEquipWeb={(id) => {
            audio3d.playClick();
            setSave((prev) => ({ ...prev, equippedWebId: id }));
          }}
          onBuyWeb={handleBuyWeb}
          onOpenCasesTab={() => setScreen('CASES')}
        />
      )}

      {screen === 'SKILLS' && (
        <SkillsScreen
          save={save}
          onBack={() => setScreen('MAIN_MENU')}
          onUpgradeSkill={handleUpgradeSkill}
        />
      )}

      {screen === 'SHOP' && (
        <ShopScreen
          save={save}
          onBack={() => setScreen('MAIN_MENU')}
          onBuySkin={handleBuySkin}
          onBuyWeb={handleBuyWeb}
          onBuyCase={handleBuyCase}
          onUnlockPremiumPass={handleUnlockPremiumPass}
          onGoSkills={() => setScreen('SKILLS')}
          onGoCases={() => setScreen('CASES')}
        />
      )}

      {screen === 'SEASON_PASS' && (
        <SeasonPass100Screen
          save={save}
          onBack={() => setScreen('MAIN_MENU')}
          onClaimReward={handleClaimSeasonTier}
          onClaimAll={handleClaimAllSeason}
          onUnlockPremium={handleUnlockPremiumPass}
        />
      )}

      {screen === 'CASES' && (
        <Cases3DScreen
          save={save}
          onBack={() => setScreen('MAIN_MENU')}
          onBuyCase={handleBuyCase}
          onOpenCase={handleOpenCase}
          onBuyAndOpenCase={handleBuyAndOpenCase}
          onEquipUnlocked={(kind, itemId) => {
            audio3d.playClick();
            setSave((prev) =>
              kind === 'skin'
                ? { ...prev, equippedSkinId: itemId }
                : { ...prev, equippedWebId: itemId }
            );
          }}
        />
      )}

      {screen === 'BOSS_ARENA' && (
        <BossArenaScreen
          save={save}
          onBack={() => setScreen('MAIN_MENU')}
          onChallengeBoss={launchBossBattle}
        />
      )}

      {screen === 'MISSIONS' && (
        <MissionsRankScreen
          save={save}
          onBack={() => setScreen('MAIN_MENU')}
          onClaimMission={handleClaimMission}
          onClaimAchievement={handleClaimAchievement}
        />
      )}

      {(screen === 'PROFILE' || screen === 'SETTINGS') && (
        <ProfileSettingsScreen
          initialTab={screen}
          save={save}
          onBack={() => setScreen('MAIN_MENU')}
          onUpdateProfile={(patch) => setSave((prev) => ({ ...prev, ...patch }))}
          onUpdateSettings={handleUpdateSettings}
          onResetSave={() => {
            audio3d.playClick();
            setSave(clear3DSave());
          }}
        />
      )}
    </div>
  );
}
