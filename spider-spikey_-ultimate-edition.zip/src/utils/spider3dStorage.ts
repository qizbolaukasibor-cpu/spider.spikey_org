import {
  BOSS_CATALOG,
  CASE_BY_ID,
  CASE_CATALOG,
  RANK_TIERS,
  SEASON_PASS_100,
  SKILL_BY_ID,
  SKILL_CATALOG,
  SKIN_BY_ID,
  SKIN_CATALOG,
  WEB_BY_ID,
  WEB_CATALOG,
} from '../data/world3dCatalog';
import {
  AchievementDef,
  CaseDef,
  Game3DSettings,
  GraphicsPreset3D,
  KeyBindings3D,
  LevelDef,
  MissionDef,
  PlayerSaveData,
  Rarity,
  SeasonPassTier,
  SkillId,
  SkinDef,
  WebTypeDef,
} from '../types/spider3d';

export function applyGraphicsPreset(
  preset: GraphicsPreset3D
): Pick<
  Game3DSettings,
  'graphicsQuality' | 'shadows' | 'bloom' | 'particleQuality' | 'viewDistance' | 'resolutionScale'
> {
  switch (preset) {
    case 'low':
      return {
        graphicsQuality: 'low',
        shadows: false,
        bloom: false,
        particleQuality: 'low',
        viewDistance: 'near',
        resolutionScale: 0.75,
      };
    case 'medium':
      return {
        graphicsQuality: 'medium',
        shadows: true,
        bloom: true,
        particleQuality: 'medium',
        viewDistance: 'medium',
        resolutionScale: 0.9,
      };
    case 'high':
      return {
        graphicsQuality: 'high',
        shadows: true,
        bloom: true,
        particleQuality: 'high',
        viewDistance: 'far',
        resolutionScale: 1.0,
      };
    case 'ultra':
      return {
        graphicsQuality: 'ultra',
        shadows: true,
        bloom: true,
        particleQuality: 'high',
        viewDistance: 'ultra',
        resolutionScale: 1.1,
      };
    case 'extreme':
      return {
        graphicsQuality: 'extreme',
        shadows: true,
        bloom: true,
        particleQuality: 'high',
        viewDistance: 'ultra',
        resolutionScale: 1.25,
      };
  }
}

export const DEFAULT_KEY_BINDINGS: KeyBindings3D = {
  forward: 'KeyW',
  backward: 'KeyS',
  left: 'KeyA',
  right: 'KeyD',
  jump: 'Space',
  sprint: 'ShiftLeft',
  interact: 'KeyE',
  skill: 'KeyQ',
  shootWeb: 'KeyF',
  releaseWeb: 'KeyR',
  fight: 'KeyG',
  web1: 'Digit1',
  web2: 'Digit2',
  web3: 'Digit3',
  web4: 'Digit4',
  web5: 'Digit5',
};

const STORAGE_KEY = 'spider_world_3d_save_v1';

export function xpForNextLevel(level: number): number {
  return Math.round(280 * Math.pow(Math.max(1, level), 1.42));
}

export function getRankForPoints(points: number) {
  let current = RANK_TIERS[0];
  let next = RANK_TIERS[1] || null;
  for (let i = 0; i < RANK_TIERS.length; i++) {
    if (points >= RANK_TIERS[i].minPoints) {
      current = RANK_TIERS[i];
      next = RANK_TIERS[i + 1] || null;
    }
  }
  return { current, next };
}

export function getSeasonPassLevel(seasonPassXp: number): number {
  let reached = 0;
  for (const tier of SEASON_PASS_100) {
    if (seasonPassXp >= tier.xpRequired) {
      reached = tier.level;
    } else {
      break;
    }
  }
  return reached;
}

export function assertAll3DCasesValid(): void {
  for (const c of CASE_CATALOG) {
    const sum = c.drops.reduce((acc, d) => acc + d.probability, 0);
    if (Math.abs(sum - 100) > 0.001) {
      throw new Error(`Case ${c.id} drop probabilities sum to ${sum}, expected 100.`);
    }
  }
}

export function createDefaultSave(playerName = 'SpiderHero'): PlayerSaveData {
  const skillLevels = {} as Record<SkillId, number>;
  for (const sk of SKILL_CATALOG) {
    skillLevels[sk.id] = sk.id === 'double_jump' || sk.id === 'wall_climb' ? 1 : 0;
  }

  return {
    playerName,
    avatarColor: '#E11D48',
    title: 'Rooftop Guardian',
    unlockedTitles: ['Rooftop Guardian'],
    level: 1,
    xp: 0,
    coins: 900,
    gems: 25,
    rankPoints: 100,
    unlockedLevel: 1,
    completedLevels: [],
    selectedLevelId: 1,
    ownedSkinIds: ['skin_crimson_rookie', 'skin_miles_morales'],
    favoriteSkinIds: ['skin_crimson_rookie', 'skin_miles_morales'],
    equippedSkinId: 'skin_crimson_rookie',
    ownedWebIds: ['web_classic'],
    equippedWebId: 'web_classic',
    skillLevels,
    casesOwned: {
      case_basic: 2,
    },
    caseHistory: [],
    seasonPassXp: 0,
    seasonPremiumUnlocked: false,
    claimedFreePassLevels: [],
    claimedPremiumPassLevels: [],
    matchesCompleted: 0,
    wins: 0,
    bossesDefeatedCount: 0,
    defeatedBossIds: [],
    claimedMissionIds: [],
    claimedAchievementIds: [],
    stats: {
      websShot: 0,
      orbsCollected: 0,
      distanceMeters: 0,
      skillsUsed: 0,
      casesOpened: 0,
      secretVisited: 0,
    },
    settings: {
      graphicsQuality: 'high',
      shadows: true,
      bloom: true,
      particleQuality: 'high',
      viewDistance: 'far',
      fpsMode: 'auto',
      showFps: true,
      resolutionScale: 1.0,
      animations: true,
      soundVolume: 75,
      musicVolume: 50,
      muted: false,
      cameraSensitivity: 1.0,
      mouseSensitivity: 1.0,
      activeSeason: 'WINTER',
      weather: 'SNOW',
      dayNightAuto: true,
      keyBindings: { ...DEFAULT_KEY_BINDINGS },
    },
  };
}

export function load3DSave(): PlayerSaveData {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const def = createDefaultSave();
      save3DProgress(def);
      return def;
    }
    const parsed = JSON.parse(raw) as Partial<PlayerSaveData>;
    const def = createDefaultSave(parsed.playerName || 'SpiderHero');
    const mergedSkins = Array.from(
      new Set([
        'skin_crimson_rookie',
        'skin_miles_morales',
        ...(Array.isArray(parsed.ownedSkinIds) ? parsed.ownedSkinIds : []),
      ])
    );
    return {
      ...def,
      ...parsed,
      ownedSkinIds: mergedSkins,
      completedLevels: Array.isArray(parsed.completedLevels) ? parsed.completedLevels : [],
      unlockedLevel: typeof parsed.unlockedLevel === 'number' ? Math.max(1, parsed.unlockedLevel) : 1,
      selectedLevelId:
        typeof parsed.selectedLevelId === 'number' ? Math.max(1, parsed.selectedLevelId) : 1,
      skillLevels: { ...def.skillLevels, ...(parsed.skillLevels || {}) },
      casesOwned: (() => {
        const merged: Record<string, number> = { ...def.casesOwned };
        if (parsed.casesOwned && typeof parsed.casesOwned === 'object') {
          for (const [k, v] of Object.entries(parsed.casesOwned)) {
            const n = Number(v);
            merged[k] = Number.isFinite(n) ? Math.max(0, Math.floor(n)) : 0;
          }
        }
        return merged;
      })(),
      stats: { ...def.stats, ...(parsed.stats || {}) },
      settings: {
        ...def.settings,
        ...(parsed.settings || {}),
        keyBindings: {
          ...DEFAULT_KEY_BINDINGS,
          ...(parsed.settings?.keyBindings || {}),
        },
      },
    };
  } catch {
    return createDefaultSave();
  }
}

export function save3DProgress(data: PlayerSaveData): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // ignore storage quota failures
  }
}

export function clear3DSave(): PlayerSaveData {
  const def = createDefaultSave();
  save3DProgress(def);
  return def;
}

export function applyXpAndLevel(
  save: PlayerSaveData,
  gainedXp: number,
  gainedSeasonXp = 0
): { save: PlayerSaveData; leveledUp: boolean } {
  let level = save.level;
  let xp = save.xp + Math.max(0, Math.round(gainedXp));
  let coins = save.coins;
  let gems = save.gems;
  let leveledUp = false;

  while (xp >= xpForNextLevel(level)) {
    xp -= xpForNextLevel(level);
    level += 1;
    leveledUp = true;
    coins += 120 + level * 20;
    if (level % 5 === 0) gems += 15;
  }

  return {
    leveledUp,
    save: {
      ...save,
      level,
      xp,
      coins,
      gems,
      seasonPassXp: save.seasonPassXp + Math.max(0, Math.round(gainedSeasonXp)),
    },
  };
}

export function buySkinItem(
  save: PlayerSaveData,
  skin: SkinDef
): { ok: true; save: PlayerSaveData } | { ok: false; error: string } {
  if (save.ownedSkinIds.includes(skin.id)) {
    return { ok: false, error: 'Skin already owned.' };
  }
  if (save.coins < skin.coinPrice || save.gems < skin.gemPrice) {
    return { ok: false, error: 'Not enough Coins or Gems.' };
  }
  return {
    ok: true,
    save: {
      ...save,
      coins: save.coins - skin.coinPrice,
      gems: save.gems - skin.gemPrice,
      ownedSkinIds: [...save.ownedSkinIds, skin.id],
    },
  };
}

export function buyWebItem(
  save: PlayerSaveData,
  web: WebTypeDef
): { ok: true; save: PlayerSaveData } | { ok: false; error: string } {
  if (save.ownedWebIds.includes(web.id)) {
    return { ok: false, error: 'Web type already owned.' };
  }
  if (save.coins < web.coinPrice || save.gems < web.gemPrice) {
    return { ok: false, error: 'Not enough Coins or Gems.' };
  }
  return {
    ok: true,
    save: {
      ...save,
      coins: save.coins - web.coinPrice,
      gems: save.gems - web.gemPrice,
      ownedWebIds: [...save.ownedWebIds, web.id],
    },
  };
}

export function buyCaseItem(
  save: PlayerSaveData,
  c: CaseDef
): { ok: true; save: PlayerSaveData } | { ok: false; error: string } {
  if (save.coins < c.coinPrice || save.gems < c.gemPrice) {
    return { ok: false, error: 'Not enough Coins or Gems for this case.' };
  }
  return {
    ok: true,
    save: {
      ...save,
      coins: save.coins - c.coinPrice,
      gems: save.gems - c.gemPrice,
      casesOwned: {
        ...save.casesOwned,
        [c.id]: (save.casesOwned[c.id] || 0) + 1,
      },
    },
  };
}

export function upgradeSkillItem(
  save: PlayerSaveData,
  skillId: SkillId
): { ok: true; save: PlayerSaveData } | { ok: false; error: string } {
  const def = SKILL_BY_ID[skillId];
  if (!def) return { ok: false, error: 'Unknown skill.' };
  const currentLvl = save.skillLevels[skillId] || 0;
  if (currentLvl >= def.maxLevel) {
    return { ok: false, error: 'Skill is already at maximum level.' };
  }
  if (save.level < def.unlockLevel) {
    return { ok: false, error: `Requires Player Level ${def.unlockLevel}.` };
  }
  const coinCost = Math.round(def.coinCost * (1 + currentLvl * 0.65));
  const gemCost = Math.round(def.gemCost * (1 + currentLvl * 0.5));
  if (save.coins < coinCost || save.gems < gemCost) {
    return { ok: false, error: 'Not enough Coins or Gems.' };
  }
  return {
    ok: true,
    save: {
      ...save,
      coins: save.coins - coinCost,
      gems: save.gems - gemCost,
      skillLevels: {
        ...save.skillLevels,
        [skillId]: currentLvl + 1,
      },
    },
  };
}

export function rollRarityFromCaseDef(caseDef: CaseDef, roll0to100: number): Rarity {
  let cumulative = 0;
  for (const drop of caseDef.drops) {
    cumulative += drop.probability;
    if (roll0to100 <= cumulative) return drop.rarity;
  }
  return caseDef.drops[caseDef.drops.length - 1].rarity;
}

export function openCaseFromSave(
  save: PlayerSaveData,
  caseDef: CaseDef,
  rng: () => number = Math.random
):
  | {
      ok: true;
      save: PlayerSaveData;
      itemKind: 'skin' | 'web';
      itemId: string;
      itemName: string;
      rarity: Rarity;
      wasDuplicate: boolean;
      bonusCoins: number;
    }
  | { ok: false; error: string } {
  const count = Math.max(0, Number(save.casesOwned?.[caseDef.id]) || 0);
  if (count <= 0) {
    return { ok: false, error: 'You do not own this case.' };
  }

  const rolledRarity = rollRarityFromCaseDef(caseDef, rng() * 100);
  const matchingSkins = SKIN_CATALOG.filter((s) => s.rarity === rolledRarity);
  const matchingWebs = WEB_CATALOG.filter((w) => w.rarity === rolledRarity);

  const pickSkin = matchingSkins.length > 0 && (matchingWebs.length === 0 || rng() < 0.55);

  let nextSave: PlayerSaveData = {
    ...save,
    casesOwned: {
      ...save.casesOwned,
      [caseDef.id]: count - 1,
    },
    stats: {
      ...save.stats,
      casesOpened: (save.stats?.casesOpened || 0) + 1,
    },
  };

  let itemId = '';
  let itemName = '';
  let itemKind: 'skin' | 'web' = 'skin';
  let wasDuplicate = false;
  let bonusCoins = 0;

  if (pickSkin || matchingWebs.length === 0) {
    const pool = matchingSkins.length > 0 ? matchingSkins : SKIN_CATALOG;
    const picked = pool[Math.floor(rng() * pool.length)];
    itemKind = 'skin';
    itemId = picked.id;
    itemName = picked.name;
    if (nextSave.ownedSkinIds.includes(picked.id)) {
      wasDuplicate = true;
      bonusCoins = Math.max(5000, Math.round(picked.coinPrice * 0.35));
      nextSave = { ...nextSave, coins: nextSave.coins + bonusCoins };
    } else {
      nextSave = {
        ...nextSave,
        ownedSkinIds: [...nextSave.ownedSkinIds, picked.id],
      };
    }
  } else {
    const picked = matchingWebs[Math.floor(rng() * matchingWebs.length)];
    itemKind = 'web';
    itemId = picked.id;
    itemName = picked.name;
    if (nextSave.ownedWebIds.includes(picked.id)) {
      wasDuplicate = true;
      bonusCoins = Math.max(4000, Math.round(picked.coinPrice * 0.35));
      nextSave = { ...nextSave, coins: nextSave.coins + bonusCoins };
    } else {
      nextSave = {
        ...nextSave,
        ownedWebIds: [...nextSave.ownedWebIds, picked.id],
      };
    }
  }

  nextSave = {
    ...nextSave,
    caseHistory: [
      {
        timestamp: new Date().toISOString(),
        caseName: caseDef.name,
        itemName,
        itemKind,
        rarity: rolledRarity,
      },
      ...(Array.isArray(nextSave.caseHistory) ? nextSave.caseHistory : []),
    ].slice(0, 30),
  };

  return {
    ok: true,
    save: nextSave,
    itemKind,
    itemId,
    itemName,
    rarity: rolledRarity,
    wasDuplicate,
    bonusCoins,
  };
}

export function claimSeasonPassReward(
  save: PlayerSaveData,
  tier: SeasonPassTier,
  track: 'free' | 'premium'
): PlayerSaveData {
  if (save.seasonPassXp < tier.xpRequired) return save;
  if (track === 'premium' && !save.seasonPremiumUnlocked) return save;

  const list = track === 'free' ? save.claimedFreePassLevels : save.claimedPremiumPassLevels;
  if (list.includes(tier.level)) return save;

  let next: PlayerSaveData = {
    ...save,
    claimedFreePassLevels:
      track === 'free' ? [...save.claimedFreePassLevels, tier.level] : save.claimedFreePassLevels,
    claimedPremiumPassLevels:
      track === 'premium'
        ? [...save.claimedPremiumPassLevels, tier.level]
        : save.claimedPremiumPassLevels,
    casesOwned: { ...save.casesOwned },
    ownedSkinIds: [...save.ownedSkinIds],
    ownedWebIds: [...save.ownedWebIds],
  };

  const rType = track === 'free' ? tier.freeType : tier.premiumType;
  const rAmt = track === 'free' ? tier.freeAmount || 0 : tier.premiumAmount || 0;
  const rRef = track === 'free' ? tier.freeRefId : tier.premiumRefId;

  if (rType === 'coins') next = { ...next, coins: next.coins + rAmt };
  else if (rType === 'gems') next = { ...next, gems: next.gems + rAmt };
  else if (rType === 'case' && rRef && CASE_BY_ID[rRef]) {
    next.casesOwned[rRef] = (next.casesOwned[rRef] || 0) + 1;
  } else if (rType === 'skin' && rRef && SKIN_BY_ID[rRef]) {
    if (!next.ownedSkinIds.includes(rRef)) next.ownedSkinIds.push(rRef);
    else next.coins += 1200;
  } else if (rType === 'web' && rRef && WEB_BY_ID[rRef]) {
    if (!next.ownedWebIds.includes(rRef)) next.ownedWebIds.push(rRef);
    else next.coins += 900;
  }

  return next;
}

export function claimMissionReward(save: PlayerSaveData, mission: MissionDef): PlayerSaveData {
  if (save.claimedMissionIds.includes(mission.id)) return save;
  const updated = applyXpAndLevel(save, mission.xpReward, mission.seasonXpReward).save;
  return {
    ...updated,
    coins: updated.coins + mission.coinReward,
    gems: updated.gems + mission.gemReward,
    claimedMissionIds: [...updated.claimedMissionIds, mission.id],
  };
}

export function claimAchievementReward(
  save: PlayerSaveData,
  ach: AchievementDef
): PlayerSaveData {
  if (save.claimedAchievementIds.includes(ach.id)) return save;
  const updated = applyXpAndLevel(save, ach.xpReward, 120).save;
  return {
    ...updated,
    coins: updated.coins + ach.coinReward,
    gems: updated.gems + ach.gemReward,
    unlockedTitles: updated.unlockedTitles.includes(ach.rewardTitle)
      ? updated.unlockedTitles
      : [...updated.unlockedTitles, ach.rewardTitle],
    claimedAchievementIds: [...updated.claimedAchievementIds, ach.id],
  };
}

export function getNextBossForSave(save: PlayerSaveData) {
  const idx = save.bossesDefeatedCount % BOSS_CATALOG.length;
  return BOSS_CATALOG[idx];
}

export function getRotatingShopOfferIds(date = new Date()): {
  dailySkinId: string;
  weeklyWebId: string;
} {
  const daySeed = Math.floor(date.getTime() / 86_400_000);
  const weekSeed = Math.floor(daySeed / 7);
  const buyableSkins = SKIN_CATALOG.filter((s) => s.coinPrice > 0);
  const buyableWebs = WEB_CATALOG.filter((w) => w.coinPrice > 0);
  return {
    dailySkinId: buyableSkins[daySeed % buyableSkins.length].id,
    weeklyWebId: buyableWebs[weekSeed % buyableWebs.length].id,
  };
}

export function completeCampaignLevel(
  save: PlayerSaveData,
  levelDef: LevelDef
): {
  save: PlayerSaveData;
  leveledUp: boolean;
  firstClear: boolean;
  unlockedNextLevel: number;
  coinsEarned: number;
  gemsEarned: number;
  xpEarned: number;
} {
  const firstClear = !save.completedLevels.includes(levelDef.id);
  const mult = firstClear ? 1 : 0.45;
  const coinsEarned = Math.round(levelDef.coinReward * mult);
  const gemsEarned = firstClear ? levelDef.gemReward : Math.max(4, Math.round(levelDef.gemReward * 0.25));
  const xpEarned = Math.round(levelDef.xpReward * mult);
  const seasonXpEarned = Math.round(levelDef.seasonXpReward * mult);

  const xpResult = applyXpAndLevel(save, xpEarned, seasonXpEarned);
  const nextUnlocked = Math.min(10, Math.max(save.unlockedLevel || 1, levelDef.id + 1));
  const completedLevels = firstClear
    ? [...save.completedLevels, levelDef.id]
    : save.completedLevels;

  const nextSave: PlayerSaveData = {
    ...xpResult.save,
    coins: xpResult.save.coins + coinsEarned,
    gems: xpResult.save.gems + gemsEarned,
    rankPoints: xpResult.save.rankPoints + (firstClear ? 65 : 20),
    unlockedLevel: nextUnlocked,
    completedLevels,
    selectedLevelId: nextUnlocked,
    matchesCompleted: xpResult.save.matchesCompleted + 1,
    wins: xpResult.save.wins + 1,
  };

  return {
    save: nextSave,
    leveledUp: xpResult.leveledUp,
    firstClear,
    unlockedNextLevel: nextUnlocked,
    coinsEarned,
    gemsEarned,
    xpEarned,
  };
}
