import { SeasonTheme } from '../types/spider3d';

class Spider3DAudioEngine {
  private ctx: AudioContext | null = null;
  private sfxVolume = 0.75;
  private musicVolume = 0.5;
  private muted = false;
  private ambientTimer: number | null = null;
  private ambientMode: 'menu' | 'boss' | null = null;
  private season: SeasonTheme = 'WINTER';

  public sync(musicPercent: number, sfxPercent: number, muted: boolean, season: SeasonTheme): void {
    this.musicVolume = Math.max(0, Math.min(1, musicPercent / 100));
    this.sfxVolume = Math.max(0, Math.min(1, sfxPercent / 100));
    this.muted = muted;
    this.season = season;
    if (muted || this.musicVolume <= 0.01) {
      this.stopMusic();
    }
  }

  private ensureContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private playTone(
    freq: number,
    endFreq: number,
    duration: number,
    type: OscillatorType,
    gainScale: number,
    channel: 'sfx' | 'music' = 'sfx'
  ): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const chVol = channel === 'music' ? this.musicVolume * 0.25 : this.sfxVolume * 0.4;
    if (chVol <= 0.005) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(40, freq), now);
    if (endFreq !== freq) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(40, endFreq), now + duration);
    }
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(gainScale * chVol, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  public playClick(): void {
    this.playTone(580, 760, 0.06, 'triangle', 0.25);
  }

  public playHover(): void {
    this.playTone(420, 480, 0.035, 'sine', 0.12);
  }

  public playJump(doubleJump = false): void {
    this.playTone(doubleJump ? 340 : 210, doubleJump ? 660 : 440, 0.14, 'triangle', 0.35);
  }

  public playLand(): void {
    this.playTone(130, 62, 0.1, 'sine', 0.32);
  }

  public playWebShoot(pitchMult = 1): void {
    this.playTone(760 * pitchMult, 280 * pitchMult, 0.13, 'sawtooth', 0.28);
  }

  public playWebAttach(pitchMult = 1): void {
    this.playTone(320 * pitchMult, 620 * pitchMult, 0.1, 'triangle', 0.32);
  }

  public playSwingWhoosh(): void {
    this.playTone(190, 340, 0.18, 'sine', 0.22);
  }

  public playStrike(): void {
    this.playTone(220, 90, 0.12, 'square', 0.32);
  }

  public playSkill(high = false): void {
    this.playTone(high ? 440 : 300, high ? 1120 : 780, 0.22, 'triangle', 0.38);
  }

  public playPickup(): void {
    this.playTone(660, 990, 0.1, 'sine', 0.3);
  }

  public playCaseTick(): void {
    this.playTone(540, 600, 0.04, 'square', 0.18);
  }

  public playRareReveal(mythic = false): void {
    const notes = mythic ? [523, 659, 784, 1046, 1318] : [440, 554, 659, 880];
    notes.forEach((f, idx) => {
      window.setTimeout(() => this.playTone(f, f * 1.01, 0.28, 'triangle', 0.42), idx * 85);
    });
  }

  public playLevelUp(): void {
    [440, 554, 659, 880, 1108].forEach((f, i) => {
      window.setTimeout(() => this.playTone(f, f, 0.24, 'triangle', 0.38), i * 70);
    });
  }

  public playVictory(): void {
    [523, 659, 784, 1046].forEach((f, i) => {
      window.setTimeout(() => this.playTone(f, f, 0.32, 'triangle', 0.4), i * 110);
    });
  }

  public playHurt(): void {
    this.playTone(190, 75, 0.2, 'sawtooth', 0.42);
  }

  public playHazardHit(): void {
    this.playTone(260, 55, 0.28, 'sawtooth', 0.48);
  }

  public playPlatformCollapse(): void {
    this.playTone(160, 68, 0.22, 'triangle', 0.34);
  }

  public playPortalTeleport(): void {
    [392, 523, 659, 784, 1046, 1318].forEach((f, idx) => {
      window.setTimeout(() => this.playTone(f, f * 1.18, 0.32, 'sine', 0.4), idx * 65);
    });
  }

  public startMusic(mode: 'menu' | 'boss'): void {
    if (this.muted || this.musicVolume <= 0.01) return;
    if (this.ambientTimer && this.ambientMode === mode) return;
    this.stopMusic();
    this.ambientMode = mode;

    const scales: Record<SeasonTheme, number[]> = {
      WINTER: [392, 440, 523, 587, 659],
      NEW_YEAR: [523, 659, 784, 880, 1046],
      SPRING: [440, 494, 554, 659, 740],
      SUMMER: [392, 494, 587, 659, 784],
      AUTUMN: [349, 440, 523, 587, 698],
    };

    let step = 0;
    this.ambientTimer = window.setInterval(() => {
      if (this.muted || this.musicVolume <= 0.01) return;
      if (mode === 'boss') {
        const bossNotes = [110, 110, 146, 130, 165, 130];
        const f = bossNotes[step % bossNotes.length];
        this.playTone(f, f * 0.98, 0.28, 'sawtooth', 0.28, 'music');
      } else {
        const sc = scales[this.season] || scales.WINTER;
        const f = sc[step % sc.length];
        this.playTone(f, f, 0.65, 'sine', 0.2, 'music');
      }
      step += 1;
    }, mode === 'boss' ? 420 : 920);
  }

  public stopMusic(): void {
    if (this.ambientTimer !== null) {
      clearInterval(this.ambientTimer);
      this.ambientTimer = null;
      this.ambientMode = null;
    }
  }
}

export const audio3d = new Spider3DAudioEngine();
