export type Rarity =
  | 'COMMON'
  | 'UNCOMMON'
  | 'RARE'
  | 'EPIC'
  | 'LEGENDARY'
  | 'MYTHIC'
  | 'SECRET'
  | 'EXCLUSIVE';

export type WebDirection = 'FORWARD' | 'BACKWARD' | 'LEFT' | 'RIGHT' | 'UPWARD';

export type SeasonTheme = 'WINTER' | 'NEW_YEAR' | 'SPRING' | 'SUMMER' | 'AUTUMN';

export type WeatherMode = 'CLEAR' | 'SNOW' | 'RAIN' | 'WIND';

export type Screen3D =
  | 'ENTRY'
  | 'MAIN_MENU'
  | 'LEVELS'
  | 'PLAYING'
  | 'INVENTORY'
  | 'SKINS'
  | 'WEBS'
  | 'SKILLS'
  | 'SHOP'
  | 'SEASON_PASS'
  | 'CASES'
  | 'BOSS_ARENA'
  | 'MISSIONS'
  | 'PROFILE'
  | 'SETTINGS';

export type EnemyKind =
  | 'small_robot'
  | 'security_drone'
  | 'spider_hunter'
  | 'mechanical_guard'
  | 'flying_enemy'
  | 'shadow_creature';

export type LevelObstacleKind =
  | 'moving_platform'
  | 'rotating_platform'
  | 'moving_wall'
  | 'sliding_block'
  | 'swinging_pendulum'
  | 'collapsing_platform'
  | 'laser_gate'
  | 'electric_barrier'
  | 'falling_object'
  | 'timed_door'
  | 'wind_zone';

export type SpiderAnimState =
  | 'idle'
  | 'walk'
  | 'run'
  | 'sprint'
  | 'jump'
  | 'doubleJump'
  | 'fall'
  | 'land'
  | 'wallClimb'
  | 'crawl'
  | 'webShoot'
  | 'webSwing'
  | 'webFly'
  | 'fight'
  | 'dodge'
  | 'skill'
  | 'victory'
  | 'defeat'
  | 'entrance'
  | 'levelUp'
  | 'previewSelect';

export type SkillId =
  | 'super_jump'
  | 'double_jump'
  | 'web_dash'
  | 'spider_sense'
  | 'fast_swing'
  | 'wall_climb'
  | 'web_shield'
  | 'electric_attack'
  | 'shadow_mode'
  | 'spider_strike'
  | 'spider_speed'
  | 'web_trap'
  | 'air_dash'
  | 'super_landing'
  | 'ultimate_spider_power';

export interface SkinAbilityDef {
  name: string;
  keyHint: string;
  description: string;
  accentColor: string;
}

export interface SkinDef {
  id: string;
  name: string;
  variant?: 'standard' | 'miles_morales';
  category:
    | 'Starter'
    | 'Classic'
    | 'Rare'
    | 'Epic'
    | 'Legendary'
    | 'Mythic'
    | 'Secret'
    | 'Limited'
    | 'Seasonal'
    | 'Exclusive';
  rarity: Rarity;
  coinPrice: number;
  gemPrice: number;
  description: string;
  unlockHint: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  emissiveColor: string;
  metalness: number;
  roughness: number;
  particleColor: string;
  entranceStyle: string;
  victoryStyle: string;
  speedBonus: number;
  powerBonus: number;
  abilities?: SkinAbilityDef[];
  caseOnly?: boolean;
  bossDropId?: string;
}

export interface WebTypeDef {
  id: string;
  name: string;
  rarity: Rarity;
  coinPrice: number;
  gemPrice: number;
  description: string;
  color: string;
  glowColor: string;
  particleColor: string;
  speedMultiplier: number;
  pullForce: number;
  soundPitch: number;
  trailStyle: 'silk' | 'ice' | 'fire' | 'electric' | 'shadow' | 'gold' | 'diamond' | 'galaxy' | 'rainbow' | 'cosmic';
  caseOnly?: boolean;
}

export interface SkillDef {
  id: SkillId;
  name: string;
  description: string;
  maxLevel: number;
  cooldownSec: number;
  unlockLevel: number;
  coinCost: number;
  gemCost: number;
  keyHint: string;
  color: string;
}

export interface CaseDropEntry {
  rarity: Rarity;
  probability: number; // strictly sums to 100 across case
}

export interface CaseDef {
  id: string;
  name: string;
  rarity: Rarity;
  coinPrice: number;
  gemPrice: number;
  description: string;
  accentColor: string;
  drops: CaseDropEntry[];
}

export interface BossDef {
  id: string;
  index: number;
  name: string;
  title: string;
  maxHp: number;
  speed: number;
  attackDamage: number;
  attackInterval: number;
  primaryColor: string;
  accentColor: string;
  emissiveColor: string;
  scale: number;
  arenaColor: string;
  coinReward: number;
  gemReward: number;
  xpReward: number;
  rewardCaseId: string;
  rewardSkinId?: string;
  rewardTitle: string;
}

export interface SeasonPassTier {
  level: number;
  xpRequired: number;
  freeLabel: string;
  freeType: 'coins' | 'gems' | 'case' | 'skin' | 'web' | 'title';
  freeAmount?: number;
  freeRefId?: string;
  premiumLabel: string;
  premiumType: 'coins' | 'gems' | 'case' | 'skin' | 'web' | 'emote' | 'title';
  premiumAmount?: number;
  premiumRefId?: string;
  isMilestone?: boolean;
}

export interface MissionDef {
  id: string;
  category: 'Daily' | 'Weekly' | 'Seasonal' | 'Secret' | 'Boss' | 'Exploration';
  title: string;
  description: string;
  metric:
    | 'websShot'
    | 'matchesPlayed'
    | 'bossesDefeated'
    | 'orbsCollected'
    | 'distanceMeters'
    | 'skillsUsed'
    | 'casesOpened'
    | 'secretVisited';
  target: number;
  coinReward: number;
  gemReward: number;
  xpReward: number;
  seasonXpReward: number;
}

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  metric:
    | 'matchesPlayed'
    | 'websShot'
    | 'bossesDefeated'
    | 'skinsOwned'
    | 'websOwned'
    | 'level'
    | 'casesOpened'
    | 'rankPoints';
  target: number;
  rewardTitle: string;
  coinReward: number;
  gemReward: number;
  xpReward: number;
}

export interface KeyBindings3D {
  forward: string;
  backward: string;
  left: string;
  right: string;
  jump: string;
  sprint: string;
  interact: string;
  skill: string;
  shootWeb: string;
  releaseWeb: string;
  fight: string;
  web1: string;
  web2: string;
  web3: string;
  web4: string;
  web5: string;
}

export type GraphicsPreset3D = 'low' | 'medium' | 'high' | 'ultra' | 'extreme';

export interface Game3DSettings {
  graphicsQuality: GraphicsPreset3D;
  shadows: boolean;
  bloom: boolean;
  particleQuality: 'low' | 'medium' | 'high';
  viewDistance: 'near' | 'medium' | 'far' | 'ultra';
  fpsMode: 'auto' | '60' | '120';
  showFps: boolean;
  resolutionScale: number; // 0.6 - 1.25
  animations: boolean;
  soundVolume: number; // 0-100
  musicVolume: number; // 0-100
  muted: boolean;
  cameraSensitivity: number; // 0.3 - 2.5
  mouseSensitivity: number; // 0.3 - 2.5
  activeSeason: SeasonTheme;
  weather: WeatherMode;
  dayNightAuto: boolean;
  keyBindings?: KeyBindings3D;
}

export interface CaseOpenRecord {
  timestamp: string;
  caseName: string;
  itemName: string;
  itemKind: 'skin' | 'web';
  rarity: Rarity;
}

export interface LevelPlatformSpec {
  id: string;
  x: number;
  y: number;
  z: number;
  w: number;
  h: number;
  d: number;
  color?: string;
  slippery?: boolean;
  climbable?: boolean;
  kind?: 'building' | 'house' | 'bridge' | 'rock' | 'platform' | 'pillar';
}

export interface LevelObstacleSpec {
  id: string;
  kind: LevelObstacleKind;
  x: number;
  y: number;
  z: number;
  w: number;
  h: number;
  d: number;
  axis?: 'x' | 'y' | 'z';
  amplitude?: number;
  speed?: number;
  phase?: number;
  lethal?: boolean;
}

export interface LevelEnemySpec {
  id: string;
  kind: EnemyKind;
  x: number;
  y: number;
  z: number;
  hp: number;
  speed: number;
  damage: number;
  patrolRadius: number;
}

export interface LevelDef {
  id: number;
  name: string;
  subtitle: string;
  difficulty: 'Normal' | 'Hard' | 'Expert' | 'Master' | 'Nightmare' | 'Omega';
  skyColor: string;
  fogColor: string;
  groundColor: string;
  accentColor: string;
  portalColor: string;
  portalGlowColor: string;
  sunColor: string;
  sunIntensity: number;
  weatherOverride?: WeatherMode;
  hasVoidPit?: boolean;
  slipperyFloors?: boolean;
  windForce?: { x: number; z: number };
  startPos: { x: number; y: number; z: number };
  portalPos: { x: number; y: number; z: number };
  coinReward: number;
  gemReward: number;
  xpReward: number;
  seasonXpReward: number;
  platforms: LevelPlatformSpec[];
  obstacles: LevelObstacleSpec[];
  enemies: LevelEnemySpec[];
}

export interface PlayerSaveData {
  playerName: string;
  avatarColor: string;
  title: string;
  unlockedTitles: string[];
  level: number;
  xp: number;
  coins: number;
  gems: number;
  rankPoints: number;
  unlockedLevel: number;
  completedLevels: number[];
  selectedLevelId: number;
  ownedSkinIds: string[];
  favoriteSkinIds: string[];
  equippedSkinId: string;
  ownedWebIds: string[];
  equippedWebId: string;
  skillLevels: Record<SkillId, number>;
  casesOwned: Record<string, number>;
  caseHistory: CaseOpenRecord[];
  seasonPassXp: number;
  seasonPremiumUnlocked: boolean;
  claimedFreePassLevels: number[];
  claimedPremiumPassLevels: number[];
  matchesCompleted: number;
  wins: number;
  bossesDefeatedCount: number;
  defeatedBossIds: string[];
  claimedMissionIds: string[];
  claimedAchievementIds: string[];
  stats: {
    websShot: number;
    orbsCollected: number;
    distanceMeters: number;
    skillsUsed: number;
    casesOpened: number;
    secretVisited: number;
  };
  settings: Game3DSettings;
}

export interface CityCollider {
  id: string;
  x: number;
  y: number; // bottom Y
  z: number;
  w: number;
  h: number;
  d: number;
  climbable?: boolean;
  slippery?: boolean;
  disabled?: boolean;
  kind?: 'building' | 'house' | 'bridge' | 'rock' | 'platform' | 'pillar';
}
