import React from 'react';
import { Calendar, Check, Crown, X } from 'lucide-react';
import { DAILY_LOGIN_REWARDS } from '../data/catalog';
import { getTranslations } from '../data/translations';
import { DailyLoginReward, PlayerProfile } from '../types/game';
import { soundEngine } from '../utils/audio';
import { canClaimDailyLogin } from '../utils/storage';

interface DailyRewardsModalProps {
  profile: PlayerProfile;
  onClose: () => void;
  onClaimDaily: (reward: DailyLoginReward, dayNumber: number) => void;
}

export const DailyRewardsModal: React.FC<DailyRewardsModalProps> = ({
  profile,
  onClose,
  onClaimDaily,
}) => {
  const t = getTranslations(profile.settings.language);
  const status = canClaimDailyLogin(profile);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
      <div className="w-full max-w-4xl rounded-2xl border border-slate-700 bg-[#0D131F] p-6 space-y-5 max-h-[88vh] flex flex-col">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <Calendar className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-xl font-bold text-white">{t.dailyRewards}</h2>
              <p className="text-xs text-slate-400">
                Current Streak: <strong className="text-amber-300">{profile.loginStreak} Days</strong> ·
                Day 10 Legendary · Day 20 Neon Web · Day 30 Mythic Case
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close daily rewards"
            className="p-2 rounded-lg border border-slate-700 text-slate-300 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 md:grid-cols-6 gap-2.5 overflow-y-auto pr-1">
          {DAILY_LOGIN_REWARDS.map((r) => {
            const claimed = profile.claimedLoginDays.includes(r.day);
            const isNext = status.canClaim && status.nextDayNumber === r.day;

            return (
              <div
                key={r.day}
                className={`rounded-xl border p-3 flex flex-col justify-between gap-2 ${
                  isNext
                    ? 'border-emerald-400 bg-emerald-950/30'
                    : r.highlight
                      ? 'border-amber-400/60 bg-amber-950/20'
                      : 'border-slate-800 bg-[#080B12]'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono-num font-bold text-white">Day {r.day}</span>
                  {r.highlight && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                </div>
                <div className="text-xs font-semibold text-amber-300">{r.label}</div>
                {claimed ? (
                  <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>{t.claimed}</span>
                  </div>
                ) : isNext ? (
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playRareReveal(Boolean(r.highlight));
                      onClaimDaily(r, r.day);
                    }}
                    className="w-full py-1.5 rounded bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-bold text-xs cursor-pointer"
                  >
                    {t.claim}
                  </button>
                ) : (
                  <span className="text-[11px] text-slate-500">Locked</span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
