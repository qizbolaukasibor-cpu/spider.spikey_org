import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Home,
  Pause,
  Play,
  RotateCcw,
  Shield,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { getTranslations } from '../data/translations';
import { GAME_LEVELS } from '../game/levels';
import {
  applyWebSwingPhysics,
  computeAdaptiveWebHouse,
  computeEffectiveLoadout,
  findBestWebAnchor,
  moveAndCollideAABB,
  rectsOverlap,
} from '../game/physics';
import {
  drawPlatformsAndProps,
  drawSpiderSpikeyPixel,
  drawStyledWebLine,
  drawWebHouse,
  drawWinterLevelBackground,
  ParticlePool,
} from '../game/renderer';
import {
  EnemyType,
  GamePlayState,
  PlayerMetrics,
  PlayerProfile,
  Vec2,
  WebHouseStructure,
} from '../types/game';
import { soundEngine } from '../utils/audio';

interface GameCanvasProps {
  profile: PlayerProfile;
  stageId: number;
  onSelectStage: (stageId: number) => void;
  onExitToMenu: () => void;
  onRunFinished: (result: {
    won: boolean;
    stageId: number;
    score: number;
    coinsEarned: number;
    xpEarned: number;
    metricsDelta: Partial<PlayerMetrics>;
  }) => void;
  onToggleMute: () => void;
}

interface ActiveEnemy {
  id: string;
  type: EnemyType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  baseY: number;
  patrolMinX: number;
  patrolMaxX: number;
  dir: number;
  telegraphTimer: number;
  chargeTimer: number;
  cooldownTimer: number;
  koTimer: number;
  alive: boolean;
}

interface EnemyBolt {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
}

interface HudSnapshot {
  hp: number;
  maxHp: number;
  coins: number;
  score: number;
  shieldReady: boolean;
  shieldCooldown: number;
  shelterLabel: 'SMALL' | 'LARGE';
  anchorReady: boolean;
  webState: 'idle' | 'shooting' | 'attached';
}

interface RunSummary {
  won: boolean;
  score: number;
  coins: number;
  distanceM: number;
  housesBuilt: number;
  webAttaches: number;
  clearTimeSec: number;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  profile,
  stageId,
  onSelectStage,
  onExitToMenu,
  onRunFinished,
  onToggleMute,
}) => {
  const t = getTranslations(profile.settings.language);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [playState, setPlayState] = useState<GamePlayState>('playing');
  const [hud, setHud] = useState<HudSnapshot>({
    hp: 3,
    maxHp: 3,
    coins: 0,
    score: 0,
    shieldReady: false,
    shieldCooldown: 0,
    shelterLabel: 'LARGE',
    anchorReady: false,
    webState: 'idle',
  });
  const [summary, setSummary] = useState<RunSummary | null>(null);
  const [runNonce, setRunNonce] = useState(0);

  const playStateRef = useRef<GamePlayState>(playState);
  playStateRef.current = playState;

  const profileRef = useRef(profile);
  profileRef.current = profile;

  const onRunFinishedRef = useRef(onRunFinished);
  onRunFinishedRef.current = onRunFinished;

  const resumeRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    document.body.dataset.state = playState;
    if (playState === 'playing') {
      resumeRef.current?.();
    }
    return () => {
      document.body.dataset.state = 'title';
    };
  }, [playState]);

  const restartStage = useCallback(() => {
    soundEngine.playMenuClick();
    setSummary(null);
    setPlayState('playing');
    setRunNonce((n) => n + 1);
  }, []);

  const togglePause = useCallback(() => {
    soundEngine.playMenuClick();
    setPlayState((prev) => (prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev));
  }, []);

  useEffect(() => {
    const level = GAME_LEVELS.find((l) => l.id === stageId) || GAME_LEVELS[0];
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const parent = canvas.parentElement;
      const w = parent ? parent.clientWidth : window.innerWidth;
      const h = parent ? parent.clientHeight : window.innerHeight;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const nextW = Math.floor(w * dpr);
      const nextH = Math.floor(h * dpr);
      if (canvas.width !== nextW || canvas.height !== nextH) {
        canvas.width = nextW;
        canvas.height = nextH;
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);
    const resizeObserver =
      typeof ResizeObserver !== 'undefined' && canvas.parentElement
        ? new ResizeObserver(() => resize())
        : null;
    if (resizeObserver && canvas.parentElement) {
      resizeObserver.observe(canvas.parentElement);
    }

    // Simulation state (strictly decoupled from React 60Hz reconciliation)
    const size = { w: 28, h: 36 };
    let pos: Vec2 = { ...level.spawn };
    let vel: Vec2 = { x: 0, y: 0 };
    let spawnPoint: Vec2 = { ...level.spawn };
    let activeCheckpointId: string | null = null;
    let facing = 1;
    let grounded = false;
    let coyoteTimer = 0;
    let jumpBufferTimer = 0;
    let jumpsRemaining = 2;
    let scaleX = 1;
    let scaleY = 1;
    let walkCycle = 0;
    let hp = 3;
    const maxHp = 3;
    let invulnTimer = 0;
    let hitFlash = 0;
    let hitstopTimer = 0;
    let trauma = 0;
    let shieldCooldown = 0;
    let runCoins = 0;
    let runScore = 0;
    let distancePx = 0;
    let elapsedPlayTime = 0;
    let housesBuilt = 0;
    let housesSmall = 0;
    let housesLarge = 0;
    let webAttaches = 0;
    let enemiesDefeated = 0;
    let lastHudSync = 0;
    let finishReported = false;

    const collectedCoins = new Set<string>();
    const webHouses: WebHouseStructure[] = [];
    const particles = new ParticlePool(260);
    const bolts: EnemyBolt[] = [];
    const enemies: ActiveEnemy[] = level.enemies.map((e) => ({
      id: e.id,
      type: e.type,
      x: e.x,
      y: e.y,
      vx: e.type === 'frost_turret' ? 0 : 75,
      vy: 0,
      baseY: e.y,
      patrolMinX: e.patrolMinX,
      patrolMaxX: e.patrolMaxX,
      dir: 1,
      telegraphTimer: 0,
      chargeTimer: 0,
      cooldownTimer: 1.5,
      koTimer: 0,
      alive: true,
    }));

    // Q-key web grapple state
    let webPhase: 'idle' | 'shooting' | 'attached' = 'idle';
    let webTarget: Vec2 | null = null;
    let webShootProgress = 0;
    let webRopeLen = 140;
    let webReleaseFade = 0;
    let webReleaseFrom: Vec2 | null = null;
    let webReleaseTo: Vec2 | null = null;
    let swingSoundCooldown = 0;

    let camX = 0;
    let camY = 0;

    // Unified input hub
    const held = new Set<string>();
    const justPressed = new Set<string>();

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === 'Escape' || e.code === 'KeyP') {
        if (playStateRef.current === 'playing' || playStateRef.current === 'paused') {
          e.preventDefault();
          togglePause();
        }
        return;
      }
      if (e.code === 'KeyM') {
        onToggleMute();
        return;
      }
      if (e.code === 'KeyR' && playStateRef.current !== 'gameover') {
        restartStage();
        return;
      }
      if (playStateRef.current !== 'playing') return;

      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
      held.add(e.code);
      justPressed.add(e.code);
    };

    const onKeyUp = (e: KeyboardEvent) => {
      held.delete(e.code);
      if (
        (e.code === 'Space' || e.code === 'KeyW' || e.code === 'ArrowUp') &&
        vel.y < -120 &&
        webPhase !== 'attached'
      ) {
        vel.y *= 0.48; // variable jump cut
      }
    };

    const clearInputs = () => {
      held.clear();
      justPressed.clear();
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', clearInputs);
    document.addEventListener('visibilitychange', clearInputs);

    const applyPlayerDamage = (sourceX: number, loadout: ReturnType<typeof computeEffectiveLoadout>) => {
      if (invulnTimer > 0 || playStateRef.current !== 'playing') return;

      // ZAI Crystal Shield absorbs 1 hit when ready!
      if (loadout.abilities.has('ZAI_CRYSTAL_SHIELD') && shieldCooldown <= 0) {
        shieldCooldown = 14;
        invulnTimer = 1.1;
        hitstopTimer = 0.045;
        trauma = 0.45;
        soundEngine.playZaiAbility();
        particles.burst(pos.x + size.w / 2, pos.y + size.h / 2, 20, '#F5C451', 220, 5, 80);
        return;
      }

      hp = Math.max(0, hp - 1);
      invulnTimer = 1.25;
      hitFlash = 0.14;
      hitstopTimer = 0.055;
      trauma = 0.7;
      soundEngine.playHurt();
      vel.y = -320;
      vel.x = pos.x + size.w / 2 < sourceX ? -240 : 240;
      webPhase = 'idle';
      particles.burst(pos.x + size.w / 2, pos.y + size.h / 2, 16, '#FB7185', 200, 4, 240);

      if (hp <= 0 && !finishReported) {
        finishReported = true;
        const distM = Math.round(distancePx / 18);
        setSummary({
          won: false,
          score: runScore,
          coins: runCoins,
          distanceM: distM,
          housesBuilt,
          webAttaches,
          clearTimeSec: Math.round(elapsedPlayTime),
        });
        setPlayState('gameover');
        onRunFinishedRef.current({
          won: false,
          stageId: level.id,
          score: runScore,
          coinsEarned: runCoins,
          xpEarned: Math.max(25, Math.round(distM * 0.3)),
          metricsDelta: {
            distanceTraveled: distM,
            webHousesBuilt: housesBuilt,
            webHousesSmall: housesSmall,
            webHousesLarge: housesLarge,
            webAttaches,
            coinsCollectedInGame: runCoins,
            enemiesDefeated,
          },
        });
      }
    };

    let raf = 0;
    let lastTime = performance.now();
    let loopActive = true;

    const resumeLoop = () => {
      if (!loopActive && playStateRef.current === 'playing') {
        loopActive = true;
        lastTime = performance.now();
        raf = requestAnimationFrame(step);
      }
    };
    resumeRef.current = resumeLoop;

    const step = (now: number) => {
      const rawDt = (now - lastTime) / 1000;
      lastTime = now;
      const dt = Math.min(rawDt, 0.05);
      const timeSec = now / 1000;

      const viewW = canvas.clientWidth || window.innerWidth;
      const viewH = canvas.clientHeight || window.innerHeight;
      const loadout = computeEffectiveLoadout(profileRef.current.equipped);
      const highQ = profileRef.current.settings.graphicsQuality !== 'low';

      if (playStateRef.current === 'playing') {
        if (hitFlash > 0) hitFlash = Math.max(0, hitFlash - dt);
        if (trauma > 0) trauma = Math.max(0, trauma - dt * 1.8);
        if (invulnTimer > 0) invulnTimer = Math.max(0, invulnTimer - dt);
        if (shieldCooldown > 0) shieldCooldown = Math.max(0, shieldCooldown - dt);
        if (webReleaseFade > 0) webReleaseFade = Math.max(0, webReleaseFade - dt * 4.5);
        if (swingSoundCooldown > 0) swingSoundCooldown = Math.max(0, swingSoundCooldown - dt);

        if (hitstopTimer > 0) {
          hitstopTimer = Math.max(0, hitstopTimer - dt);
        } else {
          elapsedPlayTime += dt;

          const leftHeld = held.has('KeyA') || held.has('ArrowLeft');
          const rightHeld = held.has('KeyD') || held.has('ArrowRight');
          const upHeld = held.has('KeyW') || held.has('ArrowUp');
          const downHeld = held.has('KeyS') || held.has('ArrowDown');
          const inputX = (rightHeld ? 1 : 0) - (leftHeld ? 1 : 0);
          if (inputX !== 0) facing = inputX;

          const jumpJust =
            justPressed.has('Space') || justPressed.has('KeyW') || justPressed.has('ArrowUp');
          const eJust = justPressed.has('KeyE');
          const qJust = justPressed.has('KeyQ');
          justPressed.clear();

          if (jumpJust) jumpBufferTimer = 0.12;
          else if (jumpBufferTimer > 0) jumpBufferTimer = Math.max(0, jumpBufferTimer - dt);

          const playerCenter: Vec2 = { x: pos.x + size.w / 2, y: pos.y + size.h / 2 };

          // Preview anchor for Q
          const highlightedAnchor = findBestWebAnchor(
            playerCenter,
            facing,
            level.anchors,
            level.platforms,
            loadout.stats.webRange,
            loadout.abilities.has('ZAI_INSTANT_ATTACH')
          );

          // Preview web house for E
          const housePreview = computeAdaptiveWebHouse(
            playerCenter.x,
            playerCenter.y,
            level.platforms,
            { width: level.width, height: level.height },
            loadout.stats.webRange,
            loadout.webStyle,
            loadout.webColor,
            loadout.webGlow
          );

          // E Key: Build Intelligent Space-Adaptive Web House
          if (eJust) {
            const newHouse = {
              ...housePreview,
              id: `wh_${Date.now()}_${webHouses.length}`,
              buildProgress: 0.05,
            };
            webHouses.push(newHouse);
            if (webHouses.length > 6) webHouses.shift();
            housesBuilt += 1;
            if (newHouse.sizeCategory === 'small') housesSmall += 1;
            else housesLarge += 1;
            runScore += newHouse.sizeCategory === 'large' ? 40 : 25;
            soundEngine.playWebHouseBuild(newHouse.sizeCategory === 'large');
            particles.burst(
              newHouse.centerX,
              newHouse.centerY,
              newHouse.sizeCategory === 'large' ? 18 : 10,
              loadout.webGlow,
              150,
              3.5,
              40
            );
          }

          // Q Key: First press shoots/attaches, Second press releases with momentum
          if (qJust) {
            if (webPhase === 'idle') {
              if (highlightedAnchor) {
                webPhase = 'shooting';
                webTarget = { ...highlightedAnchor };
                webShootProgress = 0;
                soundEngine.playWebShoot(loadout.isZaiActive);
              }
            } else {
              // Second Q press -> Release Web
              webReleaseFrom = { ...playerCenter };
              webReleaseTo = webTarget ? { ...webTarget } : null;
              webReleaseFade = 1;
              webPhase = 'idle';
              webTarget = null;
              jumpsRemaining = Math.max(jumpsRemaining, 1);

              // Preserve momentum & give crisp release lift
              const boostScale = 1 + (loadout.stats.swingBoost / 100) * 0.14;
              vel.x *= boostScale;
              vel.y = Math.min(vel.y - 110, -240);

              soundEngine.playWebRelease(loadout.isZaiActive);

              if (loadout.abilities.has('ZAI_ENERGY_BURST')) {
                vel.y = Math.min(vel.y, -350);
                vel.x += facing * 75;
                particles.burst(playerCenter.x, playerCenter.y, 22, '#F5C451', 250, 4.5, 60);
              } else {
                particles.burst(playerCenter.x, playerCenter.y, 10, loadout.webGlow, 150, 3, 90);
              }
            }
          }

          // Advance Web House construction animations
          const buildSpeed = loadout.abilities.has('SILK_SURGE') ? 4.2 : 2.8;
          for (const wh of webHouses) {
            if (wh.buildProgress < 1) {
              wh.buildProgress = Math.min(1, wh.buildProgress + dt * buildSpeed);
            }
          }

          // Advance Web Shooting -> Attached transition
          if (webPhase === 'shooting' && webTarget) {
            const shootRate = loadout.abilities.has('ZAI_INSTANT_ATTACH') ? 26 : 13;
            webShootProgress += dt * shootRate;
            if (webShootProgress >= 1) {
              webPhase = 'attached';
              webAttaches += 1;
              runScore += 20;
              const dist = Math.hypot(webTarget.x - playerCenter.x, webTarget.y - playerCenter.y);
              webRopeLen = Math.max(58, Math.min(dist, 260));
              soundEngine.playWebAttach(loadout.isZaiActive);
              particles.burst(webTarget.x, webTarget.y, 10, loadout.webColor, 130, 3, 60);
            }
          }

          const wasGrounded = grounded;
          const prevX = pos.x;

          if (webPhase === 'attached' && webTarget) {
            // Reel rope with W/S while swinging
            if (upHeld) webRopeLen = Math.max(54, webRopeLen - 170 * dt);
            if (downHeld) webRopeLen = Math.min(280, webRopeLen + 170 * dt);

            const swung = applyWebSwingPhysics(
              playerCenter,
              vel,
              webTarget,
              webRopeLen,
              inputX,
              loadout.stats.swingBoost,
              loadout.abilities.has('ZAI_SUPER_SWING'),
              dt
            );
            const desiredVel = {
              x: (swung.center.x - size.w / 2 - pos.x) / Math.max(0.001, dt),
              y: (swung.center.y - size.h / 2 - pos.y) / Math.max(0.001, dt),
            };
            const col = moveAndCollideAABB(
              pos,
              desiredVel,
              size,
              level.platforms,
              { width: level.width, height: level.height },
              dt
            );
            pos = col.pos;
            vel = swung.vel;
            if (col.hitWallLeft || col.hitWallRight) vel.x *= -0.25;
            if (col.grounded) vel.y = Math.min(0, vel.y);
            grounded = col.grounded;

            if (Math.hypot(vel.x, vel.y) > 260 && swingSoundCooldown <= 0) {
              soundEngine.playSwingWhoosh();
              swingSoundCooldown = 0.45;
              if (loadout.abilities.has('PRISM_TRAIL') || loadout.isZaiActive) {
                particles.spawn(
                  pos.x + size.w / 2,
                  pos.y + size.h / 2,
                  -vel.x * 0.15,
                  -vel.y * 0.15,
                  0.25,
                  4,
                  loadout.webGlow,
                  0
                );
              }
            }
          } else {
            // Normal responsive platformer movement
            const maxRunSpeed = 245 + (loadout.stats.moveSpeed / 100) * 95;
            const accel = grounded ? 2100 : 1450;
            const targetVx = inputX * maxRunSpeed;
            if (vel.x < targetVx) {
              vel.x = Math.min(targetVx, vel.x + accel * dt);
            } else if (vel.x > targetVx) {
              vel.x = Math.max(targetVx, vel.x - accel * dt);
            }

            // Inside a Web House -> gentle silk cushion & jump pad bounce
            const insideHouse = webHouses.find((wh) =>
              rectsOverlap({ x: pos.x, y: pos.y, w: size.w, h: size.h }, wh.bounds)
            );

            // Gravity
            const gravity = insideHouse && vel.y > 0 ? 520 : 1120;
            vel.y = Math.min(760, vel.y + gravity * dt);

            // Jump (coyote + buffered + double jump)
            if (jumpBufferTimer > 0 && (coyoteTimer > 0 || jumpsRemaining > 0)) {
              const jumpPower = insideHouse ? -540 : -475 - (loadout.stats.webPower / 100) * 35;
              vel.y = jumpPower;
              if (coyoteTimer <= 0) {
                jumpsRemaining = Math.max(0, jumpsRemaining - 1);
              } else {
                jumpsRemaining = 1;
              }
              coyoteTimer = 0;
              jumpBufferTimer = 0;
              grounded = false;
              scaleX = 0.84;
              scaleY = 1.2;
              soundEngine.playJump();
              particles.burst(pos.x + size.w / 2, pos.y + size.h, 5, loadout.accentColor, 95, 3, 180);
            }

            const col = moveAndCollideAABB(
              pos,
              vel,
              size,
              level.platforms,
              { width: level.width, height: level.height },
              dt
            );
            pos = col.pos;
            vel = col.vel;
            grounded = col.grounded;
          }

          if (grounded) {
            coyoteTimer = 0.1;
            jumpsRemaining = 2;
            if (!wasGrounded) {
              scaleX = 1.24;
              scaleY = 0.78;
              particles.burst(pos.x + size.w / 2, pos.y + size.h, 4, '#E0F2FE', 80, 2.5, 180);
            }
          } else {
            coyoteTimer = Math.max(0, coyoteTimer - dt);
          }

          // Smooth squash & stretch recovery
          scaleX += (1 - scaleX) * Math.min(1, dt * 14);
          scaleY += (1 - scaleY) * Math.min(1, dt * 14);

          const dxMoved = Math.abs(pos.x - prevX);
          distancePx += dxMoved;
          if (grounded && dxMoved > 0.2) {
            walkCycle += dxMoved * 0.16;
            if (loadout.abilities.has('FROST_STEP') && Math.random() < 0.25) {
              particles.spawn(pos.x + size.w / 2, pos.y + size.h, -vel.x * 0.1, -20, 0.25, 3, '#BAE6FD', 80);
            }
          }

          // Pit respawn to checkpoint
          if (pos.y > level.height + 40) {
            pos = { ...spawnPoint };
            vel = { x: 0, y: 0 };
            webPhase = 'idle';
            applyPlayerDamage(pos.x, loadout);
          }

          const playerRect = { x: pos.x, y: pos.y, w: size.w, h: size.h };

          // Hazards
          for (const h of level.hazards) {
            if (rectsOverlap(playerRect, h)) {
              applyPlayerDamage(h.x + h.w / 2, loadout);
            }
          }

          // Checkpoints
          for (const cp of level.checkpoints) {
            if (
              activeCheckpointId !== cp.id &&
              Math.abs(pos.x - cp.x) < 42 &&
              Math.abs(pos.y + size.h - cp.y) < 60
            ) {
              activeCheckpointId = cp.id;
              spawnPoint = { x: cp.x, y: cp.y - size.h - 2 };
              soundEngine.playPurchase();
              particles.burst(cp.x, cp.y - 24, 12, '#10B981', 150, 3.5, 90);
            }
          }

          // Coins
          for (const c of level.coins) {
            if (collectedCoins.has(c.id)) continue;
            if (
              rectsOverlap(playerRect, {
                x: c.x - 12,
                y: c.y - 12,
                w: 24,
                h: 24,
              })
            ) {
              collectedCoins.add(c.id);
              runCoins += c.value;
              runScore += c.value * 5;
              soundEngine.playCoin();
              particles.burst(c.x, c.y, 8, '#FDE047', 120, 3, 60);
            }
          }

          // Enemies (3 distinct AI policies)
          for (const en of enemies) {
            if (!en.alive) {
              if (en.koTimer > 0) {
                en.koTimer -= dt;
                en.y += en.vy * dt;
                en.vy += 650 * dt;
              }
              continue;
            }

            if (en.type === 'frost_drone') {
              en.x += en.dir * 85 * dt;
              if (en.x >= en.patrolMaxX) en.dir = -1;
              if (en.x <= en.patrolMinX) en.dir = 1;
              en.y = en.baseY + Math.sin(timeSec * 3.2 + en.x * 0.02) * 20;
            } else if (en.type === 'ice_stalker') {
              const distToPlayer = pos.x - en.x;
              const sameBand = Math.abs(pos.y - en.y) < 70;
              if (en.chargeTimer > 0) {
                en.chargeTimer -= dt;
                en.x += en.dir * 215 * dt;
              } else if (en.telegraphTimer > 0) {
                en.telegraphTimer -= dt;
                if (en.telegraphTimer <= 0) {
                  en.chargeTimer = 0.55;
                  en.cooldownTimer = 1.6;
                }
              } else {
                en.cooldownTimer = Math.max(0, en.cooldownTimer - dt);
                if (sameBand && Math.abs(distToPlayer) < 220 && en.cooldownTimer <= 0) {
                  en.dir = distToPlayer >= 0 ? 1 : -1;
                  en.telegraphTimer = 0.45; // clear crouch/flash windup telegraph!
                } else {
                  en.x += en.dir * 55 * dt;
                }
              }
              en.x = Math.max(en.patrolMinX, Math.min(en.patrolMaxX, en.x));
              if (en.x >= en.patrolMaxX) en.dir = -1;
              if (en.x <= en.patrolMinX) en.dir = 1;
            } else if (en.type === 'frost_turret') {
              const dist = Math.hypot(pos.x - en.x, pos.y - en.y);
              en.cooldownTimer -= dt;
              if (en.telegraphTimer > 0) {
                en.telegraphTimer -= dt;
                if (en.telegraphTimer <= 0) {
                  const dx = pos.x + size.w / 2 - en.x;
                  const dy = pos.y + size.h / 2 - (en.y - 10);
                  const len = Math.max(1, Math.hypot(dx, dy));
                  bolts.push({
                    x: en.x,
                    y: en.y - 10,
                    vx: (dx / len) * 260,
                    vy: (dy / len) * 260,
                    life: 2.6,
                  });
                  en.cooldownTimer = 2.4;
                }
              } else if (dist < 420 && en.cooldownTimer <= 0) {
                en.telegraphTimer = 0.6; // visible laser sightline telegraph!
              }
            }

            const enRect = { x: en.x - 14, y: en.y - 14, w: 28, h: 28 };
            if (rectsOverlap(playerRect, enRect)) {
              // Stomp from above defeats enemy cleanly!
              if (vel.y > 40 && pos.y + size.h - vel.y * dt <= enRect.y + 14) {
                en.alive = false;
                en.koTimer = 0.45;
                en.vy = -210;
                vel.y = -370;
                hitstopTimer = 0.04;
                enemiesDefeated += 1;
                runCoins += 25;
                runScore += 120;
                soundEngine.playRareReveal(false);
                particles.burst(en.x, en.y, 14, '#38BDF8', 190, 4, 180);
              } else {
                applyPlayerDamage(en.x, loadout);
              }
            }
          }

          // Update enemy bolts (blocked by player's Web Houses!)
          for (let i = bolts.length - 1; i >= 0; i--) {
            const b = bolts[i];
            b.x += b.vx * dt;
            b.y += b.vy * dt;
            b.life -= dt;
            const blockedByHouse = webHouses.some(
              (wh) =>
                b.x >= wh.bounds.x &&
                b.x <= wh.bounds.x + wh.bounds.w &&
                b.y >= wh.bounds.y &&
                b.y <= wh.bounds.y + wh.bounds.h
            );
            if (blockedByHouse) {
              particles.burst(b.x, b.y, 8, loadout.webGlow, 110, 3, 80);
              bolts.splice(i, 1);
              continue;
            }
            if (rectsOverlap(playerRect, { x: b.x - 5, y: b.y - 5, w: 10, h: 10 })) {
              bolts.splice(i, 1);
              applyPlayerDamage(b.x, loadout);
              continue;
            }
            if (b.life <= 0) bolts.splice(i, 1);
          }

          // Goal Portal Victory Check
          if (rectsOverlap(playerRect, level.goal) && !finishReported) {
            finishReported = true;
            const clearBonus = 120 + level.id * 60;
            const totalCoinsEarned = runCoins + clearBonus;
            const distM = Math.round(distancePx / 18);
            const totalScore = runScore + clearBonus * 4;
            soundEngine.playVictory();
            setSummary({
              won: true,
              score: totalScore,
              coins: totalCoinsEarned,
              distanceM: distM,
              housesBuilt,
              webAttaches,
              clearTimeSec: Math.round(elapsedPlayTime),
            });
            setPlayState('gameover');
            onRunFinishedRef.current({
              won: true,
              stageId: level.id,
              score: totalScore,
              coinsEarned: totalCoinsEarned,
              xpEarned: 150 + level.id * 45,
              metricsDelta: {
                distanceTraveled: distM,
                webHousesBuilt: housesBuilt,
                webHousesSmall: housesSmall,
                webHousesLarge: housesLarge,
                webAttaches,
                levelsCompleted: 1,
                coinsCollectedInGame: runCoins,
                enemiesDefeated,
              },
            });
          }

          particles.update(dt);

          // Camera smooth follow
          const targetCamX = Math.max(0, Math.min(level.width - viewW, pos.x - viewW * 0.36));
          const targetCamY = Math.max(0, Math.min(level.height - viewH, pos.y - viewH * 0.55));
          camX += (targetCamX - camX) * Math.min(1, dt * 8);
          camY += (targetCamY - camY) * Math.min(1, dt * 8);

          // Throttle HUD updates (~12Hz or on key state changes)
          if (now - lastHudSync > 85) {
            lastHudSync = now;
            setHud({
              hp,
              maxHp,
              coins: runCoins,
              score: runScore,
              shieldReady: loadout.abilities.has('ZAI_CRYSTAL_SHIELD') && shieldCooldown <= 0,
              shieldCooldown: Math.ceil(shieldCooldown),
              shelterLabel: housePreview.sizeCategory === 'small' ? 'SMALL' : 'LARGE',
              anchorReady: Boolean(highlightedAnchor),
              webState: webPhase,
            });
          }
        }
      }

      // ==================== RENDER ====================
      const shakeMag = trauma * trauma * 10;
      const shakeX = shakeMag > 0.2 ? (Math.random() - 0.5) * shakeMag : 0;
      const shakeY = shakeMag > 0.2 ? (Math.random() - 0.5) * shakeMag : 0;

      ctx.save();
      ctx.translate(shakeX, shakeY);

      drawWinterLevelBackground(ctx, level, camX, viewW, viewH, timeSec, highQ);

      const playerCenter: Vec2 = { x: pos.x + size.w / 2, y: pos.y + size.h / 2 };
      const activeAnchor = findBestWebAnchor(
        playerCenter,
        facing,
        level.anchors,
        level.platforms,
        loadout.stats.webRange,
        loadout.abilities.has('ZAI_INSTANT_ATTACH')
      );

      drawPlatformsAndProps(
        ctx,
        level,
        camX,
        camY,
        timeSec,
        activeAnchor,
        collectedCoins,
        activeCheckpointId
      );

      // Web House live preview blueprint + built Web Houses
      if (playStateRef.current === 'playing') {
        const preview = computeAdaptiveWebHouse(
          playerCenter.x,
          playerCenter.y,
          level.platforms,
          { width: level.width, height: level.height },
          loadout.stats.webRange,
          loadout.webStyle,
          loadout.webColor,
          loadout.webGlow
        );
        drawWebHouse(ctx, preview, camX, camY, timeSec, true);
      }

      for (const wh of webHouses) {
        drawWebHouse(ctx, wh, camX, camY, timeSec, false);
      }

      // Enemies & telegraphs
      for (const en of enemies) {
        if (!en.alive && en.koTimer <= 0) continue;
        const ex = Math.round(en.x - camX);
        const ey = Math.round(en.y - camY);
        ctx.save();
        if (!en.alive) ctx.globalAlpha = Math.max(0, en.koTimer / 0.45);

        if (en.type === 'frost_drone') {
          ctx.fillStyle = '#0F172A';
          ctx.fillRect(ex - 14, ey - 10, 28, 20);
          ctx.strokeStyle = '#38BDF8';
          ctx.lineWidth = 2;
          ctx.strokeRect(ex - 14, ey - 10, 28, 20);
          ctx.fillStyle = '#38BDF8';
          ctx.fillRect(ex - 5, ey - 4, 10, 8);
        } else if (en.type === 'ice_stalker') {
          const telegraphing = en.telegraphTimer > 0;
          ctx.fillStyle = telegraphing ? '#F43F5E' : '#1E293B';
          ctx.fillRect(ex - 14, ey - 12, 28, 24);
          ctx.fillStyle = telegraphing ? '#FDE047' : '#FB7185';
          ctx.fillRect(en.dir > 0 ? ex + 2 : ex - 10, ey - 7, 8, 6);
        } else {
          // Frost Turret
          ctx.fillStyle = '#1E293B';
          ctx.fillRect(ex - 14, ey - 8, 28, 24);
          ctx.fillStyle = en.telegraphTimer > 0 ? '#EF4444' : '#38BDF8';
          ctx.fillRect(ex - 7, ey - 16, 14, 10);
          if (en.telegraphTimer > 0) {
            ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
            ctx.lineWidth = 1.5;
            ctx.setLineDash([5, 5]);
            ctx.beginPath();
            ctx.moveTo(ex, ey - 10);
            ctx.lineTo(playerCenter.x - camX, playerCenter.y - camY);
            ctx.stroke();
            ctx.setLineDash([]);
          }
        }
        ctx.restore();
      }

      // Enemy Bolts
      for (const b of bolts) {
        ctx.fillStyle = '#FB7185';
        ctx.fillRect(Math.round(b.x - camX - 4), Math.round(b.y - camY - 4), 8, 8);
      }

      // Active Q Web Shooting / Swinging / Release Silk
      if ((webPhase === 'shooting' || webPhase === 'attached') && webTarget) {
        const prog = webPhase === 'shooting' ? Math.min(1, webShootProgress) : 1;
        drawStyledWebLine(
          ctx,
          playerCenter.x - camX,
          playerCenter.y - camY - 6,
          webTarget.x - camX,
          webTarget.y - camY,
          loadout.webStyle,
          loadout.webColor,
          loadout.webGlow,
          timeSec,
          prog
        );
      } else if (webReleaseFade > 0 && webReleaseFrom && webReleaseTo) {
        ctx.save();
        ctx.globalAlpha = webReleaseFade;
        drawStyledWebLine(
          ctx,
          webReleaseFrom.x - camX,
          webReleaseFrom.y - camY,
          webReleaseTo.x - camX,
          webReleaseTo.y - camY,
          loadout.webStyle,
          loadout.webColor,
          loadout.webGlow,
          timeSec,
          webReleaseFade
        );
        ctx.restore();
      }

      // Player Sprite
      if (invulnTimer <= 0 || Math.floor(timeSec * 16) % 2 === 0) {
        drawSpiderSpikeyPixel(ctx, playerCenter.x - camX, playerCenter.y - camY, {
          facing,
          scaleX,
          scaleY,
          walkCycle,
          isGrounded: grounded,
          isSwinging: webPhase === 'attached',
          hitFlash,
          time: timeSec,
          loadout,
          shieldReady: loadout.abilities.has('ZAI_CRYSTAL_SHIELD') && shieldCooldown <= 0,
        });
      }

      particles.draw(ctx, camX, camY);
      ctx.restore();

      if (playStateRef.current === 'playing') {
        raf = requestAnimationFrame(step);
      } else {
        loopActive = false;
        held.clear();
        justPressed.clear();
      }
    };

    raf = requestAnimationFrame(step);
    return () => {
      loopActive = false;
      resumeRef.current = null;
      cancelAnimationFrame(raf);
      resizeObserver?.disconnect();
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', clearInputs);
      document.removeEventListener('visibilitychange', clearInputs);
    };
  }, [stageId, runNonce, togglePause, restartStage, onToggleMute]);

  const currentLevel = GAME_LEVELS.find((l) => l.id === stageId) || GAME_LEVELS[0];

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#060911]">
      <canvas
        ref={canvasRef}
        data-testid="game-canvas"
        className="block w-full h-full"
      />

      {/* World-Matched Perimeter HUD (pointer-events: none wrapper) */}
      <div className="fixed inset-0 pointer-events-none flex flex-col justify-between p-4">
        <div className="flex items-start justify-between gap-4">
          {/* Top-Left Vitality & Score Cluster */}
          <div className="pointer-events-auto flex items-center gap-4 rounded-lg border border-slate-700/80 bg-[#0A0F1A]/88 px-3.5 py-2.5 shadow-lg">
            {/* HP Pips */}
            <div className="flex items-center gap-1.5" aria-label={`Health ${hud.hp} of ${hud.maxHp}`}>
              {Array.from({ length: hud.maxHp }).map((_, i) => (
                <svg key={i} width="20" height="20" viewBox="0 0 24 24">
                  <path
                    d="M12 21s-7-4.5-9.2-8.4C1.2 9.7 2.8 6 6.5 6c2 0 3.7 1.1 5.5 3 1.8-1.9 3.5-3 5.5-3 3.7 0 5.3 3.7 3.7 6.6C19 16.5 12 21 12 21z"
                    fill={i < hud.hp ? '#F43F5E' : '#1E293B'}
                    stroke={i < hud.hp ? '#FDA4AF' : '#475569'}
                    strokeWidth="2"
                  />
                </svg>
              ))}
            </div>

            <div className="h-5 w-px bg-slate-700" />

            <div>
              <div className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
                {currentLevel.name}
              </div>
              <div className="flex items-center gap-3 font-mono-num text-sm font-bold text-white">
                <span>SCORE {hud.score}</span>
                <span className="text-amber-400">+{hud.coins} COINS</span>
              </div>
            </div>

            {hud.shieldReady && (
              <div className="flex items-center gap-1 text-xs font-bold text-amber-300 border-l border-slate-700 pl-3">
                <Shield className="w-4 h-4 text-sky-400" />
                <span>ZAI SHIELD</span>
              </div>
            )}
          </div>

          {/* Top-Right Compact Utility Buttons */}
          <div className="pointer-events-auto flex items-center gap-2">
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onToggleMute();
              }}
              aria-label="Mute toggle [M]"
              className="p-2.5 rounded-lg border border-slate-700/80 bg-[#0A0F1A]/88 text-slate-200 hover:border-slate-500 cursor-pointer"
            >
              {profile.settings.muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                togglePause();
              }}
              aria-label="Pause [P]"
              className="p-2.5 rounded-lg border border-slate-700/80 bg-[#0A0F1A]/88 text-slate-200 hover:border-slate-500 cursor-pointer"
            >
              <Pause className="w-4 h-4" />
            </button>
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                restartStage();
              }}
              aria-label="Restart [R]"
              className="p-2.5 rounded-lg border border-slate-700/80 bg-[#0A0F1A]/88 text-slate-200 hover:border-slate-500 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onExitToMenu();
              }}
              aria-label={t.backToMenu}
              className="px-3 py-2 rounded-lg border border-slate-700/80 bg-[#0A0F1A]/88 text-xs font-bold text-slate-200 hover:border-amber-400 cursor-pointer flex items-center gap-1.5"
            >
              <Home className="w-3.5 h-3.5" />
              <span>Menu</span>
            </button>
          </div>
        </div>

        {/* Bottom-Left Compact Live Web Ability Cues */}
        <div className="flex items-end justify-between">
          <div className="flex items-center gap-3 rounded-lg border border-slate-700/75 bg-[#0A0F1A]/85 px-3 py-2 text-xs font-mono-num">
            <span className="text-sky-300">
              <strong className="text-white">[E]</strong> {hud.shelterLabel} WEB HOUSE
            </span>
            <span className="text-slate-600">·</span>
            <span className={hud.webState === 'attached' ? 'text-amber-300' : hud.anchorReady ? 'text-emerald-300' : 'text-slate-400'}>
              <strong className="text-white">[Q]</strong>{' '}
              {hud.webState === 'attached'
                ? 'RELEASE WEB'
                : hud.anchorReady
                  ? 'ANCHOR LOCKED'
                  : 'MOVE NEAR ANCHOR'}
            </span>
          </div>
        </div>
      </div>

      {/* Pause Modal */}
      {playState === 'paused' && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-sm rounded-xl border border-slate-700 bg-[#0D131F] p-6 space-y-5 shadow-2xl">
            <h2 className="text-2xl font-bold text-white text-center">{t.pause}</h2>
            <p className="text-xs text-slate-400 text-center">{currentLevel.objectiveText}</p>
            <div className="space-y-2.5">
              <button
                type="button"
                onClick={togglePause}
                className="w-full py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm cursor-pointer flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>{t.resume}</span>
              </button>
              <button
                type="button"
                onClick={restartStage}
                className="w-full py-2.5 rounded-lg border border-slate-700 bg-[#080B12] hover:border-slate-500 text-slate-200 font-semibold text-sm cursor-pointer"
              >
                {t.restart}
              </button>
              <button
                type="button"
                onClick={onExitToMenu}
                className="w-full py-2.5 rounded-lg border border-slate-800 bg-transparent hover:bg-slate-800/50 text-slate-400 hover:text-white text-sm cursor-pointer"
              >
                {t.backToMenu}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Victory / Game Over Modal */}
      {playState === 'gameover' && summary && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/75 p-4">
          <div
            className={`w-full max-w-md rounded-xl border p-6 space-y-5 shadow-2xl ${
              summary.won
                ? 'border-amber-400/80 bg-[#0D131F]'
                : 'border-rose-500/70 bg-[#120D14]'
            }`}
          >
            <div className="text-center space-y-1">
              <div className="text-xs font-bold uppercase tracking-wider text-amber-400">
                {currentLevel.subtitle}
              </div>
              <h2 className="text-3xl font-extrabold text-white">
                {summary.won ? t.victory : t.gameOver}
              </h2>
            </div>

            <div className="grid grid-cols-3 gap-2.5 text-center">
              <div className="rounded-lg border border-slate-800 bg-[#080B12] p-3">
                <div className="text-[11px] text-slate-400">SCORE</div>
                <div className="font-mono-num text-lg font-bold text-white">{summary.score}</div>
              </div>
              <div className="rounded-lg border border-slate-800 bg-[#080B12] p-3">
                <div className="text-[11px] text-slate-400">COINS</div>
                <div className="font-mono-num text-lg font-bold text-amber-400">
                  +{summary.coins}
                </div>
              </div>
              <div className="rounded-lg border border-slate-800 bg-[#080B12] p-3">
                <div className="text-[11px] text-slate-400">DISTANCE</div>
                <div className="font-mono-num text-lg font-bold text-sky-300">
                  {summary.distanceM}m
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 font-mono-num px-1">
              <span>Web Houses: {summary.housesBuilt}</span>
              <span>Swings: {summary.webAttaches}</span>
              <span>Time: {summary.clearTimeSec}s</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5">
              {summary.won && stageId < GAME_LEVELS.length ? (
                <button
                  type="button"
                  data-start="true"
                  onClick={() => {
                    onSelectStage(stageId + 1);
                    setSummary(null);
                    setPlayState('playing');
                    setRunNonce((n) => n + 1);
                  }}
                  className="flex-1 py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm cursor-pointer"
                >
                  {t.nextStage}
                </button>
              ) : (
                <button
                  type="button"
                  data-start="true"
                  onClick={restartStage}
                  className="flex-1 py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm cursor-pointer"
                >
                  {t.playAgain}
                </button>
              )}
              <button
                type="button"
                onClick={onExitToMenu}
                className="flex-1 py-3 rounded-lg border border-slate-700 bg-[#080B12] hover:border-slate-500 text-slate-200 font-semibold text-sm cursor-pointer"
              >
                {t.backToMenu}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
