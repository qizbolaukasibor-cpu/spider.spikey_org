import React from 'react';
import { ArrowLeft, Award, Check, Coins, ShieldCheck } from 'lucide-react';
import { SEASON_MISSIONS, SEASON_PASS_LEVELS } from '../data/catalog';
import { getTranslations } from '../data/translations';
import { PlayerProfile, SeasonMission, SeasonPassReward } from '../types/game';
import { soundEngine } from '../utils/audio';
import { getSeasonPassLevelFromXp } from '../utils/storage';

interface SeasonPassScreenProps {
  profile: PlayerProfile;
  onBack: () => void;
  onClaimLevel: (reward: SeasonPassReward) => void;
  onClaimMission: (mission: SeasonMission) => void;
}

export const SeasonPassScreen: React.FC<SeasonPassScreenProps> = ({
  profile,
  onBack,
  onClaimLevel,
  onClaimMission,
}) => {
  const t = getTranslations(profile.settings.language);
  const currentTier = getSeasonPassLevelFromXp(profile.seasonPassXp);

  const getMissionProgress = (m: SeasonMission): number => {
    switch (m.metric) {
      case 'distance':
        return profile.metrics.distanceTraveled;
      case 'web_houses':
        return profile.metrics.webHousesBuilt;
      case 'web_attaches':
        return profile.metrics.webAttaches;
      case 'levels_completed':
        return profile.metrics.levelsCompleted;
      case 'coins_collected':
        return profile.metrics.coinsCollectedInGame;
      case 'cases_opened':
        return profile.metrics.casesOpened;
    }
  };

  return (
    <div className="relative z-10 min-h-screen w-full bg-[#080B12]/95 p-4 md:p-7">
      <div className="max-w-[1400px] mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                onBack();
              }}
              className="p-2.5 rounded-lg border border-slate-700 bg-[#0D131F] text-slate-200 hover:border-amber-400 cursor-pointer"
              aria-label={t.backToMenu}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-violet-400" />
                <span>{t.seasonPass} — 50 LEVELS</span>
              </h1>
              <p className="text-xs text-slate-400">
                Complete gameplay missions to earn Season XP and unlock Coins, Cases, and Skins.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-slate-400">Season Tier</div>
              <div className="font-mono-num text-lg font-bold text-amber-300">
                {currentTier} / 50 · {profile.seasonPassXp.toLocaleString()} XP
              </div>
            </div>
          </div>
        </div>

        {/* Missions Grid */}
        <section className="space-y-3">
          <h2 className="text-lg font-bold text-white">Active Season Missions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {SEASON_MISSIONS.map((m) => {
              const prog = getMissionProgress(m);
              const pct = Math.min(100, Math.round((prog / m.target) * 100));
              const claimed = profile.claimedMissionIds.includes(m.id);
              const ready = prog >= m.target && !claimed;

              const diffColor =
                m.difficulty === 'EASY'
                  ? 'text-emerald-400'
                  : m.difficulty === 'MEDIUM'
                    ? 'text-sky-400'
                    : m.difficulty === 'HARD'
                      ? 'text-orange-400'
                      : 'text-rose-400';

              return (
                <div
                  key={m.id}
                  className="rounded-xl border border-slate-800 bg-[#0D131F] p-4 flex flex-col justify-between gap-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className={diffColor}>{m.difficulty}</span>
                      <span className="font-mono-num text-amber-300">
                        +{m.xpReward} XP · +{m.coinReward}c
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-white">{m.title}</h3>
                    <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-violet-400 transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <div className="text-[11px] font-mono-num text-slate-400">
                      {Math.min(prog, m.target).toLocaleString()} / {m.target.toLocaleString()}
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={!ready}
                    onClick={() => {
                      soundEngine.playPurchase();
                      onClaimMission(m);
                    }}
                    className={`w-full py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 ${
                      claimed
                        ? 'bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 cursor-default'
                        : ready
                          ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    {claimed && <Check className="w-3.5 h-3.5" />}
                    <span>{claimed ? t.claimed : ready ? t.claim : 'In Progress'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </section>

        {/* 50-Level Reward Track */}
        <section className="space-y-3">
          <h2 className="text-lg font-bold text-white">50-Level Reward Track</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-5 gap-3">
            {SEASON_PASS_LEVELS.map((lvl) => {
              const unlocked = profile.seasonPassXp >= lvl.xpRequired;
              const claimed = profile.claimedSeasonLevels.includes(lvl.level);
              const isMilestone = lvl.level % 5 === 0;

              return (
                <div
                  key={lvl.level}
                  className={`rounded-xl border p-3.5 flex flex-col justify-between gap-2.5 ${
                    lvl.level === 50
                      ? 'border-amber-400 bg-[#0A0908]'
                      : isMilestone
                        ? 'border-violet-500/50 bg-[#111221]'
                        : 'border-slate-800 bg-[#0D131F]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono-num font-bold text-white">Lv.{lvl.level}</span>
                      <span className="font-mono-num text-[11px] text-slate-400">
                        {lvl.xpRequired} XP
                      </span>
                    </div>
                    <div className="mt-2 text-xs font-bold text-amber-300 flex items-center gap-1.5">
                      {lvl.rewardType === 'coins' ? (
                        <Coins className="w-3.5 h-3.5 shrink-0" />
                      ) : (
                        <ShieldCheck className="w-3.5 h-3.5 shrink-0 text-violet-300" />
                      )}
                      <span className="truncate">{lvl.label}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={!unlocked || claimed}
                    onClick={() => {
                      soundEngine.playPurchase();
                      onClaimLevel(lvl);
                    }}
                    className={`w-full py-1.5 rounded text-xs font-bold ${
                      claimed
                        ? 'bg-emerald-950/50 text-emerald-300 cursor-default'
                        : unlocked
                          ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer'
                          : 'bg-slate-800/70 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    {claimed ? t.claimed : unlocked ? t.claim : 'Locked'}
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
};
