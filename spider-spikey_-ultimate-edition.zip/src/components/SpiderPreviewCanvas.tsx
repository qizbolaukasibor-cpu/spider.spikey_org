import React, { useEffect, useRef } from 'react';
import { computeEffectiveLoadout } from '../game/physics';
import { drawSpiderSpikeyPixel, drawStyledWebLine } from '../game/renderer';
import { EquippedLoadout } from '../types/game';

interface SpiderPreviewCanvasProps {
  equipped: EquippedLoadout;
  width?: number;
  height?: number;
  showWebDemo?: boolean;
  className?: string;
}

export const SpiderPreviewCanvas: React.FC<SpiderPreviewCanvasProps> = ({
  equipped,
  width = 200,
  height = 140,
  showWebDemo = true,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const equippedRef = useRef(equipped);
  equippedRef.current = equipped;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let timerId = 0;
    let rafId = 0;
    let cancelled = false;
    const start = performance.now();

    const draw = (now: number) => {
      if (cancelled) return;
      const t = (now - start) / 1000;
      const loadout = computeEffectiveLoadout(equippedRef.current);

      ctx.clearRect(0, 0, width, height);

      ctx.fillStyle = loadout.isZaiActive
        ? 'rgba(245, 196, 81, 0.22)'
        : 'rgba(56, 189, 248, 0.16)';
      ctx.fillRect(16, height - 22, width - 32, 2);

      const cx = width * 0.42;
      const cy = height - 42;

      if (showWebDemo) {
        const anchorX = width * 0.82;
        const anchorY = 22;
        drawStyledWebLine(
          ctx,
          cx + 8,
          cy - 12,
          anchorX,
          anchorY,
          loadout.webStyle,
          loadout.webColor,
          loadout.webGlow,
          t,
          1
        );
        ctx.fillStyle = loadout.webGlow;
        ctx.fillRect(anchorX - 4, anchorY - 4, 8, 8);
      }

      drawSpiderSpikeyPixel(ctx, cx, cy, {
        facing: 1,
        scaleX: 1.35,
        scaleY: 1.35,
        walkCycle: t * 4,
        isGrounded: true,
        isSwinging: false,
        hitFlash: 0,
        time: t,
        loadout,
        shieldReady: loadout.abilities.has('ZAI_CRYSTAL_SHIELD'),
      });

      timerId = window.setTimeout(() => {
        if (!cancelled) rafId = requestAnimationFrame(draw);
      }, 42);
    };

    rafId = requestAnimationFrame(draw);
    return () => {
      cancelled = true;
      clearTimeout(timerId);
      cancelAnimationFrame(rafId);
    };
  }, [width, height, showWebDemo]);

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className={`block ${className}`}
    />
  );
};
