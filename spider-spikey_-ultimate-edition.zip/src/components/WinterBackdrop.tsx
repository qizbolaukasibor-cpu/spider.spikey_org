import React, { useEffect, useRef } from 'react';
import { computeEffectiveLoadout } from '../game/physics';
import { drawSpiderSpikeyPixel, drawStyledWebLine } from '../game/renderer';
import { EquippedLoadout } from '../types/game';

interface WinterBackdropProps {
  equipped: EquippedLoadout;
  animationsEnabled?: boolean;
  highQuality?: boolean;
}

export const WinterBackdrop: React.FC<WinterBackdropProps> = ({
  equipped,
  animationsEnabled = true,
  highQuality = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const equippedRef = useRef(equipped);
  equippedRef.current = equipped;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bgBuffer = document.createElement('canvas');
    const bgCtx = bgBuffer.getContext('2d');

    const drawFrostedCornerWeb = (
      c: CanvasRenderingContext2D,
      ox: number,
      oy: number,
      dirX: number,
      dirY: number,
      radius: number
    ) => {
      c.save();
      c.strokeStyle = 'rgba(224, 242, 254, 0.25)';
      c.lineWidth = 1.2;
      const spokes = 5;
      for (let i = 0; i <= spokes; i++) {
        const ang = (Math.PI / 2) * (i / spokes);
        c.beginPath();
        c.moveTo(ox, oy);
        c.lineTo(ox + Math.cos(ang) * radius * dirX, oy + Math.sin(ang) * radius * dirY);
        c.stroke();
      }
      for (let r = 1; r <= 4; r++) {
        const frac = r / 4.2;
        c.beginPath();
        for (let i = 0; i <= spokes; i++) {
          const ang = (Math.PI / 2) * (i / spokes);
          const wx = ox + Math.cos(ang) * radius * frac * dirX;
          const wy = oy + Math.sin(ang) * radius * frac * dirY;
          if (i === 0) c.moveTo(wx, wy);
          else c.lineTo(wx, wy);
        }
        c.stroke();
      }
      c.restore();
    };

    const paintStaticBackground = (w: number, h: number) => {
      if (!bgCtx) return;
      bgBuffer.width = w;
      bgBuffer.height = h;

      const sky = bgCtx.createLinearGradient(0, 0, 0, h);
      sky.addColorStop(0, '#050811');
      sky.addColorStop(0.55, '#0D1B32');
      sky.addColorStop(1, '#162C4A');
      bgCtx.fillStyle = sky;
      bgCtx.fillRect(0, 0, w, h);

      // Moon
      const moonX = w * 0.82;
      const moonY = h * 0.18;
      bgCtx.fillStyle = 'rgba(224, 242, 254, 0.1)';
      bgCtx.beginPath();
      bgCtx.arc(moonX, moonY, 85, 0, Math.PI * 2);
      bgCtx.fill();
      bgCtx.fillStyle = '#E0F2FE';
      bgCtx.beginPath();
      bgCtx.arc(moonX, moonY, 32, 0, Math.PI * 2);
      bgCtx.fill();

      // Frozen mountains
      bgCtx.fillStyle = '#0B1628';
      bgCtx.beginPath();
      bgCtx.moveTo(0, h);
      const peaks = [
        [0, 0.62],
        [0.14, 0.42],
        [0.28, 0.56],
        [0.44, 0.36],
        [0.6, 0.54],
        [0.77, 0.39],
        [0.92, 0.52],
        [1, 0.45],
      ];
      for (const [px, py] of peaks) {
        bgCtx.lineTo(px * w, py * h);
      }
      bgCtx.lineTo(w, h);
      bgCtx.closePath();
      bgCtx.fill();

      // Snow ridges
      bgCtx.fillStyle = 'rgba(186, 230, 253, 0.22)';
      for (const [px, py] of [peaks[1], peaks[3], peaks[5]]) {
        bgCtx.beginPath();
        bgCtx.moveTo(px * w, py * h);
        bgCtx.lineTo(px * w - 34, py * h + 46);
        bgCtx.lineTo(px * w + 26, py * h + 42);
        bgCtx.closePath();
        bgCtx.fill();
      }

      // Ice-covered tower
      const towerX = w * 0.72;
      const towerY = h * 0.56;
      bgCtx.fillStyle = '#112138';
      bgCtx.fillRect(towerX, towerY, 96, h - towerY);
      bgCtx.fillStyle = '#BAE6FD';
      bgCtx.fillRect(towerX - 4, towerY, 104, 6);

      // Snow-covered pine trees seated on a snowy winter ridge
      bgCtx.fillStyle = '#0B1A2E';
      bgCtx.fillRect(0, h - 28, w, 28);
      bgCtx.fillStyle = 'rgba(186, 230, 253, 0.25)';
      bgCtx.fillRect(0, h - 28, w, 3);

      for (let x = 35; x < w; x += 105) {
        const treeH = 72 + ((x * 19) % 40);
        const base = h - 26;
        bgCtx.fillStyle = '#0D1E34';
        bgCtx.beginPath();
        bgCtx.moveTo(x, base - treeH);
        bgCtx.lineTo(x - 32, base);
        bgCtx.lineTo(x + 32, base);
        bgCtx.closePath();
        bgCtx.fill();

        bgCtx.fillStyle = '#122945';
        bgCtx.beginPath();
        bgCtx.moveTo(x, base - treeH * 0.72);
        bgCtx.lineTo(x - 38, base);
        bgCtx.lineTo(x + 38, base);
        bgCtx.closePath();
        bgCtx.fill();

        bgCtx.fillStyle = '#E2E8F0';
        bgCtx.beginPath();
        bgCtx.moveTo(x, base - treeH);
        bgCtx.lineTo(x - 13, base - treeH + 24);
        bgCtx.lineTo(x + 13, base - treeH + 24);
        bgCtx.closePath();
        bgCtx.fill();
      }

      drawFrostedCornerWeb(bgCtx, 0, 0, 1, 1, 175);
      drawFrostedCornerWeb(bgCtx, w, 0, -1, 1, 165);

      // Ledge positioned in open lower-right area clear of menu cards
      const ledgeX = w * 0.74;
      const ledgeY = h * 0.84;
      bgCtx.fillStyle = '#162840';
      bgCtx.fillRect(ledgeX, ledgeY, 260, h - ledgeY);
      bgCtx.fillStyle = '#E0F2FE';
      bgCtx.fillRect(ledgeX, ledgeY, 260, 6);
      bgCtx.fillStyle = '#334155';
      bgCtx.fillRect(ledgeX + 204, ledgeY - 58, 4, 58);
    };

    const resize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      canvas.width = w;
      canvas.height = h;
      paintStaticBackground(w, h);
    };
    resize();
    window.addEventListener('resize', resize);

    const snow = Array.from({ length: highQuality ? 55 : 24 }, (_, i) => ({
      x: (i * 137) % 1600,
      y: (i * 89) % 1000,
      speed: 24 + (i % 5) * 11,
      drift: (i % 3) - 1,
      size: i % 4 === 0 ? 3 : 2,
    }));

    let raf = 0;
    let timerId = 0;
    let cancelled = false;
    const start = performance.now();

    const renderFrame = (now: number) => {
      if (cancelled) return;
      const t = animationsEnabled ? (now - start) / 1000 : 0;
      const w = canvas.width;
      const h = canvas.height;
      const loadout = computeEffectiveLoadout(equippedRef.current);

      if (bgCtx) {
        ctx.drawImage(bgBuffer, 0, 0);
      }

      // Glowing lantern windows
      const towerX = w * 0.72;
      const towerY = h * 0.56;
      const glowAlpha = 0.65 + Math.sin(t * 2.5) * 0.15;
      ctx.fillStyle = `rgba(245, 196, 81, ${glowAlpha})`;
      ctx.fillRect(towerX + 24, towerY + 28, 14, 22);
      ctx.fillRect(towerX + 58, towerY + 28, 14, 22);
      ctx.fillRect(towerX + 41, towerY + 72, 14, 22);

      const ledgeX = w * 0.74;
      const ledgeY = h * 0.84;
      ctx.fillStyle = '#F5C451';
      ctx.fillRect(ledgeX + 199, ledgeY - 68, 14, 12);

      const spikeyX = ledgeX + 76;
      const spikeyY = ledgeY - 18 + Math.sin(t * 2.2) * 1.5;

      drawStyledWebLine(
        ctx,
        spikeyX + 12,
        spikeyY - 12,
        ledgeX + 205,
        ledgeY - 62,
        loadout.webStyle,
        loadout.webColor,
        loadout.webGlow,
        t,
        1
      );

      drawSpiderSpikeyPixel(ctx, spikeyX, spikeyY, {
        facing: -1,
        scaleX: 1.85,
        scaleY: 1.85,
        walkCycle: t * 2.2,
        isGrounded: true,
        isSwinging: false,
        hitFlash: 0,
        time: t,
        loadout,
        shieldReady: loadout.abilities.has('ZAI_CRYSTAL_SHIELD'),
      });

      ctx.fillStyle = 'rgba(240, 249, 255, 0.75)';
      for (const s of snow) {
        const sy = (s.y + t * s.speed) % h;
        const sx = (s.x + t * s.drift * 14 + Math.sin(t + s.y * 0.02) * 8 + w) % w;
        ctx.fillRect(Math.round(sx), Math.round(sy), s.size, s.size);
      }

      if (animationsEnabled) {
        timerId = window.setTimeout(() => {
          if (!cancelled) raf = requestAnimationFrame(renderFrame);
        }, 50);
      }
    };

    raf = requestAnimationFrame(renderFrame);
    return () => {
      cancelled = true;
      clearTimeout(timerId);
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, [animationsEnabled, highQuality]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="fixed inset-0 h-full w-full pointer-events-none"
    />
  );
};
