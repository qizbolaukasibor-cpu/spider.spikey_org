import React, { useState } from 'react';
import { ArrowLeft, Globe, RotateCcw, Settings, Trash2 } from 'lucide-react';
import { getTranslations, SUPPORTED_LANGUAGES } from '../data/translations';
import { GameSettings, PlayerProfile } from '../types/game';
import { soundEngine } from '../utils/audio';

interface SettingsScreenProps {
  profile: PlayerProfile;
  onBack: () => void;
  onUpdateSettings: (next: GameSettings) => void;
  onOpenLanguagePicker: () => void;
  onResetSettingsOnly: () => void;
  onResetAllProgress: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  profile,
  onBack,
  onUpdateSettings,
  onOpenLanguagePicker,
  onResetSettingsOnly,
  onResetAllProgress,
}) => {
  const s = profile.settings;
  const t = getTranslations(s.language);
  const [confirmResetModal, setConfirmResetModal] = useState(false);

  const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === s.language);

  return (
    <div className="relative z-10 min-h-screen w-full bg-[#080B12]/95 p-4 md:p-7">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <button
            type="button"
            onClick={() => {
              soundEngine.playMenuClick();
              onBack();
            }}
            className="p-2.5 rounded-lg border border-slate-700 bg-[#0D131F] text-slate-200 hover:border-amber-400 cursor-pointer"
            aria-label={t.backToMenu}
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <Settings className="w-5 h-5 text-slate-300" />
              <span>{t.settings}</span>
            </h1>
            <p className="text-xs text-slate-400">
              Audio levels, visual quality, language, controls, and save management.
            </p>
          </div>
        </div>

        {/* Audio & Graphics */}
        <div className="rounded-xl border border-slate-800 bg-[#0D131F] p-5 space-y-5">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <label htmlFor="music-vol" className="font-semibold text-white">
                {t.musicVolume}
              </label>
              <span className="font-mono-num text-amber-300">{s.musicVolume}%</span>
            </div>
            <input
              id="music-vol"
              type="range"
              min={0}
              max={100}
              value={s.musicVolume}
              onChange={(e) =>
                onUpdateSettings({ ...s, musicVolume: Number(e.target.value) })
              }
              className="w-full accent-amber-400"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <label htmlFor="sfx-vol" className="font-semibold text-white">
                {t.sfxVolume}
              </label>
              <span className="font-mono-num text-amber-300">{s.sfxVolume}%</span>
            </div>
            <input
              id="sfx-vol"
              type="range"
              min={0}
              max={100}
              value={s.sfxVolume}
              onChange={(e) =>
                onUpdateSettings({ ...s, sfxVolume: Number(e.target.value) })
              }
              className="w-full accent-amber-400"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800">
            <span className="text-sm font-semibold text-white">{t.graphicsQuality}</span>
            <div className="flex gap-2">
              {(['low', 'medium', 'high'] as const).map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => {
                    soundEngine.playMenuClick();
                    onUpdateSettings({ ...s, graphicsQuality: q });
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold uppercase border cursor-pointer ${
                    s.graphicsQuality === q
                      ? 'border-amber-400 bg-amber-400 text-slate-950'
                      : 'border-slate-700 bg-[#080B12] text-slate-300'
                  }`}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <span className="text-sm font-semibold text-white">{t.animations}</span>
            <button
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                onUpdateSettings({ ...s, animationsEnabled: !s.animationsEnabled });
              }}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold border cursor-pointer ${
                s.animationsEnabled
                  ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200'
                  : 'border-slate-700 bg-[#080B12] text-slate-400'
              }`}
            >
              {s.animationsEnabled ? 'Enabled' : 'Reduced'}
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <div>
              <div className="text-sm font-semibold text-white">{t.language}</div>
              <div className="text-xs text-slate-400">
                {currentLangObj?.nativeName} ({currentLangObj?.name})
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                onOpenLanguagePicker();
              }}
              className="px-4 py-2 rounded-lg border border-slate-700 bg-[#080B12] hover:border-amber-400 text-xs font-bold text-white flex items-center gap-2 cursor-pointer"
            >
              <Globe className="w-4 h-4 text-sky-400" />
              <span>Change Language</span>
            </button>
          </div>
        </div>

        {/* Control Bindings */}
        <div className="rounded-xl border border-slate-800 bg-[#0D131F] p-5 space-y-3">
          <h2 className="text-base font-bold text-white">{t.controls}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            {[
              ['Move Left / Right', `${s.controls.moveLeft} · ${s.controls.moveRight}`],
              ['Jump / Double Jump', s.controls.jump],
              ['Adaptive Web House', s.controls.webHouse],
              ['Web Shoot / Swing / Release', s.controls.webShoot],
              ['Pause Game', s.controls.pause],
              ['Mute Audio', 'KeyM'],
            ].map(([act, keys]) => (
              <div
                key={act}
                className="flex items-center justify-between rounded-lg border border-slate-800 bg-[#080B12] px-3 py-2.5"
              >
                <span className="text-slate-300">{act}</span>
                <span className="font-mono-num font-bold text-amber-300">{keys}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Reset Options */}
        <div className="rounded-xl border border-slate-800 bg-[#0D131F] p-5 flex flex-wrap gap-3 justify-between">
          <button
            type="button"
            onClick={() => {
              soundEngine.playMenuClick();
              onResetSettingsOnly();
            }}
            className="px-4 py-2.5 rounded-lg border border-slate-700 bg-[#080B12] hover:border-slate-500 text-xs font-bold text-slate-200 flex items-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Audio & Graphics</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundEngine.playMenuClick();
              setConfirmResetModal(true);
            }}
            className="px-4 py-2.5 rounded-lg border border-rose-500/60 bg-rose-950/30 hover:bg-rose-950/50 text-xs font-bold text-rose-200 flex items-center gap-2 cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>{t.resetProgress}</span>
          </button>
        </div>
      </div>

      {/* Confirmation Dialog before resetting saved progress */}
      {confirmResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="w-full max-w-sm rounded-xl border border-rose-500/70 bg-[#120D14] p-6 space-y-4">
            <h2 className="text-lg font-bold text-white">Confirm Progress Reset</h2>
            <p className="text-xs text-slate-300 leading-relaxed">{t.confirmReset}</p>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => {
                  soundEngine.playHurt();
                  setConfirmResetModal(false);
                  onResetAllProgress();
                }}
                className="flex-1 py-2.5 rounded-lg bg-rose-500 hover:bg-rose-400 text-white font-bold text-xs cursor-pointer"
              >
                Reset Everything
              </button>
              <button
                type="button"
                onClick={() => setConfirmResetModal(false)}
                className="flex-1 py-2.5 rounded-lg border border-slate-700 text-slate-200 text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
