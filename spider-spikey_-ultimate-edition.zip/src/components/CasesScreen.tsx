import React, { useState } from 'react';
import { ArrowLeft, Coins, Crown, Gift, Sparkles } from 'lucide-react';
import { CASE_DEFINITIONS, RARITY_META } from '../data/catalog';
import { getTranslations } from '../data/translations';
import { CaseDefinition, CatalogItem, PlayerProfile, Rarity } from '../types/game';
import { soundEngine } from '../utils/audio';

interface CasesScreenProps {
  profile: PlayerProfile;
  onBack: () => void;
  onBuyCase: (caseDef: CaseDefinition) => { ok: boolean; error?: string };
  onOpenCase: (caseDef: CaseDefinition) =>
    | {
        ok: true;
        reward: CatalogItem;
        rarity: Rarity;
        wasDuplicate: boolean;
        bonusCoins: number;
      }
    | { ok: false; error: string };
}

export const CasesScreen: React.FC<CasesScreenProps> = ({
  profile,
  onBack,
  onBuyCase,
  onOpenCase,
}) => {
  const t = getTranslations(profile.settings.language);
  const [openingCase, setOpeningCase] = useState<CaseDefinition | null>(null);
  const [animPhase, setAnimPhase] = useState<'spinning' | 'revealed'>('spinning');
  const [spinLabel, setSpinLabel] = useState<string>('COMMON');
  const [revealResult, setRevealResult] = useState<{
    reward: CatalogItem;
    rarity: Rarity;
    wasDuplicate: boolean;
    bonusCoins: number;
  } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleOpen = (c: CaseDefinition) => {
    setErrorMsg(null);
    const res = onOpenCase(c);
    if (!res.ok) {
      soundEngine.playHurt();
      setErrorMsg(res.error);
      return;
    }

    setOpeningCase(c);
    setAnimPhase('spinning');
    setRevealResult(null);

    const poolLabels = c.drops.map((d) => RARITY_META[d.rarity].label);
    let tick = 0;
    const timer = window.setInterval(() => {
      tick += 1;
      setSpinLabel(poolLabels[tick % poolLabels.length]);
      soundEngine.playCaseSpinTick();
      if (tick >= 16) {
        clearInterval(timer);
        setAnimPhase('revealed');
        setRevealResult({
          reward: res.reward,
          rarity: res.rarity,
          wasDuplicate: res.wasDuplicate,
          bonusCoins: res.bonusCoins,
        });
        soundEngine.playRareReveal(
          res.rarity === 'ZAI_LIMITED' || res.rarity === 'MYTHIC' || res.rarity === 'LEGENDARY'
        );
      }
    }, 95);
  };

  return (
    <div className="relative z-10 min-h-screen w-full bg-[#080B12]/95 p-4 md:p-7">
      <div className="max-w-[1400px] mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                onBack();
              }}
              className="p-2.5 rounded-lg border border-slate-700 bg-[#0D131F] text-slate-200 hover:border-amber-400 cursor-pointer"
              aria-label={t.backToMenu}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                <Gift className="w-5 h-5 text-orange-400" />
                <span>{t.cases}</span>
              </h1>
              <p className="text-xs text-slate-400">
                Transparent 100%-verified drop odds using virtual in-game coins only.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-950/30 px-4 py-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="font-mono-num font-bold text-amber-300">
              {profile.coins.toLocaleString()}
            </span>
          </div>
        </div>

        {errorMsg && (
          <div className="rounded-lg border border-rose-500/50 bg-rose-950/30 px-4 py-2.5 text-sm text-rose-200">
            {errorMsg}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {CASE_DEFINITIONS.map((c) => {
            const owned = profile.casesOwned[c.id] || 0;
            const meta = RARITY_META[c.rarity];
            const canAfford = profile.coins >= c.price;

            return (
              <div
                key={c.id}
                style={{ borderColor: meta.border }}
                className={`rounded-xl border p-5 flex flex-col justify-between gap-4 ${
                  c.isZaiLimited ? 'zai-shimmer' : 'bg-[#0D131F]'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold tracking-wider" style={{ color: meta.color }}>
                      {meta.label}
                    </span>
                    <span className="font-mono-num font-bold text-white">
                      Owned: {owned}
                    </span>
                  </div>

                  {/* Case Crate Visual */}
                  <div
                    className="h-24 rounded-lg border border-slate-800 flex items-center justify-center relative"
                    style={{
                      background: c.isZaiLimited
                        ? 'radial-gradient(circle, rgba(245,196,81,0.22), #07070A 75%)'
                        : `radial-gradient(circle, ${c.accentColor}22, #070A11 75%)`,
                    }}
                  >
                    {c.isZaiLimited ? (
                      <div className="flex flex-col items-center gap-1">
                        <Crown className="w-8 h-8 text-amber-400" />
                        <span className="font-mono-num text-[10px] font-bold tracking-widest text-amber-300">
                          ZAI VAULT
                        </span>
                      </div>
                    ) : (
                      <Gift className="w-9 h-9" style={{ color: c.accentColor }} />
                    )}
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white">{c.name}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">{c.description}</p>
                  </div>

                  {/* Probability Table (totals 100%) */}
                  <div className="rounded-lg bg-[#080B12] border border-slate-800/80 p-2.5 space-y-1">
                    {c.drops.map((d) => (
                      <div key={d.rarity} className="flex items-center justify-between text-[11px] font-mono-num">
                        <span style={{ color: RARITY_META[d.rarity].color }}>
                          {RARITY_META[d.rarity].label}
                        </span>
                        <span className="text-slate-200">{d.probability}%</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    disabled={owned <= 0}
                    onClick={() => handleOpen(c)}
                    className={`flex-1 py-2.5 rounded-lg text-xs font-bold transition-colors ${
                      owned > 0
                        ? 'bg-emerald-400 hover:bg-emerald-300 text-slate-950 cursor-pointer'
                        : 'bg-slate-800/60 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    {t.openCase} ({owned})
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const res = onBuyCase(c);
                      if (res.ok) {
                        soundEngine.playPurchase();
                        setErrorMsg(null);
                      } else {
                        soundEngine.playHurt();
                        setErrorMsg(res.error || t.insufficientCoins);
                      }
                    }}
                    className={`px-3 py-2.5 rounded-lg font-mono-num text-xs font-bold flex items-center gap-1 cursor-pointer ${
                      canAfford
                        ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Coins className="w-3.5 h-3.5" />
                    <span>{c.price}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Case Opening & Reveal Modal */}
      {openingCase && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div
            className={`w-full max-w-md rounded-2xl border p-7 text-center space-y-5 shadow-2xl ${
              openingCase.isZaiLimited
                ? 'border-amber-400 bg-[#08080B] zai-shimmer'
                : 'border-slate-600 bg-[#0D131F]'
            }`}
          >
            <div className="text-xs font-bold tracking-widest uppercase text-amber-400">
              {openingCase.name}
            </div>

            {animPhase === 'spinning' ? (
              <div className="py-10 space-y-4">
                <div className="w-20 h-20 mx-auto rounded-xl border-2 border-amber-400/70 bg-amber-500/10 flex items-center justify-center animate-bounce">
                  {openingCase.isZaiLimited ? (
                    <Crown className="w-10 h-10 text-amber-400" />
                  ) : (
                    <Gift className="w-10 h-10 text-sky-400" />
                  )}
                </div>
                <div className="font-mono-num text-lg font-extrabold text-white tracking-wider">
                  {spinLabel}
                </div>
                <p className="text-xs text-slate-400">Unlocking crystalline vault...</p>
              </div>
            ) : (
              revealResult && (
                <div className="space-y-4 py-2">
                  <div
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded text-xs font-extrabold tracking-widest"
                    style={{
                      color: RARITY_META[revealResult.rarity].color,
                      backgroundColor: RARITY_META[revealResult.rarity].bg,
                      border: `1px solid ${RARITY_META[revealResult.rarity].border}`,
                    }}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{RARITY_META[revealResult.rarity].label}</span>
                  </div>

                  <h2 className="text-2xl font-extrabold text-white">
                    {revealResult.reward.name}
                  </h2>
                  <p className="text-xs text-slate-300">{revealResult.reward.description}</p>

                  <div className="grid grid-cols-2 gap-2 text-xs font-mono-num bg-black/40 border border-slate-800 rounded-lg p-3 text-slate-200">
                    <div>Web Power: {revealResult.reward.stats.webPower}</div>
                    <div>Web Range: {revealResult.reward.stats.webRange}</div>
                    <div>Move Speed: {revealResult.reward.stats.moveSpeed}</div>
                    <div>Swing Boost: {revealResult.reward.stats.swingBoost}</div>
                  </div>

                  {revealResult.wasDuplicate ? (
                    <div className="text-xs text-amber-300 font-semibold">
                      Already owned — converted to +{revealResult.bonusCoins} Bonus Coins!
                    </div>
                  ) : (
                    <div className="text-xs text-emerald-300 font-semibold">
                      Added to your Inventory!
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => setOpeningCase(null)}
                    className="w-full py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm cursor-pointer"
                  >
                    Collect Reward
                  </button>
                </div>
              )
            )}
          </div>
        </div>
      )}
    </div>
  );
};
