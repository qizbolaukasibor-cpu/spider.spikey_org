import React, { useMemo, useState } from 'react';
import { ArrowLeft, Briefcase, Check, Crown, Eye, Search } from 'lucide-react';
import {
  CASE_DEFINITIONS,
  ITEM_BY_ID,
  RARITY_META,
  RARITY_ORDER,
  ZAI_ABILITIES_INFO,
} from '../data/catalog';
import { getTranslations } from '../data/translations';
import { CatalogItem, ItemCategory, PlayerProfile, Rarity } from '../types/game';
import { soundEngine } from '../utils/audio';
import { SpiderPreviewCanvas } from './SpiderPreviewCanvas';

interface InventoryScreenProps {
  profile: PlayerProfile;
  onBack: () => void;
  onEquipItem: (item: CatalogItem) => void;
  onUnequipCategory: (category: ItemCategory) => void;
  onOpenCasesTab: () => void;
}

export const InventoryScreen: React.FC<InventoryScreenProps> = ({
  profile,
  onBack,
  onEquipItem,
  onUnequipCategory,
  onOpenCasesTab,
}) => {
  const t = getTranslations(profile.settings.language);
  const [cat, setCat] = useState<'all' | ItemCategory | 'cases'>('all');
  const [rarityFilter, setRarityFilter] = useState<Rarity | 'ALL'>('ALL');
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<'rarity' | 'level' | 'name'>('rarity');
  const [inspectItem, setInspectItem] = useState<CatalogItem | null>(null);

  const ownedItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    return profile.ownedItemIds
      .map((id) => ITEM_BY_ID[id])
      .filter((item): item is CatalogItem => Boolean(item))
      .filter((item) => {
        if (cat !== 'all' && cat !== 'cases' && item.category !== cat) return false;
        if (rarityFilter !== 'ALL' && item.rarity !== rarityFilter) return false;
        if (q && !item.name.toLowerCase().includes(q)) return false;
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'rarity') {
          return RARITY_ORDER.indexOf(b.rarity) - RARITY_ORDER.indexOf(a.rarity);
        }
        if (sortBy === 'level') return b.level - a.level;
        return a.name.localeCompare(b.name);
      });
  }, [profile.ownedItemIds, cat, rarityFilter, search, sortBy]);

  const ownedCases = CASE_DEFINITIONS.filter((c) => (profile.casesOwned[c.id] || 0) > 0);

  const isItemEquipped = (item: CatalogItem): boolean =>
    profile.equipped.skinId === item.id ||
    profile.equipped.webId === item.id ||
    profile.equipped.effectId === item.id ||
    profile.equipped.animationId === item.id;

  const isDefaultStarter = (item: CatalogItem): boolean =>
    item.id === 'skin_classic_spikey' ||
    item.id === 'web_classic_silk' ||
    item.id === 'effect_snow_dust' ||
    item.id === 'anim_standard_flip';

  return (
    <div className="relative z-10 min-h-screen w-full bg-[#080B12]/95 p-4 md:p-7">
      <div className="max-w-[1400px] mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                onBack();
              }}
              className="p-2.5 rounded-lg border border-slate-700 bg-[#0D131F] text-slate-200 hover:border-amber-400 cursor-pointer"
              aria-label={t.backToMenu}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-emerald-400" />
                <span>{t.inventory}</span>
              </h1>
              <p className="text-xs text-slate-400">
                Equip skins, webs, effects, and animations — changes apply immediately in gameplay.
              </p>
            </div>
          </div>

          <div className="font-mono-num text-xs text-slate-300 bg-[#0D131F] border border-slate-700 px-3.5 py-2 rounded-lg">
            Owned Items: <strong className="text-white">{profile.ownedItemIds.length}</strong>
          </div>
        </div>

        {/* Active Loadout Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 rounded-xl border border-slate-700/80 bg-[#0D131F] p-5 items-center">
          <div className="lg:col-span-4 flex justify-center rounded-lg border border-slate-800 bg-[#070A11] p-2">
            <SpiderPreviewCanvas equipped={profile.equipped} width={260} height={150} />
          </div>
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-3">
            {(
              [
                ['Character Skin', profile.equipped.skinId],
                ['Web Design (Q)', profile.equipped.webId],
                ['Special Effect', profile.equipped.effectId],
                ['Animation Style', profile.equipped.animationId],
              ] as const
            ).map(([label, itemId]) => {
              const item = ITEM_BY_ID[itemId];
              const meta = item ? RARITY_META[item.rarity] : RARITY_META.COMMON;
              return (
                <div
                  key={label}
                  className="rounded-lg border border-slate-800 bg-[#080B12] p-3 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="text-[11px] text-slate-400">{label}</div>
                    <div className="text-sm font-bold text-white truncate">{item?.name}</div>
                    <div className="text-[11px] font-bold" style={{ color: meta.color }}>
                      {meta.label}
                    </div>
                  </div>
                  {item && !isDefaultStarter(item) && (
                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playMenuClick();
                        onUnequipCategory(item.category);
                      }}
                      className="px-2.5 py-1 rounded border border-slate-700 text-xs text-slate-300 hover:text-white cursor-pointer shrink-0"
                    >
                      {t.unequip}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-col lg:flex-row gap-3 justify-between">
          <div className="flex flex-wrap gap-1.5">
            {(
              [
                ['all', 'All'],
                ['skin', 'Skins'],
                ['web', 'Webs'],
                ['effect', 'Effects'],
                ['animation', 'Animations'],
                ['cases', `Cases (${ownedCases.reduce((s, c) => s + (profile.casesOwned[c.id] || 0), 0)})`],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => {
                  soundEngine.playMenuClick();
                  setCat(id);
                }}
                className={`px-3.5 py-2 rounded-lg text-xs font-bold border cursor-pointer ${
                  cat === id
                    ? 'border-amber-400 bg-amber-400 text-slate-950'
                    : 'border-slate-800 bg-[#0D131F] text-slate-300 hover:border-slate-600'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search collection..."
                className="pl-8 pr-3 py-2 rounded-lg bg-[#0D131F] border border-slate-700 text-xs text-white placeholder-slate-500 w-44"
              />
            </div>

            <select
              value={rarityFilter}
              onChange={(e) => setRarityFilter(e.target.value as Rarity | 'ALL')}
              className="px-3 py-2 rounded-lg bg-[#0D131F] border border-slate-700 text-xs text-slate-200"
            >
              <option value="ALL">All Rarities</option>
              {RARITY_ORDER.map((r) => (
                <option key={r} value={r}>
                  {RARITY_META[r].label}
                </option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'rarity' | 'level' | 'name')}
              className="px-3 py-2 rounded-lg bg-[#0D131F] border border-slate-700 text-xs text-slate-200"
            >
              <option value="rarity">Sort: Rarity</option>
              <option value="level">Sort: Level</option>
              <option value="name">Sort: Name</option>
            </select>
          </div>
        </div>

        {/* Owned Cases View */}
        {cat === 'cases' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {ownedCases.map((c) => (
              <div
                key={c.id}
                className="rounded-xl border border-amber-500/40 bg-[#0D131F] p-5 flex items-center justify-between gap-4"
              >
                <div>
                  <div className="text-xs font-bold" style={{ color: RARITY_META[c.rarity].color }}>
                    {RARITY_META[c.rarity].label}
                  </div>
                  <h3 className="text-base font-bold text-white">{c.name}</h3>
                  <div className="text-xs font-mono-num text-amber-300 mt-1">
                    Quantity: {profile.casesOwned[c.id]}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onOpenCasesTab}
                  className="px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs cursor-pointer"
                >
                  {t.openCase}
                </button>
              </div>
            ))}
            {ownedCases.length === 0 && (
              <div className="col-span-full py-12 text-center text-sm text-slate-400">
                No unopened cases. Visit Cases or Market to get more!
              </div>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {ownedItems.map((item) => {
              const meta = RARITY_META[item.rarity];
              const equipped = isItemEquipped(item);
              return (
                <div
                  key={item.id}
                  style={{ borderColor: equipped ? '#F5C451' : meta.border }}
                  className={`rounded-xl border p-4 flex flex-col justify-between gap-3 ${
                    item.isZaiLimited ? 'zai-shimmer' : 'bg-[#0D131F]'
                  }`}
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold" style={{ color: meta.color }}>
                        {meta.label}
                      </span>
                      <span className="font-mono-num text-slate-400">
                        Lv.{item.level} · {item.category.toUpperCase()}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <div
                        className="w-9 h-9 rounded-lg border border-white/20 shrink-0"
                        style={{
                          background: `linear-gradient(135deg, ${item.visuals.primary}, ${item.visuals.secondary})`,
                        }}
                      />
                      <div className="min-w-0">
                        <h3 className="text-sm font-bold text-white truncate flex items-center gap-1.5">
                          <span>{item.name}</span>
                          {item.isZaiLimited && <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                        </h3>
                        <p className="text-[11px] text-slate-400 truncate">{item.unlockRequirement}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-1 text-[11px] font-mono-num text-slate-300">
                      <div>PWR {item.stats.webPower}</div>
                      <div>RNG {item.stats.webRange}</div>
                      <div>SPD {item.stats.moveSpeed}</div>
                      <div>SWG {item.stats.swingBoost}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playMenuClick();
                        setInspectItem(item);
                      }}
                      className="p-2 rounded-lg border border-slate-700 bg-[#080B12] text-slate-300 hover:text-white cursor-pointer"
                      aria-label={`Inspect ${item.name}`}
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    {equipped ? (
                      <button
                        type="button"
                        disabled={isDefaultStarter(item)}
                        onClick={() => {
                          soundEngine.playMenuClick();
                          onUnequipCategory(item.category);
                        }}
                        className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 ${
                          isDefaultStarter(item)
                            ? 'bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 cursor-default'
                            : 'bg-emerald-500/20 border border-emerald-400 text-emerald-200 hover:bg-emerald-500/30 cursor-pointer'
                        }`}
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{isDefaultStarter(item) ? t.equipped : `${t.equipped} · ${t.unequip}`}</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          soundEngine.playPurchase();
                          onEquipItem(item);
                        }}
                        className="flex-1 py-2 px-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold cursor-pointer"
                      >
                        {t.equip}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Inspect Modal */}
      {inspectItem && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-700 bg-[#0D131F] p-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold" style={{ color: RARITY_META[inspectItem.rarity].color }}>
                {RARITY_META[inspectItem.rarity].label}
              </span>
              <button
                type="button"
                onClick={() => setInspectItem(null)}
                className="text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Close
              </button>
            </div>
            <h2 className="text-xl font-bold text-white">{inspectItem.name}</h2>
            <p className="text-xs text-slate-300">{inspectItem.description}</p>
            {inspectItem.abilities.length > 0 && (
              <div className="space-y-1.5">
                <div className="text-xs font-bold text-amber-400">Active Abilities</div>
                {inspectItem.abilities.map((ab) => (
                  <div key={ab} className="text-xs bg-[#080B12] border border-slate-800 rounded p-2">
                    <div className="font-bold text-white">{ZAI_ABILITIES_INFO[ab].name}</div>
                    <div className="text-slate-400">{ZAI_ABILITIES_INFO[ab].description}</div>
                  </div>
                ))}
              </div>
            )}
            <button
              type="button"
              onClick={() => setInspectItem(null)}
              className="w-full py-2.5 rounded-lg bg-amber-400 text-slate-950 font-bold text-sm cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
