import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  ChevronRight,
  Pause,
  Play,
  RotateCcw,
  SkipForward,
} from 'lucide-react';
import { getTranslations } from '../data/translations';
import { computeAdaptiveWebHouse, computeEffectiveLoadout } from '../game/physics';
import {
  drawSpiderSpikeyPixel,
  drawStyledWebLine,
  drawWebHouse,
} from '../game/renderer';
import { PlayerProfile, Rect } from '../types/game';
import { soundEngine } from '../utils/audio';

interface TutorialScreenProps {
  profile: PlayerProfile;
  onBack: () => void;
  onFinishToPlay: () => void;
}

export const TutorialScreen: React.FC<TutorialScreenProps> = ({
  profile,
  onBack,
  onFinishToPlay,
}) => {
  const t = getTranslations(profile.settings.language);
  const [chapterIdx, setChapterIdx] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [replayNonce, setReplayNonce] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const chapters = [
    {
      title: t.tutMove,
      keyBadge: 'A / D',
      caption: 'Hold A or D (or Arrow keys) to sprint smoothly across snowy rooftops.',
    },
    {
      title: t.tutJump,
      keyBadge: 'SPACE / W',
      caption: 'Press Space or W to leap with coyote-time grace and mid-air double jump.',
    },
    {
      title: t.tutHouseSmall,
      keyBadge: 'E',
      caption: 'Inside a tight alcove or tunnel, pressing E builds a compact Web Shelter anchored to nearby walls.',
    },
    {
      title: t.tutHouseLarge,
      keyBadge: 'E',
      caption: 'In wide open areas, pressing E extends long silk struts and 4 protective rings.',
    },
    {
      title: t.tutWebShoot,
      keyBadge: 'Q',
      caption: 'First Q press fires fast animated spider silk toward the highlighted anchor point.',
    },
    {
      title: t.tutWebSwing,
      keyBadge: 'Q + A/D',
      caption: 'Once attached, pump with A/D to build natural pendulum swing momentum.',
    },
    {
      title: t.tutWebRelease,
      keyBadge: '2nd Q',
      caption: 'Second Q press releases the silk cleanly, preserving forward and upward launch velocity.',
    },
    {
      title: t.tutSkins,
      keyBadge: 'ZAI',
      caption: 'Equipping rare or ZAI LIMITED skins transforms your web style, particles, and active abilities.',
    },
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let raf = 0;
    let elapsed = 0;
    let last = performance.now();

    const frame = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      if (playing) elapsed = (elapsed + dt) % 4.5;

      const w = canvas.width;
      const h = canvas.height;

      // Sky
      const sky = ctx.createLinearGradient(0, 0, 0, h);
      sky.addColorStop(0, '#070D19');
      sky.addColorStop(1, '#13253E');
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, w, h);

      // Floor
      const floorY = h - 72;
      ctx.fillStyle = '#1E293B';
      ctx.fillRect(0, floorY, w, 72);
      ctx.fillStyle = '#E2E8F0';
      ctx.fillRect(0, floorY, w, 6);

      const isZaiDemo = chapterIdx === 7;
      const loadout = computeEffectiveLoadout(
        isZaiDemo
          ? {
              skinId: 'skin_zai_imperial',
              webId: 'web_zai_energy',
              effectId: 'effect_zai_crystal_aura',
              animationId: 'anim_zai_sovereign_motion',
            }
          : profile.equipped
      );

      let px = w * 0.35;
      let py = floorY - 22;
      let isSwinging = false;
      let isGrounded = true;
      let eHighlight = false;
      let qHighlight = false;

      if (chapterIdx === 0) {
        // Basic movement
        px = 140 + Math.abs(Math.sin(elapsed * 1.4)) * (w - 280);
      } else if (chapterIdx === 1) {
        // Jumping
        const jumpPhase = (elapsed % 1.8) / 1.8;
        py = floorY - 22 - Math.sin(jumpPhase * Math.PI) * 115;
        isGrounded = jumpPhase < 0.05 || jumpPhase > 0.95;
      } else if (chapterIdx === 2) {
        // Small Web House inside tight alcove
        const alcove: Rect[] = [
          { x: 0, y: floorY, w, h: 72 },
          { x: 240, y: floorY - 110, w: 180, h: 24 },
          { x: 396, y: floorY - 86, w: 24, h: 52 },
        ];
        for (const p of alcove) {
          ctx.fillStyle = '#1E293B';
          ctx.fillRect(p.x, p.y, p.w, p.h);
          ctx.fillStyle = '#BAE6FD';
          ctx.fillRect(p.x, p.y, p.w, 4);
        }
        px = 325;
        py = floorY - 22;
        eHighlight = elapsed > 0.6 && elapsed < 1.8;
        if (elapsed > 1.0) {
          const wh = computeAdaptiveWebHouse(
            px,
            py - 12,
            alcove,
            { width: w, height: h },
            60,
            loadout.webStyle,
            loadout.webColor,
            loadout.webGlow
          );
          wh.buildProgress = Math.min(1, (elapsed - 1.0) * 2.2);
          drawWebHouse(ctx, wh, 0, 0, elapsed, false);
        }
      } else if (chapterIdx === 3) {
        // Large Web House in wide area
        px = w * 0.5;
        py = floorY - 36;
        eHighlight = elapsed > 0.6 && elapsed < 1.8;
        if (elapsed > 1.0) {
          const wh = computeAdaptiveWebHouse(
            px,
            py - 12,
            [{ x: 0, y: floorY, w, h: 72 }],
            { width: w, height: h },
            85,
            loadout.webStyle,
            loadout.webColor,
            loadout.webGlow
          );
          wh.buildProgress = Math.min(1, (elapsed - 1.0) * 2.2);
          drawWebHouse(ctx, wh, 0, 0, elapsed, false);
        }
      } else if (chapterIdx === 4 || chapterIdx === 5 || chapterIdx === 6) {
        // Q shoot / swing / release
        const anchorX = w * 0.52;
        const anchorY = 68;
        ctx.fillStyle = '#0F172A';
        ctx.fillRect(anchorX - 8, anchorY - 8, 16, 16);
        ctx.strokeStyle = '#F5C451';
        ctx.lineWidth = 2;
        ctx.strokeRect(anchorX - 8, anchorY - 8, 16, 16);

        if (chapterIdx === 4) {
          qHighlight = elapsed > 0.7 && elapsed < 1.7;
          px = w * 0.34;
          py = floorY - 58;
          if (elapsed > 0.8) {
            const prog = Math.min(1, (elapsed - 0.8) * 3.5);
            drawStyledWebLine(ctx, px, py - 10, anchorX, anchorY, loadout.webStyle, loadout.webColor, loadout.webGlow, elapsed, prog);
          }
        } else if (chapterIdx === 5) {
          qHighlight = true;
          isSwinging = true;
          isGrounded = false;
          const angle = Math.sin(elapsed * 2.4) * 0.65;
          const len = 165;
          px = anchorX + Math.sin(angle) * len;
          py = anchorY + Math.cos(angle) * len;
          drawStyledWebLine(ctx, px, py - 10, anchorX, anchorY, loadout.webStyle, loadout.webColor, loadout.webGlow, elapsed, 1);
        } else {
          // Release
          if (elapsed < 1.8) {
            isSwinging = true;
            isGrounded = false;
            const angle = -0.5 + (elapsed / 1.8) * 1.1;
            px = anchorX + Math.sin(angle) * 165;
            py = anchorY + Math.cos(angle) * 165;
            drawStyledWebLine(ctx, px, py - 10, anchorX, anchorY, loadout.webStyle, loadout.webColor, loadout.webGlow, elapsed, 1);
          } else {
            qHighlight = elapsed < 2.3;
            isGrounded = false;
            const rt = elapsed - 1.8;
            px = anchorX + 95 + rt * 190;
            py = anchorY + 135 - rt * 110 + 140 * rt * rt;
          }
        }
      } else {
        // ZAI LIMITED showcase
        px = w * 0.48;
        py = floorY - 28;
        drawStyledWebLine(ctx, px + 8, py - 12, w * 0.75, 65, loadout.webStyle, loadout.webColor, loadout.webGlow, elapsed, 1);
      }

      drawSpiderSpikeyPixel(ctx, px, py, {
        facing: 1,
        scaleX: 1.45,
        scaleY: 1.45,
        walkCycle: elapsed * 6,
        isGrounded,
        isSwinging,
        hitFlash: 0,
        time: elapsed,
        loadout,
        shieldReady: isZaiDemo,
      });

      // Highlighted E & Q Keycaps + visible cursor pointer in canvas
      const drawKey = (kx: number, ky: number, label: string, lit: boolean) => {
        ctx.fillStyle = lit ? '#F5C451' : '#0F172A';
        ctx.fillRect(kx, ky, 40, 36);
        ctx.strokeStyle = lit ? '#FEF08A' : '#475569';
        ctx.lineWidth = 2;
        ctx.strokeRect(kx, ky, 40, 36);
        ctx.fillStyle = lit ? '#09090D' : '#E2E8F0';
        ctx.font = '700 15px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText(label, kx + 20, ky + 23);
      };

      drawKey(w - 115, 22, 'E', eHighlight);
      drawKey(w - 64, 22, 'Q', qHighlight);

      // Animated pointer cursor over the active key
      const cursorTargetX = eHighlight ? w - 95 : qHighlight ? w - 44 : px + 36;
      const cursorTargetY = eHighlight || qHighlight ? 42 : py - 16;
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.moveTo(cursorTargetX, cursorTargetY);
      ctx.lineTo(cursorTargetX + 12, cursorTargetY + 9);
      ctx.lineTo(cursorTargetX + 5, cursorTargetY + 14);
      ctx.closePath();
      ctx.fill();

      raf = requestAnimationFrame(frame);
    };

    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [chapterIdx, playing, replayNonce, profile.equipped]);

  const current = chapters[chapterIdx];

  return (
    <div className="relative z-10 min-h-screen w-full bg-[#080B12]/95 p-4 md:p-7">
      <div className="max-w-5xl mx-auto space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                onBack();
              }}
              className="p-2.5 rounded-lg border border-slate-700 bg-[#0D131F] text-slate-200 hover:border-amber-400 cursor-pointer"
              aria-label={t.backToMenu}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-teal-400" />
                <span>{t.tutorial}</span>
              </h1>
              <p className="text-xs text-slate-400">
                Chapter {chapterIdx + 1} of {chapters.length} · Interactive Animated Demonstration
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onFinishToPlay}
            className="px-4 py-2 rounded-lg border border-slate-700 bg-[#0D131F] hover:border-amber-400 text-xs font-bold text-slate-200 flex items-center gap-1.5 cursor-pointer"
          >
            <SkipForward className="w-4 h-4" />
            <span>{t.skip} → {t.play}</span>
          </button>
        </div>

        {/* Live Animated Canvas Demonstration */}
        <div className="rounded-2xl border border-slate-700 bg-[#0A0F1A] overflow-hidden shadow-2xl">
          <canvas
            ref={canvasRef}
            width={920}
            height={380}
            className="w-full h-auto block"
          />

          <div className="p-5 border-t border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2.5">
                <span className="font-mono-num text-xs font-bold text-amber-400">
                  [{current.keyBadge}]
                </span>
                <h2 className="text-lg font-bold text-white">{current.title}</h2>
              </div>
              <p className="text-sm text-slate-300">{current.caption}</p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setPlaying((p) => !p)}
                className="px-3.5 py-2 rounded-lg border border-slate-700 bg-[#080B12] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                {playing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{playing ? t.pause : 'Play'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setReplayNonce((n) => n + 1);
                  setPlaying(true);
                }}
                className="px-3.5 py-2 rounded-lg border border-slate-700 bg-[#080B12] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t.replay}</span>
              </button>

              {chapterIdx < chapters.length - 1 ? (
                <button
                  type="button"
                  onClick={() => {
                    soundEngine.playMenuClick();
                    setChapterIdx((i) => i + 1);
                    setPlaying(true);
                  }}
                  className="px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <span>{t.next}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onFinishToPlay}
                  className="px-4 py-2 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-slate-950 text-xs font-bold cursor-pointer"
                >
                  {t.play}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Chapter Index */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {chapters.map((ch, idx) => (
            <button
              key={ch.title}
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                setChapterIdx(idx);
                setPlaying(true);
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                idx === chapterIdx
                  ? 'border-amber-400 bg-amber-500/15 text-white'
                  : 'border-slate-800 bg-[#0D131F] text-slate-400 hover:border-slate-600 hover:text-white'
              }`}
            >
              <div className="font-mono-num text-[11px] text-amber-400">
                0{idx + 1} · {ch.keyBadge}
              </div>
              <div className="text-xs font-bold mt-0.5 truncate">{ch.title}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
