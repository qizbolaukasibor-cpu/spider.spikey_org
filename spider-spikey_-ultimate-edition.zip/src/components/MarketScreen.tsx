import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  Check,
  Coins,
  Crown,
  Eye,
  Search,
  ShoppingBag,
} from 'lucide-react';
import {
  CASE_DEFINITIONS,
  CATALOG_ITEMS,
  RARITY_META,
  RARITY_ORDER,
  ZAI_ABILITIES_INFO,
} from '../data/catalog';
import { getTranslations } from '../data/translations';
import {
  CaseDefinition,
  CatalogItem,
  ItemCategory,
  PlayerProfile,
  Rarity,
} from '../types/game';
import { soundEngine } from '../utils/audio';
import { SpiderPreviewCanvas } from './SpiderPreviewCanvas';

interface MarketScreenProps {
  profile: PlayerProfile;
  onBack: () => void;
  onBuyItem: (item: CatalogItem) => { ok: boolean; error?: string };
  onBuyCase: (caseDef: CaseDefinition) => { ok: boolean; error?: string };
}

type MarketCategory = 'all' | ItemCategory | 'limited' | 'cases';
type SortMode = 'price_asc' | 'price_desc' | 'level_desc' | 'power_desc';

export const MarketScreen: React.FC<MarketScreenProps> = ({
  profile,
  onBack,
  onBuyItem,
  onBuyCase,
}) => {
  const t = getTranslations(profile.settings.language);
  const [category, setCategory] = useState<MarketCategory>('all');
  const [rarityFilter, setRarityFilter] = useState<Rarity | 'ALL'>('ALL');
  const [sortMode, setSortMode] = useState<SortMode>('price_asc');
  const [search, setSearch] = useState('');
  const [previewItem, setPreviewItem] = useState<CatalogItem | null>(null);
  const [confirmItem, setConfirmItem] = useState<CatalogItem | null>(null);
  const [confirmCase, setConfirmCase] = useState<CaseDefinition | null>(null);
  const [toast, setToast] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const showToast = (type: 'ok' | 'err', text: string) => {
    setToast({ type, text });
    window.setTimeout(() => setToast(null), 3000);
  };

  const filteredItems = useMemo(() => {
    if (category === 'cases') return [];
    const q = search.trim().toLowerCase();
    return CATALOG_ITEMS.filter((item) => {
      if (item.price <= 0) return false;
      if (category === 'limited') {
        if (item.rarity !== 'LIMITED' && item.rarity !== 'ZAI_LIMITED') return false;
      } else if (category !== 'all' && item.category !== category) {
        return false;
      }
      if (rarityFilter !== 'ALL' && item.rarity !== rarityFilter) return false;
      if (
        q &&
        !item.name.toLowerCase().includes(q) &&
        !item.description.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortMode === 'price_asc') return a.price - b.price;
      if (sortMode === 'price_desc') return b.price - a.price;
      if (sortMode === 'level_desc') return b.level - a.level;
      return b.stats.abilityLevel - a.stats.abilityLevel || b.stats.webPower - a.stats.webPower;
    });
  }, [category, rarityFilter, sortMode, search]);

  const filteredCases = useMemo(() => {
    if (category !== 'cases' && category !== 'all') return [];
    const q = search.trim().toLowerCase();
    return CASE_DEFINITIONS.filter((c) => {
      if (rarityFilter !== 'ALL' && c.rarity !== rarityFilter) return false;
      if (q && !c.name.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [category, rarityFilter, search]);

  const handleConfirmPurchaseItem = () => {
    if (!confirmItem) return;
    if (profile.coins < confirmItem.price) {
      soundEngine.playHurt();
      showToast('err', t.insufficientCoins);
      setConfirmItem(null);
      return;
    }
    const res = onBuyItem(confirmItem);
    if (res.ok) {
      soundEngine.playPurchase();
      showToast('ok', `${confirmItem.name} — ${t.purchaseSuccess}`);
    } else {
      soundEngine.playHurt();
      showToast('err', res.error || t.insufficientCoins);
    }
    setConfirmItem(null);
  };

  const handleConfirmPurchaseCase = () => {
    if (!confirmCase) return;
    if (profile.coins < confirmCase.price) {
      soundEngine.playHurt();
      showToast('err', t.insufficientCoins);
      setConfirmCase(null);
      return;
    }
    const res = onBuyCase(confirmCase);
    if (res.ok) {
      soundEngine.playPurchase();
      showToast('ok', `${confirmCase.name} added to Cases!`);
    } else {
      soundEngine.playHurt();
      showToast('err', res.error || t.insufficientCoins);
    }
    setConfirmCase(null);
  };

  const previewEquipped = useMemo(() => {
    if (!previewItem) return profile.equipped;
    const next = { ...profile.equipped };
    if (previewItem.category === 'skin') next.skinId = previewItem.id;
    if (previewItem.category === 'web') next.webId = previewItem.id;
    if (previewItem.category === 'effect') next.effectId = previewItem.id;
    if (previewItem.category === 'animation') next.animationId = previewItem.id;
    return next;
  }, [previewItem, profile.equipped]);

  const catTabs: Array<{ id: MarketCategory; label: string }> = [
    { id: 'all', label: 'All Items' },
    { id: 'skin', label: 'Character Skins' },
    { id: 'web', label: 'Web Designs' },
    { id: 'effect', label: 'Special Effects' },
    { id: 'animation', label: 'Animations' },
    { id: 'limited', label: 'Limited & ZAI' },
    { id: 'cases', label: 'Cases' },
  ];

  return (
    <div className="relative z-10 min-h-screen w-full bg-[#080B12]/95 p-4 md:p-7">
      <div className="max-w-[1400px] mx-auto space-y-5">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                onBack();
              }}
              className="p-2.5 rounded-lg border border-slate-700 bg-[#0D131F] text-slate-200 hover:border-amber-400 cursor-pointer"
              aria-label={t.backToMenu}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-sky-400" />
                <span>{t.market}</span>
              </h1>
              <p className="text-xs text-slate-400">
                Character Skins · Web Designs · Effects · Animations · Cases
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-950/30 px-4 py-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="font-mono-num font-bold text-amber-300">
              {profile.coins.toLocaleString()}
            </span>
          </div>
        </div>

        {toast && (
          <div
            role="status"
            className={`rounded-lg border px-4 py-2.5 text-sm font-semibold flex items-center gap-2 ${
              toast.type === 'ok'
                ? 'border-emerald-500/60 bg-emerald-950/40 text-emerald-200'
                : 'border-rose-500/60 bg-rose-950/40 text-rose-200'
            }`}
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{toast.text}</span>
          </div>
        )}

        {/* Filter & Search Bar */}
        <div className="flex flex-col lg:flex-row gap-3 justify-between">
          <div className="flex flex-wrap gap-1.5">
            {catTabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  soundEngine.playMenuClick();
                  setCategory(tab.id);
                }}
                className={`px-3.5 py-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer whitespace-nowrap ${
                  category === tab.id
                    ? 'border-amber-400 bg-amber-400 text-slate-950'
                    : 'border-slate-800 bg-[#0D131F] text-slate-300 hover:border-slate-600'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search items..."
                aria-label="Search market items"
                className="pl-8 pr-3 py-2 rounded-lg bg-[#0D131F] border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 w-44"
              />
            </div>

            <select
              value={rarityFilter}
              onChange={(e) => setRarityFilter(e.target.value as Rarity | 'ALL')}
              aria-label="Filter by rarity"
              className="px-3 py-2 rounded-lg bg-[#0D131F] border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
            >
              <option value="ALL">All Rarities</option>
              {RARITY_ORDER.map((r) => (
                <option key={r} value={r}>
                  {RARITY_META[r].label}
                </option>
              ))}
            </select>

            <select
              value={sortMode}
              onChange={(e) => setSortMode(e.target.value as SortMode)}
              aria-label="Sort market items"
              className="px-3 py-2 rounded-lg bg-[#0D131F] border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
            >
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="level_desc">Level: Highest</option>
              <option value="power_desc">Abilities: Strongest</option>
            </select>
          </div>
        </div>

        {/* Item Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredItems.map((item) => {
            const meta = RARITY_META[item.rarity];
            const owned = profile.ownedItemIds.includes(item.id);
            const equipped =
              profile.equipped.skinId === item.id ||
              profile.equipped.webId === item.id ||
              profile.equipped.effectId === item.id ||
              profile.equipped.animationId === item.id;
            const canAfford = profile.coins >= item.price;

            return (
              <div
                key={item.id}
                style={{ borderColor: meta.border }}
                className={`rounded-xl border p-4 flex flex-col justify-between gap-4 transition-transform hover:-translate-y-0.5 ${
                  item.isZaiLimited ? 'zai-shimmer' : 'bg-[#0D131F]'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold tracking-wider" style={{ color: meta.color }}>
                      {meta.label}
                    </span>
                    <span className="font-mono-num text-slate-400">
                      Lv.{item.level} · {item.category.toUpperCase()}
                    </span>
                  </div>

                  {/* Color/Style Swatch Preview */}
                  <div
                    className="h-24 rounded-lg border border-slate-800/90 flex items-center justify-between px-4 relative overflow-hidden"
                    style={{
                      background: `radial-gradient(circle at 30% 50%, ${item.visuals.glow}28, #070A11 75%)`,
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-lg border border-white/20"
                        style={{
                          background: `linear-gradient(135deg, ${item.visuals.primary}, ${item.visuals.secondary})`,
                          boxShadow: `0 0 16px ${item.visuals.glow}66`,
                        }}
                      />
                      <div
                        className="w-12 h-1.5 rounded-full"
                        style={{
                          backgroundColor: item.visuals.webColor,
                          boxShadow: `0 0 10px ${item.visuals.webGlow}`,
                        }}
                      />
                    </div>
                    {item.isZaiLimited && <Crown className="w-5 h-5 text-amber-400" />}
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white">{item.name}</h3>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1">{item.description}</p>
                  </div>

                  {/* Compact Stats */}
                  <div className="grid grid-cols-2 gap-1.5 text-[11px] font-mono-num text-slate-300">
                    <div>PWR {item.stats.webPower}</div>
                    <div>RNG {item.stats.webRange}</div>
                    <div>SPD {item.stats.moveSpeed}</div>
                    <div>SWG {item.stats.swingBoost}</div>
                  </div>

                  {item.abilities.length > 0 && (
                    <div className="text-[11px] text-amber-300 truncate">
                      {item.abilities.map((a) => ZAI_ABILITIES_INFO[a].name).join(' · ')}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playMenuClick();
                      setPreviewItem(item);
                    }}
                    className="p-2 rounded-lg border border-slate-700 bg-[#080B12] text-slate-300 hover:text-white hover:border-slate-500 cursor-pointer"
                    aria-label={`Preview ${item.name}`}
                  >
                    <Eye className="w-4 h-4" />
                  </button>

                  {owned ? (
                    <div className="flex-1 py-2 px-3 rounded-lg bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5">
                      <Check className="w-3.5 h-3.5" />
                      <span>{equipped ? t.equipped : 'Owned'}</span>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playMenuClick();
                        if (!canAfford) {
                          soundEngine.playHurt();
                          showToast('err', `${t.insufficientCoins} Need ${item.price - profile.coins} more.`);
                          return;
                        }
                        setConfirmItem(item);
                      }}
                      className={`flex-1 py-2 px-3 rounded-lg font-mono-num text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
                        canAfford
                          ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                      }`}
                    >
                      <Coins className="w-3.5 h-3.5" />
                      <span>{item.price.toLocaleString()}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {/* Cases in Market */}
          {filteredCases.map((c) => {
            const meta = RARITY_META[c.rarity];
            const canAfford = profile.coins >= c.price;
            const ownedCount = profile.casesOwned[c.id] || 0;
            return (
              <div
                key={c.id}
                style={{ borderColor: meta.border }}
                className={`rounded-xl border p-4 flex flex-col justify-between gap-4 ${
                  c.isZaiLimited ? 'zai-shimmer' : 'bg-[#0D131F]'
                }`}
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold" style={{ color: meta.color }}>
                      {meta.label} CASE
                    </span>
                    <span className="font-mono-num text-slate-400">Owned: {ownedCount}</span>
                  </div>
                  <h3 className="text-base font-bold text-white">{c.name}</h3>
                  <p className="text-xs text-slate-400">{c.description}</p>
                  <div className="space-y-1 pt-1">
                    {c.drops.map((d) => (
                      <div key={d.rarity} className="flex justify-between text-[11px] font-mono-num">
                        <span style={{ color: RARITY_META[d.rarity].color }}>
                          {RARITY_META[d.rarity].label}
                        </span>
                        <span className="text-slate-300">{d.probability}%</span>
                      </div>
                    ))}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    soundEngine.playMenuClick();
                    if (!canAfford) {
                      soundEngine.playHurt();
                      showToast('err', t.insufficientCoins);
                      return;
                    }
                    setConfirmCase(c);
                  }}
                  className={`w-full py-2.5 rounded-lg font-mono-num text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                    canAfford
                      ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>
                    {t.buy} · {c.price.toLocaleString()}
                  </span>
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Live Preview Modal */}
      {previewItem && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-700 bg-[#0D131F] p-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold" style={{ color: RARITY_META[previewItem.rarity].color }}>
                {RARITY_META[previewItem.rarity].label} · Lv.{previewItem.level}
              </span>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Close
              </button>
            </div>
            <h2 className="text-xl font-bold text-white">{previewItem.name}</h2>
            <div className="rounded-lg border border-slate-800 bg-[#070A11] flex justify-center p-2">
              <SpiderPreviewCanvas equipped={previewEquipped} width={280} height={160} />
            </div>
            <p className="text-xs text-slate-300">{previewItem.description}</p>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono-num text-slate-200 bg-[#080B12] p-3 rounded-lg">
              <div>Web Power: {previewItem.stats.webPower}</div>
              <div>Web Range: {previewItem.stats.webRange}</div>
              <div>Move Speed: {previewItem.stats.moveSpeed}</div>
              <div>Swing Boost: {previewItem.stats.swingBoost}</div>
            </div>
            <button
              type="button"
              onClick={() => setPreviewItem(null)}
              className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-sm font-semibold cursor-pointer"
            >
              Close Preview
            </button>
          </div>
        </div>
      )}

      {/* Purchase Confirmation Modal */}
      {(confirmItem || confirmCase) && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 p-4">
          <div className="w-full max-w-sm rounded-xl border border-amber-400/60 bg-[#0D131F] p-6 space-y-4">
            <h2 className="text-lg font-bold text-white">Confirm Purchase</h2>
            <p className="text-sm text-slate-300">
              Buy <strong className="text-white">{confirmItem?.name || confirmCase?.name}</strong> for{' '}
              <strong className="text-amber-400 font-mono-num">
                {(confirmItem?.price || confirmCase?.price || 0).toLocaleString()} Coins
              </strong>
              ?
            </p>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={confirmItem ? handleConfirmPurchaseItem : handleConfirmPurchaseCase}
                className="flex-1 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm cursor-pointer"
              >
                Confirm
              </button>
              <button
                type="button"
                onClick={() => {
                  setConfirmItem(null);
                  setConfirmCase(null);
                }}
                className="flex-1 py-2.5 rounded-lg border border-slate-700 text-slate-300 hover:text-white text-sm cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
