import React, { useRef, useState } from 'react';
import {
  ArrowLeft,
  Check,
  Coins,
  Download,
  ShieldAlert,
  Trophy,
  Upload,
  User,
} from 'lucide-react';
import { ACHIEVEMENTS, AVATAR_OPTIONS, ITEM_BY_ID } from '../data/catalog';
import { getTranslations } from '../data/translations';
import { PlayerProfile } from '../types/game';
import { soundEngine } from '../utils/audio';
import { exportSaveJson } from '../utils/storage';
import { PixelAvatar } from './PixelAvatar';

interface ProfileScreenProps {
  profile: PlayerProfile;
  onBack: () => void;
  onUpdateProfileInfo: (nickname: string, avatarId: string) => void;
  onImportSaveText: (raw: string) => { ok: boolean; error?: string };
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  profile,
  onBack,
  onUpdateProfileInfo,
  onImportSaveText,
}) => {
  const t = getTranslations(profile.settings.language);
  const [editNick, setEditNick] = useState(profile.nickname);
  const [editAvatar, setEditAvatar] = useState(profile.avatarId);
  const [statusMsg, setStatusMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const xpNeeded = profile.level * 250;
  const xpPct = Math.min(100, Math.round((profile.xp / xpNeeded) * 100));
  const equippedSkin = ITEM_BY_ID[profile.equipped.skinId];
  const zaiCount = profile.ownedItemIds.filter((id) => ITEM_BY_ID[id]?.isZaiLimited).length;

  const handleExport = () => {
    soundEngine.playMenuClick();
    const json = exportSaveJson(profile);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `spider-spikey-${profile.nickname.toLowerCase().replace(/[^a-z0-9]/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setStatusMsg({ type: 'ok', text: 'Save file exported as JSON.' });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = typeof reader.result === 'string' ? reader.result : '';
      const res = onImportSaveText(text);
      if (res.ok) {
        soundEngine.playPurchase();
        setStatusMsg({ type: 'ok', text: 'Save data imported and loaded successfully!' });
      } else {
        soundEngine.playHurt();
        setStatusMsg({ type: 'err', text: res.error || 'Import failed.' });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="relative z-10 min-h-screen w-full bg-[#080B12]/95 p-4 md:p-7">
      <div className="max-w-[1200px] mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                onBack();
              }}
              className="p-2.5 rounded-lg border border-slate-700 bg-[#0D131F] text-slate-200 hover:border-amber-400 cursor-pointer"
              aria-label={t.backToMenu}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                <User className="w-5 h-5 text-cyan-400" />
                <span>{t.profile}</span>
              </h1>
              <p className="text-xs text-slate-400">
                Player identity, collection statistics, achievements, and save backup.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-950/30 px-4 py-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="font-mono-num font-bold text-amber-300">
              {profile.coins.toLocaleString()}
            </span>
          </div>
        </div>

        {statusMsg && (
          <div
            className={`rounded-lg border px-4 py-2.5 text-sm font-semibold ${
              statusMsg.type === 'ok'
                ? 'border-emerald-500/50 bg-emerald-950/40 text-emerald-200'
                : 'border-rose-500/50 bg-rose-950/40 text-rose-200'
            }`}
          >
            {statusMsg.text}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Identity & Edit */}
          <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#0D131F] p-5 space-y-5">
            <div className="flex items-center gap-4">
              <PixelAvatar avatarId={editAvatar} size={64} />
              <div className="flex-1 min-w-0">
                <div className="text-lg font-bold text-white truncate">{profile.nickname}</div>
                <div className="text-xs text-amber-400 font-mono-num">
                  Level {profile.level} · {profile.xp} / {xpNeeded} XP
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 mt-1.5 overflow-hidden">
                  <div className="h-full bg-amber-400" style={{ width: `${xpPct}%` }} />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="profile-nick-input" className="text-xs font-semibold text-slate-300">
                Nickname
              </label>
              <input
                id="profile-nick-input"
                type="text"
                maxLength={24}
                value={editNick}
                onChange={(e) => setEditNick(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#080B12] border border-slate-700 text-sm text-white"
              />
            </div>

            <div className="grid grid-cols-6 gap-2">
              {AVATAR_OPTIONS.map((av) => (
                <button
                  key={av.id}
                  type="button"
                  onClick={() => setEditAvatar(av.id)}
                  className={`p-1.5 rounded-lg border cursor-pointer flex justify-center ${
                    editAvatar === av.id
                      ? 'border-amber-400 bg-amber-500/15'
                      : 'border-slate-800 bg-[#080B12]'
                  }`}
                >
                  <PixelAvatar avatarId={av.id} size={34} />
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => {
                if (editNick.trim().length < 2) return;
                soundEngine.playPurchase();
                onUpdateProfileInfo(editNick.trim(), editAvatar);
                setStatusMsg({ type: 'ok', text: 'Profile updated and saved locally.' });
              }}
              className="w-full py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs cursor-pointer"
            >
              Save Identity
            </button>
          </div>

          {/* Stats & Save Backup */}
          <div className="lg:col-span-7 space-y-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                ['Items Owned', profile.ownedItemIds.length],
                ['ZAI Items', zaiCount],
                ['Cases Opened', profile.metrics.casesOpened],
                ['Web Houses', profile.metrics.webHousesBuilt],
                ['Web Swings', profile.metrics.webAttaches],
                ['Distance (m)', profile.metrics.distanceTraveled],
                ['Stages Cleared', profile.metrics.levelsCompleted],
                ['Equipped Skin', equippedSkin?.name || 'Classic'],
              ].map(([label, val]) => (
                <div
                  key={String(label)}
                  className="rounded-xl border border-slate-800 bg-[#0D131F] p-3.5"
                >
                  <div className="text-[11px] text-slate-400">{label}</div>
                  <div className="font-mono-num text-sm font-bold text-white truncate mt-1">
                    {val}
                  </div>
                </div>
              ))}
            </div>

            {/* Export / Import */}
            <div className="rounded-xl border border-slate-800 bg-[#0D131F] p-5 space-y-4">
              <div className="flex items-start gap-3 text-xs text-sky-200/90 bg-sky-950/30 border border-sky-500/30 rounded-lg p-3">
                <ShieldAlert className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <span>{t.localSaveNotice}</span>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={handleExport}
                  className="flex-1 min-w-[160px] py-2.5 px-4 rounded-lg border border-slate-700 bg-[#080B12] hover:border-amber-400 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>{t.exportSave}</span>
                </button>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1 min-w-[160px] py-2.5 px-4 rounded-lg border border-slate-700 bg-[#080B12] hover:border-sky-400 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-sky-400" />
                  <span>{t.importSave}</span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="application/json,.json"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <span>Achievements</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {ACHIEVEMENTS.map((ach) => {
              const current = profile.metrics[ach.metric] || 0;
              const done = current >= ach.target;
              const pct = Math.min(100, Math.round((current / ach.target) * 100));
              return (
                <div
                  key={ach.id}
                  className={`rounded-xl border p-4 space-y-2 ${
                    done
                      ? 'border-emerald-500/60 bg-emerald-950/20'
                      : 'border-slate-800 bg-[#0D131F]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white">{ach.title}</span>
                    {done && <Check className="w-4 h-4 text-emerald-400" />}
                  </div>
                  <p className="text-xs text-slate-400">{ach.description}</p>
                  <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full ${done ? 'bg-emerald-400' : 'bg-sky-400'}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="text-[11px] font-mono-num text-slate-300">
                    {Math.min(current, ach.target)} / {ach.target}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
