import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Calendar,
  Check,
  Coins,
  Crown,
  Flame,
  Sparkles,
} from 'lucide-react';
import {
  CASE_BY_ID,
  CATALOG_ITEMS,
  ITEM_BY_ID,
  MONTHLY_COLLECTIONS,
  ZAI_ABILITIES_INFO,
  ZAI_ANNUAL_EVENTS,
  ZAI_MAX_STATS,
} from '../data/catalog';
import { getTranslations } from '../data/translations';
import { CaseDefinition, CatalogItem, PlayerProfile, ZaiAbilityId } from '../types/game';
import { soundEngine } from '../utils/audio';
import { getEventCountdown } from '../utils/storage';
import { SpiderPreviewCanvas } from './SpiderPreviewCanvas';

interface ZaiLimitedScreenProps {
  profile: PlayerProfile;
  onBack: () => void;
  onBuyItem: (item: CatalogItem) => { ok: boolean; error?: string };
  onEquipItem: (item: CatalogItem) => void;
  onBuyCase: (caseDef: CaseDefinition) => { ok: boolean; error?: string };
  onGoToCases: () => void;
}

export const ZaiLimitedScreen: React.FC<ZaiLimitedScreenProps> = ({
  profile,
  onBack,
  onBuyItem,
  onEquipItem,
  onBuyCase,
  onGoToCases,
}) => {
  const t = getTranslations(profile.settings.language);
  const [tab, setTab] = useState<'zai' | 'monthly' | 'events'>('zai');
  const [previewItemId, setPreviewItemId] = useState<string>('skin_zai_imperial');
  const [now, setNow] = useState(() => new Date());
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const zaiItems = CATALOG_ITEMS.filter((i) => i.isZaiLimited);
  const zaiCase = CASE_BY_ID['zai_limited_case'];

  const previewTarget = ITEM_BY_ID[previewItemId] || zaiItems[0];
  const previewLoadout = {
    ...profile.equipped,
    ...(previewTarget.category === 'skin' ? { skinId: previewTarget.id } : {}),
    ...(previewTarget.category === 'web' ? { webId: previewTarget.id } : {}),
    ...(previewTarget.category === 'effect' ? { effectId: previewTarget.id } : {}),
    ...(previewTarget.category === 'animation' ? { animationId: previewTarget.id } : {}),
  };

  const zaiCoreAbilities: ZaiAbilityId[] = [
    'ZAI_ENERGY_WEB',
    'ZAI_INSTANT_ATTACH',
    'ZAI_CRYSTAL_SHIELD',
    'ZAI_SUPER_SWING',
    'ZAI_ENERGY_BURST',
    'ZAI_AURA',
  ];

  const notify = (msg: string) => {
    setFeedback(msg);
    window.setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <div className="relative z-10 min-h-screen w-full bg-[#060609]/98 p-4 md:p-7">
      <div className="max-w-[1400px] mx-auto space-y-6">
        {/* Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-amber-500/30 pb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                onBack();
              }}
              className="p-2.5 rounded-lg border border-amber-500/40 bg-[#0D0D12] text-amber-200 hover:border-amber-400 cursor-pointer"
              aria-label={t.backToMenu}
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-3">
              {/* Animated ZAI Emblem SVG */}
              <svg width="40" height="40" viewBox="0 0 40 40" className="shrink-0">
                <polygon
                  points="20,2 37,11 37,29 20,38 3,29 3,11"
                  fill="#09090D"
                  stroke="#F5C451"
                  strokeWidth="2"
                />
                <polygon points="20,8 28,20 20,32 12,20" fill="#F5C451" opacity="0.22" />
                <text
                  x="20"
                  y="24"
                  textAnchor="middle"
                  fill="#F5C451"
                  fontFamily="Outfit, sans-serif"
                  fontWeight="800"
                  fontSize="12"
                >
                  ZAI
                </text>
              </svg>
              <div>
                <h1 className="text-2xl font-extrabold text-amber-300 tracking-wide">
                  ZAI LIMITED COLLECTION
                </h1>
                <p className="text-xs text-slate-400">
                  Apex Black & Gold Tier · Maximum Permitted Stats (100/100) · Live Gameplay Abilities
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 rounded-lg border border-amber-500/50 bg-[#0D0B07] px-4 py-2">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="font-mono-num font-bold text-amber-300">
                {profile.coins.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Section Tabs */}
        <div className="flex flex-wrap gap-2">
          {(
            [
              ['zai', 'ZAI LIMITED Apex'],
              ['monthly', 'Monthly Collections (Jan–Dec)'],
              ['events', 'Special Annual ZAI Events'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => {
                soundEngine.playMenuClick();
                setTab(id);
              }}
              className={`px-4 py-2.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                tab === id
                  ? 'border-amber-400 bg-amber-400 text-slate-950 shadow-[0_0_20px_rgba(245,196,81,0.3)]'
                  : 'border-slate-800 bg-[#0D0D12] text-slate-300 hover:border-amber-500/40'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {feedback && (
          <div className="rounded-lg border border-amber-400/60 bg-amber-950/30 px-4 py-2.5 text-sm font-semibold text-amber-200">
            {feedback}
          </div>
        )}

        {/* TAB 1: ZAI LIMITED APEX */}
        {tab === 'zai' && (
          <div className="space-y-6">
            {/* Hero Spotlight */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 rounded-2xl border border-amber-400/70 p-6 zai-shimmer shadow-[0_0_40px_rgba(245,196,81,0.14)]">
              <div className="lg:col-span-5 flex flex-col items-center justify-center rounded-xl border border-amber-500/30 bg-[#050508] p-4">
                <SpiderPreviewCanvas equipped={previewLoadout} width={300} height={180} />
                <div className="mt-2 text-center">
                  <div className="text-sm font-bold text-amber-300">{previewTarget.name}</div>
                  <div className="text-[11px] text-slate-400">
                    Web Style: {previewTarget.visuals.webStyle.toUpperCase()}
                  </div>
                </div>
              </div>

              <div className="lg:col-span-7 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold tracking-widest text-amber-400 uppercase flex items-center gap-1.5">
                    <Crown className="w-4 h-4" />
                    <span>MAXIMUM PERMITTED TIER</span>
                  </span>
                  <span className="font-mono-num text-xs text-amber-200">
                    ALL STATS {ZAI_MAX_STATS.webPower}/100 · ABILITY Lv.{ZAI_MAX_STATS.abilityLevel}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {zaiCoreAbilities.map((ab) => (
                    <div
                      key={ab}
                      className="rounded-lg border border-amber-500/25 bg-black/60 p-2.5"
                    >
                      <div className="text-xs font-bold text-amber-300">
                        {ZAI_ABILITIES_INFO[ab].name}
                      </div>
                      <div className="text-[11px] text-slate-300 mt-0.5">
                        {ZAI_ABILITIES_INFO[ab].description}
                      </div>
                    </div>
                  ))}
                </div>

                {/* ZAI LIMITED Case Quick Box */}
                <div className="rounded-xl border border-amber-400/50 bg-[#0A0907] p-4 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-bold text-amber-300">{zaiCase.name}</div>
                    <div className="text-xs text-slate-400">
                      Owned: <strong className="text-white">{profile.casesOwned.zai_limited_case}</strong> ·
                      ZAI Drop Rate: 5% · Mythic 18%
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const res = onBuyCase(zaiCase);
                        if (res.ok) {
                          soundEngine.playPurchase();
                          notify('ZAI LIMITED Case purchased! Open it in Cases.');
                        } else {
                          soundEngine.playHurt();
                          notify(res.error || t.insufficientCoins);
                        }
                      }}
                      className="px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-mono-num text-xs font-bold cursor-pointer"
                    >
                      Buy Case · {zaiCase.price}
                    </button>
                    <button
                      type="button"
                      onClick={onGoToCases}
                      className="px-4 py-2 rounded-lg border border-amber-400/60 text-amber-200 hover:bg-amber-400/10 text-xs font-bold cursor-pointer"
                    >
                      Open Vaults
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* ZAI LIMITED Catalog Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {zaiItems.map((item) => {
                const owned = profile.ownedItemIds.includes(item.id);
                const equipped =
                  profile.equipped.skinId === item.id ||
                  profile.equipped.webId === item.id ||
                  profile.equipped.effectId === item.id ||
                  profile.equipped.animationId === item.id;

                return (
                  <div
                    key={item.id}
                    className="rounded-xl border border-amber-500/60 bg-[#09090D] p-5 flex flex-col justify-between gap-4"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-amber-400">ZAI LIMITED</span>
                        <span className="font-mono-num text-slate-400">
                          Lv.{item.level} · {item.category.toUpperCase()}
                        </span>
                      </div>
                      <h3 className="text-lg font-bold text-white">{item.name}</h3>
                      <p className="text-xs text-slate-400">{item.description}</p>
                      <div className="grid grid-cols-2 gap-1 text-xs font-mono-num text-amber-200">
                        <div>PWR {item.stats.webPower}</div>
                        <div>RNG {item.stats.webRange}</div>
                        <div>SPD {item.stats.moveSpeed}</div>
                        <div>SWG {item.stats.swingBoost}</div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          soundEngine.playMenuClick();
                          setPreviewItemId(item.id);
                        }}
                        className="px-3 py-2 rounded-lg border border-slate-700 text-xs text-slate-200 hover:border-amber-400 cursor-pointer"
                      >
                        Preview
                      </button>
                      {owned ? (
                        <button
                          type="button"
                          onClick={() => {
                            soundEngine.playZaiAbility();
                            onEquipItem(item);
                            notify(`${item.name} equipped!`);
                          }}
                          className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                            equipped
                              ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-200'
                              : 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>{equipped ? t.equipped : t.equip}</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            const res = onBuyItem(item);
                            if (res.ok) {
                              soundEngine.playZaiAbility();
                              notify(`${item.name} unlocked and added to Inventory!`);
                            } else {
                              soundEngine.playHurt();
                              notify(res.error || t.insufficientCoins);
                            }
                          }}
                          className="flex-1 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-mono-num text-xs font-bold cursor-pointer"
                        >
                          Unlock · {item.price.toLocaleString()}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: 12 MONTHLY COLLECTIONS */}
        {tab === 'monthly' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {MONTHLY_COLLECTIONS.map((col) => {
              const skin = ITEM_BY_ID[col.skinId];
              const owned = skin ? profile.ownedItemIds.includes(skin.id) : false;
              const monthName = new Date(2026, col.month - 1, 1).toLocaleString('en-US', {
                month: 'long',
              });
              return (
                <div
                  key={col.month}
                  style={{ borderColor: `${col.themeColor}88` }}
                  className="rounded-xl border bg-[#0C101A] p-4 flex flex-col justify-between gap-4"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold uppercase tracking-wider" style={{ color: col.themeColor }}>
                        {monthName}
                      </span>
                      <span className="font-mono-num text-slate-400">LIMITED</span>
                    </div>
                    <h3 className="text-base font-bold text-white">{col.name}</h3>
                    <p className="text-xs text-slate-400">{col.description}</p>
                    {skin && (
                      <div className="text-[11px] font-mono-num text-slate-300">
                        Skin: {skin.name} · PWR {skin.stats.webPower}
                      </div>
                    )}
                  </div>

                  {skin && (
                    <button
                      type="button"
                      onClick={() => {
                        if (owned) {
                          soundEngine.playPurchase();
                          onEquipItem(skin);
                          notify(`${skin.name} equipped!`);
                        } else {
                          const res = onBuyItem(skin);
                          if (res.ok) {
                            soundEngine.playPurchase();
                            notify(`${skin.name} unlocked!`);
                          } else {
                            soundEngine.playHurt();
                            notify(res.error || t.insufficientCoins);
                          }
                        }
                      }}
                      className={`w-full py-2 rounded-lg text-xs font-bold cursor-pointer ${
                        owned
                          ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-200'
                          : 'bg-amber-400 hover:bg-amber-300 text-slate-950 font-mono-num'
                      }`}
                    >
                      {owned ? t.equip : `${t.buy} · ${skin.price}`}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 3: SPECIAL ANNUAL ZAI EVENTS */}
        {tab === 'events' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {ZAI_ANNUAL_EVENTS.map((ev) => {
              const cd = getEventCountdown(ev, now);
              const isWarning =
                cd.status === 'WARNING_7D' ||
                cd.status === 'WARNING_24H' ||
                cd.status === 'WARNING_1H';
              const isLive = cd.status === 'AVAILABLE_NOW';
              const evCase = CASE_BY_ID[ev.caseId];
              const evSkin = ITEM_BY_ID[ev.exclusiveSkinId];

              return (
                <div
                  key={ev.id}
                  className={`rounded-2xl border p-6 flex flex-col justify-between gap-5 ${
                    isLive
                      ? 'border-amber-400 bg-[#0A0A0E] shadow-[0_0_28px_rgba(245,196,81,0.28)]'
                      : isWarning
                        ? 'border-red-500 bg-[#12070A] warning-pulse'
                        : 'border-slate-700/80 bg-[#0C101A]'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span
                        className={`text-xs font-extrabold tracking-wider uppercase flex items-center gap-1.5 ${
                          isLive
                            ? 'text-amber-400'
                            : isWarning
                              ? 'text-red-400'
                              : 'text-sky-400'
                        }`}
                      >
                        {isWarning ? (
                          <AlertTriangle className="w-4 h-4" />
                        ) : isLive ? (
                          <Flame className="w-4 h-4" />
                        ) : (
                          <Calendar className="w-4 h-4" />
                        )}
                        <span>
                          {isLive
                            ? t.availableNow
                            : cd.status === 'WARNING_1H'
                              ? t.warning1Hour
                              : cd.status === 'WARNING_24H'
                                ? t.warning24Hours
                                : cd.status === 'WARNING_7D'
                                  ? t.warning7Days
                                  : `Annual Drop · ${ev.month}/${ev.day}`}
                        </span>
                      </span>
                    </div>

                    <h2 className="text-xl font-extrabold text-white">{ev.name}</h2>
                    <p className="text-xs text-slate-300 leading-relaxed">{ev.description}</p>

                    <div className="rounded-xl border border-slate-800 bg-black/50 p-3.5 text-center">
                      <div className="text-[10px] uppercase tracking-widest text-slate-400 mb-1">
                        {isLive ? 'Event Status' : 'Live Countdown'}
                      </div>
                      <div className="font-mono-num text-xl font-extrabold text-white">
                        {isLive
                          ? t.availableNow
                          : `${cd.days}d ${String(cd.hours).padStart(2, '0')}h ${String(
                              cd.minutes
                            ).padStart(2, '0')}m ${String(cd.seconds).padStart(2, '0')}s`}
                      </div>
                    </div>

                    <div className="text-xs text-slate-300 space-y-1">
                      <div>
                        Exclusive Skin: <strong className="text-amber-300">{evSkin?.name}</strong>
                      </div>
                      <div>
                        Exclusive Case: <strong className="text-white">{evCase.name}</strong>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const res = onBuyCase(evCase);
                      if (res.ok) {
                        soundEngine.playZaiAbility();
                        notify(`${evCase.name} added to your Vaults!`);
                      } else {
                        soundEngine.playHurt();
                        notify(res.error || t.insufficientCoins);
                      }
                    }}
                    className="w-full py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Acquire {evCase.name} · {evCase.price}</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
