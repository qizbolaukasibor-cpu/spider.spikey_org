import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Box, Check, Coins, Gem, History, Lock, Sparkles, X } from 'lucide-react';
import { CASE_CATALOG, RARITY_CONFIG } from '../../data/world3dCatalog';
import { CaseDef, PlayerSaveData, Rarity } from '../../types/spider3d';

type CaseOpenResponse =
  | {
      ok: true;
      itemKind: 'skin' | 'web';
      itemId: string;
      itemName: string;
      rarity: Rarity;
      wasDuplicate: boolean;
      bonusCoins: number;
    }
  | { ok: false; error: string };

interface Cases3DScreenProps {
  save: PlayerSaveData;
  onBack: () => void;
  onBuyCase: (caseId: string) => boolean;
  onOpenCase: (caseDef: CaseDef) => CaseOpenResponse;
  onBuyAndOpenCase: (caseDef: CaseDef) => CaseOpenResponse;
  onEquipUnlocked: (kind: 'skin' | 'web', itemId: string) => void;
}

export const Cases3DScreen: React.FC<Cases3DScreenProps> = ({
  save,
  onBack,
  onBuyCase,
  onOpenCase,
  onBuyAndOpenCase,
  onEquipUnlocked,
}) => {
  const [spinningCase, setSpinningCase] = useState<CaseDef | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [equippedJustNow, setEquippedJustNow] = useState(false);
  const [revealed, setRevealed] = useState<{
    caseDef: CaseDef;
    itemKind: 'skin' | 'web';
    itemId: string;
    itemName: string;
    rarity: Rarity;
    wasDuplicate: boolean;
    bonusCoins: number;
  } | null>(null);
  const spinTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (spinTimerRef.current !== null) {
        window.clearTimeout(spinTimerRef.current);
      }
    };
  }, []);

  const triggerUnbox = (c: CaseDef, mode: 'open' | 'buy_and_open') => {
    if (spinTimerRef.current !== null) {
      window.clearTimeout(spinTimerRef.current);
      spinTimerRef.current = null;
    }
    setErrorMsg(null);
    setRevealed(null);
    setEquippedJustNow(false);
    setSpinningCase(c);

    spinTimerRef.current = window.setTimeout(() => {
      spinTimerRef.current = null;
      const res = mode === 'buy_and_open' ? onBuyAndOpenCase(c) : onOpenCase(c);
      setSpinningCase(null);
      if (res.ok) {
        setRevealed({
          caseDef: c,
          itemKind: res.itemKind,
          itemId: res.itemId,
          itemName: res.itemName,
          rarity: res.rarity,
          wasDuplicate: res.wasDuplicate,
          bonusCoins: res.bonusCoins,
        });
      } else {
        setErrorMsg(res.error);
      }
    }, 520);
  };

  return (
    <div className="fixed inset-0 z-30 bg-[#070B14] overflow-y-auto p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> MENU
            </button>
            <div>
              <h1 className="font-display text-2xl font-extrabold text-white flex items-center gap-2">
                <Box className="w-5 h-5 text-pink-400" /> SPIDER SUPPLY CASES (8 VAULTS)
              </h1>
              <p className="text-xs text-slate-400 font-mono-num">
                Opened Total: {save.stats.casesOpened} · Coins: {save.coins.toLocaleString()} ·
                Gems: {save.gems.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 font-mono-num text-sm font-bold">
            <span className="px-3 py-1.5 rounded-xl bg-slate-900 border border-amber-500/40 text-amber-300 flex items-center gap-1.5">
              <Coins className="w-4 h-4" /> {save.coins.toLocaleString()}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 flex items-center gap-1.5">
              <Gem className="w-4 h-4" /> {save.gems.toLocaleString()}
            </span>
          </div>
        </div>

        {errorMsg && (
          <div
            role="alert"
            className="mt-4 px-4 py-2.5 rounded-xl bg-rose-500/20 border border-rose-400/60 text-rose-200 text-xs font-bold flex items-center justify-between"
          >
            <span>{errorMsg}</span>
            <button
              type="button"
              onClick={() => setErrorMsg(null)}
              className="text-rose-200 hover:text-white cursor-pointer"
              aria-label="Dismiss alert"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* 8 Case Grid */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {CASE_CATALOG.map((c) => {
            const count = save.casesOwned[c.id] || 0;
            const canBuy = save.coins >= c.coinPrice && save.gems >= c.gemPrice;
            const rc = RARITY_CONFIG[c.rarity];
            return (
              <div
                key={c.id}
                data-testid={`case-card-${c.id}`}
                className="p-4 rounded-2xl bg-[#0B1120] border border-slate-800 flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span
                      className="px-2 py-0.5 rounded text-[10px] font-mono-num font-bold border"
                      style={{ color: rc.color, borderColor: rc.border, background: rc.bg }}
                    >
                      {c.rarity}
                    </span>
                    <span
                      data-testid={`case-owned-${c.id}`}
                      className="text-xs font-mono-num text-amber-300 font-bold"
                    >
                      OWNED: {count}
                    </span>
                  </div>
                  <h2 className="mt-2 font-display text-lg font-bold text-white">{c.name}</h2>
                  <p className="mt-1 text-xs text-slate-400">{c.description}</p>

                  {/* Transparent 100% Drop Table */}
                  <div className="mt-3 space-y-1">
                    {c.drops.map((d) => (
                      <div
                        key={d.rarity}
                        className="flex items-center justify-between text-[11px] font-mono-num"
                      >
                        <span style={{ color: RARITY_CONFIG[d.rarity].color }}>{d.rarity}</span>
                        <span className="text-slate-300">{d.probability}%</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col gap-2 pt-2 border-t border-slate-800">
                  {count > 0 ? (
                    <button
                      type="button"
                      disabled={Boolean(spinningCase)}
                      onClick={() => triggerUnbox(c, 'open')}
                      data-testid={`open-case-${c.id}`}
                      className="w-full py-2.5 rounded-xl text-xs font-display font-extrabold bg-emerald-400 hover:bg-emerald-300 text-slate-950 cursor-pointer"
                    >
                      OPEN CASE ({count} READY)
                    </button>
                  ) : canBuy ? (
                    <button
                      type="button"
                      disabled={Boolean(spinningCase)}
                      onClick={() => triggerUnbox(c, 'buy_and_open')}
                      data-testid={`buy-open-case-${c.id}`}
                      className="w-full py-2.5 rounded-xl text-xs font-display font-extrabold bg-amber-400 hover:bg-amber-300 text-slate-950 cursor-pointer"
                    >
                      BUY &amp; OPEN ({c.coinPrice.toLocaleString()})
                    </button>
                  ) : (
                    <div className="w-full py-2 rounded-xl text-[11px] font-mono-num font-bold bg-slate-900 border border-slate-800 text-slate-400 flex items-center justify-center gap-1.5">
                      <Lock className="w-3.5 h-3.5" />
                      <span>
                        NEED {c.coinPrice.toLocaleString()} COINS
                        {c.gemPrice > 0 ? ` + ${c.gemPrice}G` : ''}
                      </span>
                    </div>
                  )}

                  <button
                    type="button"
                    disabled={!canBuy || Boolean(spinningCase)}
                    onClick={() => {
                      const ok = onBuyCase(c.id);
                      if (!ok) {
                        setErrorMsg(`Not enough Coins or Gems for ${c.name}.`);
                      }
                    }}
                    data-testid={`buy-case-${c.id}`}
                    className={`w-full py-1.5 rounded-xl text-xs font-mono-num font-bold flex items-center justify-center gap-2 cursor-pointer ${
                      canBuy
                        ? 'bg-amber-400/15 border border-amber-400/50 text-amber-200 hover:bg-amber-400/25'
                        : 'bg-slate-900 border border-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    <span>BUY CRATE:</span>
                    <Coins className="w-3 h-3" /> {c.coinPrice.toLocaleString()}
                    {c.gemPrice > 0 && (
                      <span className="flex items-center gap-0.5">
                        <Gem className="w-3 h-3" /> {c.gemPrice}
                      </span>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Recent Unlocks History */}
        <div className="mt-6 p-4 rounded-2xl bg-[#0B1120] border border-slate-800">
          <h3 className="font-display text-sm font-bold text-slate-200 flex items-center gap-2">
            <History className="w-4 h-4 text-sky-400" /> RECENT CASE UNBOXING LOG
          </h3>
          {save.caseHistory.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">
              No cases unboxed yet. Open a Basic Case above to claim your first drop!
            </p>
          ) : (
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {save.caseHistory.slice(0, 9).map((h, i) => (
                <div
                  key={`${h.timestamp}-${i}`}
                  className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-bold text-white">{h.itemName}</div>
                    <div className="text-[10px] text-slate-400">{h.caseName}</div>
                  </div>
                  <span
                    className="font-mono-num font-bold text-[10px]"
                    style={{ color: RARITY_CONFIG[h.rarity].color }}
                  >
                    {h.rarity}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Centered Unboxing / Reward Reveal Modal (Always visible regardless of scroll) */}
      {(spinningCase || revealed) && (
        <div
          data-testid="case-reveal-modal"
          className="fixed inset-0 z-50 bg-slate-950/85 flex items-center justify-center p-4"
        >
          <div className="w-full max-w-md rounded-2xl bg-[#0B1224] border border-amber-400/60 p-6 text-center shadow-2xl">
            {spinningCase ? (
              <div className="py-6">
                <Box className="w-12 h-12 text-amber-400 mx-auto animate-bounce" />
                <div className="mt-4 font-display text-xl font-extrabold text-amber-300">
                  DECRYPTING {spinningCase.name.toUpperCase()}...
                </div>
                <p className="mt-1 text-xs text-slate-400">Rolling Spider Vault drop table</p>
              </div>
            ) : revealed ? (
              <div>
                <div
                  className="inline-block px-3 py-1 rounded-full text-xs font-mono-num font-bold border"
                  style={{
                    color: RARITY_CONFIG[revealed.rarity].color,
                    borderColor: RARITY_CONFIG[revealed.rarity].border,
                    background: RARITY_CONFIG[revealed.rarity].bg,
                  }}
                >
                  {revealed.rarity} {revealed.itemKind.toUpperCase()}
                </div>
                <h2
                  data-testid="case-reveal-item-name"
                  className="mt-3 font-display text-3xl font-extrabold text-white flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-6 h-6 text-amber-400" /> {revealed.itemName}
                </h2>
                <p className="mt-2 text-xs text-slate-300">
                  {revealed.wasDuplicate
                    ? `Duplicate converted into +${revealed.bonusCoins.toLocaleString()} Bonus Coins!`
                    : 'Unlocked and added to your Inventory vault!'}
                </p>

                <div className="mt-5 flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      onEquipUnlocked(revealed.itemKind, revealed.itemId);
                      setEquippedJustNow(true);
                    }}
                    data-testid="case-equip-reward-btn"
                    className={`w-full py-2.5 rounded-xl font-display font-extrabold text-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                      equippedJustNow
                        ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-300'
                        : 'bg-sky-400 hover:bg-sky-300 text-slate-950'
                    }`}
                  >
                    {equippedJustNow ? (
                      <>
                        <Check className="w-4 h-4" /> EQUIPPED!
                      </>
                    ) : (
                      `EQUIP ${revealed.itemKind === 'skin' ? 'SUIT' : 'WEB'} NOW`
                    )}
                  </button>

                  {(save.casesOwned[revealed.caseDef.id] || 0) > 0 && (
                    <button
                      type="button"
                      onClick={() => triggerUnbox(revealed.caseDef, 'open')}
                      data-testid="case-open-another-btn"
                      className="w-full py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-display font-extrabold text-xs cursor-pointer"
                    >
                      OPEN ANOTHER ({save.casesOwned[revealed.caseDef.id]} LEFT)
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setRevealed(null)}
                    data-testid="case-close-reveal-btn"
                    className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs cursor-pointer"
                  >
                    CLAIM &amp; CLOSE
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};

