import React from 'react';
import { ArrowLeft, CheckCircle2, Coins, Gem, ShieldAlert, Swords } from 'lucide-react';
import { BOSS_CATALOG } from '../../data/world3dCatalog';
import { BossDef, PlayerSaveData } from '../../types/spider3d';

interface BossArenaScreenProps {
  save: PlayerSaveData;
  onBack: () => void;
  onChallengeBoss: (boss: BossDef) => void;
}

export const BossArenaScreen: React.FC<BossArenaScreenProps> = ({
  save,
  onBack,
  onChallengeBoss,
}) => {
  const cycleProgress = save.matchesCompleted % 5;
  const nextAutoBoss = BOSS_CATALOG[save.bossesDefeatedCount % BOSS_CATALOG.length];

  return (
    <div className="fixed inset-0 z-30 bg-[#070B14] overflow-y-auto p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> MENU
            </button>
            <div>
              <h1 className="font-display text-2xl font-extrabold text-white flex items-center gap-2">
                <Swords className="w-5 h-5 text-rose-400" /> PROGRESSIVE BOSS ARENA (7 BOSSES)
              </h1>
              <p className="text-xs text-slate-400 font-mono-num">
                5-Match Auto-Boss Cycle: {cycleProgress}/5 Completed · Total Bosses Defeated:{' '}
                {save.bossesDefeatedCount}
              </p>
            </div>
          </div>

          <div className="px-4 py-2 rounded-xl bg-rose-500/15 border border-rose-500/45 text-xs font-mono-num text-rose-200 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>NEXT CYCLE TARGET: {nextAutoBoss.name.toUpperCase()}</span>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {BOSS_CATALOG.map((boss) => {
            const cleared = save.defeatedBossIds.includes(boss.id);
            return (
              <div
                key={boss.id}
                className="p-4 rounded-2xl bg-[#0B1120] border border-slate-800 flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span
                      className="px-2 py-0.5 rounded text-[10px] font-mono-num font-bold border"
                      style={{ color: boss.accentColor, borderColor: boss.emissiveColor }}
                    >
                      TIER #{boss.index}
                    </span>
                    {cleared && (
                      <span className="text-emerald-400 text-xs font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> CLEARED
                      </span>
                    )}
                  </div>

                  <h2 className="mt-2 font-display text-xl font-extrabold text-white">
                    {boss.name}
                  </h2>
                  <p className="text-xs text-slate-400">{boss.title}</p>

                  <div className="mt-3 grid grid-cols-2 gap-1.5 text-[11px] font-mono-num">
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-rose-300">
                      HP: {boss.maxHp.toLocaleString()}
                    </div>
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-amber-300">
                      DMG: {boss.attackDamage}
                    </div>
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-amber-200 flex items-center gap-1">
                      <Coins className="w-3 h-3" /> +{boss.coinReward}
                    </div>
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-cyan-300 flex items-center gap-1">
                      <Gem className="w-3 h-3" /> +{boss.gemReward}
                    </div>
                  </div>
                  {boss.rewardSkinId && (
                    <div className="mt-2 text-[11px] text-amber-300 font-semibold">
                      Drops Exclusive Boss Suit + Title!
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => onChallengeBoss(boss)}
                  data-testid={`challenge-boss-${boss.id}`}
                  className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-display font-bold text-xs tracking-wide cursor-pointer"
                >
                  ENTER BOSS ARENA
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
