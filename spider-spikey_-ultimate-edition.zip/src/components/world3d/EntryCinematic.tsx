import React, { useEffect, useState } from 'react';
import { Play, Shield, Sparkles } from 'lucide-react';
import { SkinDef, SeasonTheme } from '../../types/spider3d';

interface EntryCinematicProps {
  equippedSkin: SkinDef;
  season: SeasonTheme;
  onEnterWorld: () => void;
}

export const EntryCinematic: React.FC<EntryCinematicProps> = ({
  equippedSkin,
  season,
  onEnterWorld,
}) => {
  const [ready, setReady] = useState(false);
  const [progress, setProgress] = useState(14);

  useEffect(() => {
    const t = window.setTimeout(() => setReady(true), 140);
    const start = performance.now();
    const durationMs = 950;
    let rafId = 0;

    const step = (now: number) => {
      const ratio = Math.min(1, (now - start) / durationMs);
      const eased = Math.round(14 + ratio * 86);
      setProgress(eased);
      if (ratio < 1) {
        rafId = requestAnimationFrame(step);
      }
    };
    rafId = requestAnimationFrame(step);

    return () => {
      clearTimeout(t);
      cancelAnimationFrame(rafId);
    };
  }, []);

  const statusLabel =
    progress < 42
      ? 'Initializing 3D Metropolis & Skybox...'
      : progress < 76
        ? 'Calibrating 5-Direction Web Physics...'
        : progress < 100
          ? 'Spawning Suit & Dynamic Traffic...'
          : 'Engine Ready';

  return (
    <div className="fixed inset-0 z-30 flex flex-col items-center justify-between px-6 py-8 sm:py-10 pointer-events-auto bg-gradient-to-b from-[#070B14]/75 via-[#070B14]/25 to-[#060912]/88">
      {/* Top World Status Banner */}
      <div className="flex items-center gap-3 px-4 py-1.5 rounded-full border border-sky-400/35 bg-[#0A101D]/90 text-xs font-mono-num tracking-wider text-sky-300">
        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
        <span>SEASON EVENT: {season.replace('_', ' ')}</span>
        <span className="text-slate-600">|</span>
        <span className="text-amber-300">SUIT: {equippedSkin.name.toUpperCase()}</span>
      </div>

      {/* Upper-Center Hero Title Lockup + Loading Progress Bar (leaves lower viewport clear for 3D Spider showcase) */}
      <div
        className={`flex flex-col items-center text-center max-w-2xl mt-2 sm:mt-4 transition-all duration-700 ${
          ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}
      >
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-md bg-rose-600/20 border border-rose-500/40 text-rose-300 text-xs font-bold tracking-[0.22em] mb-3">
          <Shield className="w-3.5 h-3.5" />
          OPEN-WORLD 3D ACTION ADVENTURE
        </div>

        <h1 className="font-display text-4xl sm:text-6xl font-extrabold tracking-tight text-white drop-shadow-[0_6px_28px_rgba(0,0,0,0.85)]">
          SPIDER <span className="text-amber-400">WORLD</span> 3D
        </h1>

        <p className="mt-3 text-xs sm:text-sm text-slate-200 max-w-xl leading-relaxed bg-[#080C16]/85 px-5 py-2 rounded-xl border border-slate-700/60">
          Swing across towering skyscrapers with 5-direction web physics, conquer 10 portal worlds
          and 7 Spider Bosses, and unlock Mythic, Secret &amp; Exclusive suits.
        </p>

        {/* Animated Loading Progress Indicator */}
        <div
          data-testid="entry-loading-bar"
          className="mt-4 w-full max-w-md bg-[#080C16]/90 border border-slate-700/75 rounded-xl px-4 py-2.5"
        >
          <div className="flex items-center justify-between text-[11px] font-mono-num text-slate-300 mb-1.5">
            <span>{statusLabel}</span>
            <span className="text-amber-300 font-bold">{progress}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-sky-400 via-amber-400 to-emerald-400 transition-all duration-150"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <button
          type="button"
          onClick={onEnterWorld}
          data-testid="enter-world-btn"
          className="mt-4 group inline-flex items-center gap-3 px-8 py-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-display font-extrabold text-base sm:text-lg tracking-wide shadow-[0_0_35px_rgba(245,196,81,0.45)] transition-transform active:scale-95 cursor-pointer"
        >
          <Play className="w-5 h-5 fill-slate-950 transition-transform group-hover:translate-x-0.5" />
          ENTER MAIN MENU
        </button>
      </div>

      <div className="flex-1" />

      {/* Minimal Bottom Hint */}
      <div className="text-xs text-slate-300/85 font-mono-num tracking-wider bg-[#080C16]/85 px-4 py-1.5 rounded-lg border border-slate-800">
        WASD MOVE · SPACE JUMP · 1-5 WEB DIRECTION · LEFT CLICK / F SHOOT WEB · Q SKILL · ESC PAUSE
      </div>
    </div>
  );
};
