import React from 'react';
import { ArrowLeft, CheckCircle2, Coins, Gem, Lock, Play, Sparkles } from 'lucide-react';
import { LEVELS_3D_CATALOG } from '../../data/levels3d';
import { LevelDef, PlayerSaveData } from '../../types/spider3d';

interface LevelsScreenProps {
  save: PlayerSaveData;
  onBack: () => void;
  onPlayLevel: (level: LevelDef) => void;
}

export const LevelsScreen: React.FC<LevelsScreenProps> = ({ save, onBack, onPlayLevel }) => {
  return (
    <div className="fixed inset-0 z-30 bg-[#070B14] overflow-y-auto p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> MENU
            </button>
            <div>
              <h1 className="font-display text-2xl font-extrabold text-white">
                ADVENTURE CAMPAIGN (10 LEVELS)
              </h1>
              <p className="text-xs text-slate-400 font-mono-num">
                Unlocked: {save.unlockedLevel}/10 · Completed: {save.completedLevels.length}/10 ·
                Enter the Final Portal in each level to unlock the next world!
              </p>
            </div>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {LEVELS_3D_CATALOG.map((lvl) => {
            const unlocked = lvl.id <= (save.unlockedLevel || 1);
            const completed = save.completedLevels.includes(lvl.id);

            return (
              <div
                key={lvl.id}
                className={`p-4 rounded-2xl border flex flex-col justify-between gap-3 transition ${
                  unlocked
                    ? 'bg-[#0B1120] border-slate-700/90 hover:border-amber-400/70'
                    : 'bg-[#080C15] border-slate-800/70 opacity-75'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-mono-num">
                    <span className="font-bold text-slate-300">
                      LEVEL {lvl.id} · {lvl.difficulty.toUpperCase()}
                    </span>
                    {completed ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> CLEARED
                      </span>
                    ) : !unlocked ? (
                      <span className="text-slate-500 flex items-center gap-1">
                        <Lock className="w-3.5 h-3.5" /> LOCKED
                      </span>
                    ) : (
                      <span className="text-amber-400 font-bold flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5" /> NEXT
                      </span>
                    )}
                  </div>

                  <div className="mt-2 flex items-center gap-2">
                    <span
                      className="w-3.5 h-3.5 rounded-full shrink-0 border border-white/40"
                      style={{ backgroundColor: lvl.portalColor }}
                    />
                    <h2 className="font-display text-lg font-extrabold text-white">{lvl.name}</h2>
                  </div>
                  <p className="mt-1 text-xs text-slate-400 leading-relaxed">{lvl.subtitle}</p>

                  <div className="mt-3 grid grid-cols-2 gap-1.5 text-[11px] font-mono-num">
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-amber-300 flex items-center gap-1">
                      <Coins className="w-3 h-3" /> +{lvl.coinReward}
                    </div>
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-cyan-300 flex items-center gap-1">
                      <Gem className="w-3 h-3" /> +{lvl.gemReward}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={!unlocked}
                  onClick={() => onPlayLevel(lvl)}
                  data-testid={`play-level-${lvl.id}`}
                  className={`w-full py-2.5 rounded-xl text-xs font-display font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                    unlocked
                      ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                      : 'bg-slate-900 border border-slate-800 text-slate-500'
                  }`}
                >
                  {unlocked ? (
                    <>
                      <Play className="w-3.5 h-3.5 fill-slate-950" />
                      {completed ? `REPLAY LEVEL ${lvl.id}` : `ENTER LEVEL ${lvl.id}`}
                    </>
                  ) : (
                    `CLEAR LEVEL ${lvl.id - 1} FIRST`
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
