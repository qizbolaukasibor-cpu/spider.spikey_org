import React, { useMemo, useState } from 'react';
import { ArrowLeft, Check, Coins, Gem, Heart, Search, Sparkles, Zap } from 'lucide-react';
import {
  RARITY_CONFIG,
  SKIN_BY_ID,
  SKIN_CATALOG,
  WEB_BY_ID,
  WEB_CATALOG,
} from '../../data/world3dCatalog';
import { PlayerSaveData, Rarity } from '../../types/spider3d';
import { SkinPreview3D } from './SkinPreview3D';

interface CosmeticsScreenProps {
  initialTab: 'SKINS' | 'WEBS' | 'INVENTORY';
  save: PlayerSaveData;
  onBack: () => void;
  onEquipSkin: (id: string) => void;
  onToggleFavoriteSkin: (id: string) => void;
  onBuySkin: (id: string) => void;
  onEquipWeb: (id: string) => void;
  onBuyWeb: (id: string) => void;
  onOpenCasesTab: () => void;
}

const RARITIES: Array<'ALL' | Rarity> = [
  'ALL',
  'COMMON',
  'UNCOMMON',
  'RARE',
  'EPIC',
  'LEGENDARY',
  'MYTHIC',
  'SECRET',
  'EXCLUSIVE',
];

export const CosmeticsScreen: React.FC<CosmeticsScreenProps> = ({
  initialTab,
  save,
  onBack,
  onEquipSkin,
  onToggleFavoriteSkin,
  onBuySkin,
  onEquipWeb,
  onBuyWeb,
  onOpenCasesTab,
}) => {
  const [tab, setTab] = useState<'SKINS' | 'WEBS' | 'INVENTORY'>(initialTab);
  const [rarityFilter, setRarityFilter] = useState<'ALL' | Rarity>('ALL');
  const [sortBy, setSortBy] = useState<'rarity' | 'owned' | 'price'>('rarity');
  const [query, setQuery] = useState('');
  const [previewSkinId, setPreviewSkinId] = useState(save.equippedSkinId);

  const previewSkin = SKIN_BY_ID[previewSkinId] || SKIN_CATALOG[0];

  const filteredSkins = useMemo(() => {
    return SKIN_CATALOG.filter((s) => {
      if (tab === 'INVENTORY' && !save.ownedSkinIds.includes(s.id)) return false;
      if (rarityFilter !== 'ALL' && s.rarity !== rarityFilter) return false;
      if (query.trim() && !s.name.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    }).sort((a, b) => {
      if (sortBy === 'owned') {
        const ao = save.ownedSkinIds.includes(a.id) ? 0 : 1;
        const bo = save.ownedSkinIds.includes(b.id) ? 0 : 1;
        if (ao !== bo) return ao - bo;
      } else if (sortBy === 'price') {
        return b.coinPrice - a.coinPrice;
      }
      return RARITY_CONFIG[b.rarity].order - RARITY_CONFIG[a.rarity].order;
    });
  }, [tab, rarityFilter, query, sortBy, save.ownedSkinIds]);

  const filteredWebs = useMemo(() => {
    return WEB_CATALOG.filter((w) => {
      if (tab === 'INVENTORY' && !save.ownedWebIds.includes(w.id)) return false;
      if (rarityFilter !== 'ALL' && w.rarity !== rarityFilter) return false;
      if (query.trim() && !w.name.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    }).sort((a, b) => {
      if (sortBy === 'owned') {
        const ao = save.ownedWebIds.includes(a.id) ? 0 : 1;
        const bo = save.ownedWebIds.includes(b.id) ? 0 : 1;
        if (ao !== bo) return ao - bo;
      } else if (sortBy === 'price') {
        return b.coinPrice - a.coinPrice;
      }
      return RARITY_CONFIG[b.rarity].order - RARITY_CONFIG[a.rarity].order;
    });
  }, [tab, rarityFilter, query, sortBy, save.ownedWebIds]);

  const activeWeb = WEB_BY_ID[save.equippedWebId];

  return (
    <div className="fixed inset-0 z-30 bg-[#070B14] overflow-y-auto p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> MENU
            </button>
            <div>
              <h1 className="font-display text-2xl font-extrabold text-white">
                {tab === 'SKINS'
                  ? 'SPIDER SUIT COLLECTION'
                  : tab === 'WEBS'
                  ? 'ELEMENTAL WEB COLLECTION'
                  : 'HERO INVENTORY & LOADOUT'}
              </h1>
              <p className="text-xs text-slate-400 font-mono-num">
                Suits: {save.ownedSkinIds.length}/{SKIN_CATALOG.length} · Webs:{' '}
                {save.ownedWebIds.length}/{WEB_CATALOG.length}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {(['SKINS', 'WEBS', 'INVENTORY'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                className={`px-4 py-2 rounded-xl text-xs font-display font-bold cursor-pointer ${
                  tab === t
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-900 border border-slate-700 text-slate-300 hover:text-white'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            {RARITIES.map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRarityFilter(r)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono-num font-bold border cursor-pointer ${
                  rarityFilter === r
                    ? 'bg-sky-500 text-slate-950 border-sky-400'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-600'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search cosmetics..."
                className="pl-8 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-400"
              />
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'rarity' | 'owned' | 'price')}
              className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
            >
              <option value="rarity">Sort: Rarity</option>
              <option value="owned">Sort: Owned First</option>
              <option value="price">Sort: Value</option>
            </select>
          </div>
        </div>

        {/* Main Content Split: 3D Preview Panel + Cards Grid */}
        <div className="mt-5 grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left 3D Preview */}
          <div className="lg:col-span-4 rounded-2xl bg-[#0B1120] border border-slate-800 p-3.5 flex flex-col gap-2.5 h-fit">
            <SkinPreview3D skin={previewSkin} height={220} />
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span
                    className="text-[10px] font-mono-num font-bold px-2 py-0.5 rounded border"
                    style={{
                      color: RARITY_CONFIG[previewSkin.rarity].color,
                      borderColor: RARITY_CONFIG[previewSkin.rarity].border,
                    }}
                  >
                    {previewSkin.rarity}
                  </span>
                  <span className="text-[11px] font-mono-num text-sky-300">
                    +{Math.round(previewSkin.speedBonus * 100)}% SPD
                  </span>
                  <span className="text-[11px] font-mono-num text-amber-300">
                    +{previewSkin.powerBonus}% PWR
                  </span>
                </div>
                <h2
                  data-testid="preview-skin-title"
                  className="mt-1 font-display text-lg font-extrabold text-white truncate"
                >
                  {previewSkin.name}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onToggleFavoriteSkin(previewSkin.id)}
                className={`p-2 rounded-lg border cursor-pointer shrink-0 ${
                  save.favoriteSkinIds.includes(previewSkin.id)
                    ? 'border-rose-500 bg-rose-500/20 text-rose-400'
                    : 'border-slate-700 text-slate-400'
                }`}
                title="Favorite Suit"
              >
                <Heart className="w-4 h-4 fill-current" />
              </button>
            </div>
            <p className="text-[11px] text-slate-300 leading-snug">{previewSkin.description}</p>

            {/* Direct Skin Selection / Equip Button */}
            {save.ownedSkinIds.includes(previewSkin.id) ? (
              <button
                type="button"
                onClick={() => onEquipSkin(previewSkin.id)}
                data-testid="preview-select-skin-btn"
                className={`w-full py-2 rounded-xl font-display font-extrabold text-xs tracking-wide flex items-center justify-center gap-1.5 cursor-pointer ${
                  save.equippedSkinId === previewSkin.id
                    ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-300'
                    : 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                }`}
              >
                {save.equippedSkinId === previewSkin.id ? (
                  <>
                    <Check className="w-4 h-4" /> CURRENTLY EQUIPPED
                  </>
                ) : (
                  `SELECT ${previewSkin.name.toUpperCase()} SUIT`
                )}
              </button>
            ) : previewSkin.caseOnly ? (
              <button
                type="button"
                onClick={onOpenCasesTab}
                className="w-full py-2 rounded-xl bg-teal-500/20 border border-teal-400/50 text-teal-200 font-bold text-xs cursor-pointer"
              >
                UNLOCK VIA CASES
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onBuySkin(previewSkin.id)}
                disabled={save.coins < previewSkin.coinPrice || save.gems < previewSkin.gemPrice}
                className="w-full py-2 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:bg-slate-800 disabled:text-slate-400 text-slate-950 font-bold text-xs cursor-pointer"
              >
                BUY SUIT ({previewSkin.coinPrice.toLocaleString()} COINS)
              </button>
            )}

            <div className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono-num text-slate-300">
              Entrance: <span className="text-white">{previewSkin.entranceStyle}</span> · Victory:{' '}
              <span className="text-white">{previewSkin.victoryStyle}</span>
            </div>

            {previewSkin.abilities && previewSkin.abilities.length > 0 && (
              <div
                data-testid="skin-abilities-panel"
                className="p-2.5 rounded-xl bg-slate-900/90 border border-rose-500/35 space-y-1.5"
              >
                <div className="text-[10px] font-display font-bold text-rose-300 tracking-wider uppercase flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-purple-400" /> SPECIAL ABILITIES ({previewSkin.abilities.length})
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {previewSkin.abilities.map((ab, idx) => (
                    <div
                      key={ab.name}
                      className={`p-1.5 rounded-lg bg-slate-950/70 border border-slate-800/80 text-[10px] leading-snug ${
                        idx === previewSkin.abilities!.length - 1 && previewSkin.abilities!.length % 2 === 1
                          ? 'sm:col-span-2'
                          : ''
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bold truncate" style={{ color: ab.accentColor }}>
                          {ab.name}
                        </span>
                        <span className="font-mono-num text-[9px] px-1 py-0.5 rounded bg-slate-800 text-slate-200 shrink-0">
                          {ab.keyHint}
                        </span>
                      </div>
                      <p className="text-slate-400 text-[9.5px] mt-0.5 line-clamp-2">{ab.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-1.5 border-t border-slate-800 text-[11px] flex items-center justify-between">
              <span className="text-slate-400">Equipped Web:</span>
              <span className="font-bold text-sky-300">{activeWeb?.name}</span>
            </div>
          </div>

          {/* Right Cards Grid */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            {(tab === 'SKINS' || tab === 'INVENTORY') && (
              <section>
                <h3 className="font-display text-sm font-bold text-slate-300 tracking-wider mb-3 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" /> SPIDER SUITS ({filteredSkins.length})
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
                  {filteredSkins.map((sk) => {
                    const owned = save.ownedSkinIds.includes(sk.id);
                    const equipped = save.equippedSkinId === sk.id;
                    const rc = RARITY_CONFIG[sk.rarity];
                    const canAfford = save.coins >= sk.coinPrice && save.gems >= sk.gemPrice;
                    return (
                      <div
                        key={sk.id}
                        data-testid={`skin-card-${sk.id}`}
                        onClick={() => setPreviewSkinId(sk.id)}
                        className={`p-3.5 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                          previewSkinId === sk.id
                            ? 'border-amber-400 bg-slate-900'
                            : 'border-slate-800 bg-[#0B1120] hover:border-slate-600'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2">
                            <span
                              className="px-2 py-0.5 rounded text-[10px] font-mono-num font-bold border"
                              style={{ color: rc.color, borderColor: rc.border, background: rc.bg }}
                            >
                              {sk.rarity}
                            </span>
                            <span
                              className="w-4 h-4 rounded-full border border-white/30"
                              style={{ backgroundColor: sk.primaryColor }}
                            />
                          </div>
                          <div className="mt-2 font-display font-bold text-white text-sm">
                            {sk.name}
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5">{sk.unlockHint}</div>
                        </div>

                        <div className="mt-3 pt-2.5 border-t border-slate-800/90">
                          {owned ? (
                            <button
                              type="button"
                              data-testid={`equip-skin-${sk.id}`}
                              onClick={(e) => {
                                e.stopPropagation();
                                setPreviewSkinId(sk.id);
                                onEquipSkin(sk.id);
                              }}
                              className={`w-full py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1 cursor-pointer ${
                                equipped
                                  ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-300'
                                  : 'bg-sky-500 hover:bg-sky-400 text-slate-950'
                              }`}
                            >
                              {equipped ? (
                                <>
                                  <Check className="w-3.5 h-3.5" /> EQUIPPED
                                </>
                              ) : (
                                'EQUIP SUIT'
                              )}
                            </button>
                          ) : sk.caseOnly ? (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onOpenCasesTab();
                              }}
                              className="w-full py-1.5 rounded-lg bg-teal-500/20 border border-teal-400/50 text-teal-200 text-xs font-bold cursor-pointer"
                            >
                              OPEN CASES
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onBuySkin(sk.id);
                              }}
                              disabled={!canAfford}
                              className={`w-full py-1.5 rounded-lg text-xs font-mono-num font-bold flex items-center justify-center gap-2 cursor-pointer ${
                                canAfford
                                  ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              <Coins className="w-3 h-3" /> {sk.coinPrice.toLocaleString()}
                              {sk.gemPrice > 0 && (
                                <span className="flex items-center gap-0.5">
                                  <Gem className="w-3 h-3" /> {sk.gemPrice}
                                </span>
                              )}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}

            {(tab === 'WEBS' || tab === 'INVENTORY') && (
              <section>
                <h3 className="font-display text-sm font-bold text-slate-300 tracking-wider mb-3 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-cyan-400" /> ELEMENTAL WEBS ({filteredWebs.length})
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
                  {filteredWebs.map((wb) => {
                    const owned = save.ownedWebIds.includes(wb.id);
                    const equipped = save.equippedWebId === wb.id;
                    const rc = RARITY_CONFIG[wb.rarity];
                    const canAfford = save.coins >= wb.coinPrice && save.gems >= wb.gemPrice;
                    return (
                      <div
                        key={wb.id}
                        className="p-3.5 rounded-xl border border-slate-800 bg-[#0B1120] flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span
                              className="px-2 py-0.5 rounded text-[10px] font-mono-num font-bold border"
                              style={{ color: rc.color, borderColor: rc.border, background: rc.bg }}
                            >
                              {wb.rarity}
                            </span>
                            <span
                              className="w-6 h-2 rounded-full"
                              style={{ backgroundColor: wb.color }}
                            />
                          </div>
                          <div className="mt-2 font-display font-bold text-white text-sm">
                            {wb.name}
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1">{wb.description}</p>
                          <div className="mt-2 text-[11px] font-mono-num text-sky-300">
                            Speed x{wb.speedMultiplier.toFixed(2)} · Pull x{wb.pullForce.toFixed(2)}
                          </div>
                        </div>

                        <div className="mt-3 pt-2.5 border-t border-slate-800">
                          {owned ? (
                            <button
                              type="button"
                              onClick={() => onEquipWeb(wb.id)}
                              className={`w-full py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                                equipped
                                  ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-300'
                                  : 'bg-cyan-400 hover:bg-cyan-300 text-slate-950'
                              }`}
                            >
                              {equipped ? 'EQUIPPED WEB' : 'EQUIP WEB'}
                            </button>
                          ) : wb.caseOnly ? (
                            <button
                              type="button"
                              onClick={onOpenCasesTab}
                              className="w-full py-1.5 rounded-lg bg-teal-500/20 border border-teal-400/50 text-teal-200 text-xs font-bold cursor-pointer"
                            >
                              CASE EXCLUSIVE
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => onBuyWeb(wb.id)}
                              disabled={!canAfford}
                              className={`w-full py-1.5 rounded-lg text-xs font-mono-num font-bold flex items-center justify-center gap-2 cursor-pointer ${
                                canAfford
                                  ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              <Coins className="w-3 h-3" /> {wb.coinPrice.toLocaleString()}
                              {wb.gemPrice > 0 && (
                                <span className="flex items-center gap-0.5">
                                  <Gem className="w-3 h-3" /> {wb.gemPrice}
                                </span>
                              )}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
