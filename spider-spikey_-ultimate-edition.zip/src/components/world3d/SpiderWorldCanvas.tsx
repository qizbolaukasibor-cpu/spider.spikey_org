import React, { useEffect, useImperativeHandle, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { SKIN_BY_ID, WEB_BY_ID } from '../../data/world3dCatalog';
import {
  buildBoss3D,
  buildSpiderCharacter3D,
  BossRig3D,
  createProceduralTextures,
  createSkyDomeTexture,
  getSeasonPalette,
  SpiderRig3D,
} from '../../game3d/proceduralModels';
import { buildAdventureLevel3D, BuiltLevelWorld3D } from '../../game3d/levelBuilder';
import { buildCityWorld } from '../../game3d/worldBuilder';
import {
  checkPortalTrigger,
  computeFiveDirectionVector,
  computeWebReleaseBoost,
  findSkyscraperWebAnchor,
  resolveCityCollision,
  stepAirFlightPhysics,
  stepWebSwingPhysics,
} from '../../game3d/worldRules';
import {
  BossDef,
  LevelDef,
  PlayerSaveData,
  SpiderAnimState,
  WebDirection,
} from '../../types/spider3d';
import { audio3d } from '../../utils/spider3dAudio';
import { DEFAULT_KEY_BINDINGS } from '../../utils/spider3dStorage';

export interface HudSnapshot3D {
  hp: number;
  maxHp: number;
  shieldTimer: number;
  shadowTimer: number;
  ultTimer: number;
  dashCooldown: number;
  strikeCooldown: number;
  trapCooldown: number;
  shieldCooldown: number;
  shadowCooldown: number;
  ultCooldown: number;
  webAttached: boolean;
  webPulling: boolean;
  activeDirection: WebDirection;
  matchScore: number;
  matchTarget: number;
  orbsRun: number;
  dronesRun: number;
  bossHp: number;
  bossMaxHp: number;
  bossTelegraph: boolean;
  timePhase: 'DAY' | 'DUSK' | 'NIGHT';
  secretFound: boolean;
  animState: SpiderAnimState;
  movementStyle: string;
  isFlying: boolean;
  altitude: number;
  speedKmh: number;
  bannerText: string | null;
  levelId: number | null;
  levelName: string | null;
  portalDistance: number | null;
  warpingPortal: boolean;
  fps: number;
}

export interface SpiderWorldHandle {
  shootWeb: (overrideDir?: WebDirection) => void;
  releaseWeb: () => void;
  setPulling: (active: boolean) => void;
  triggerJump: () => void;
  triggerFight: () => void;
  triggerSkill: (kind: 'dash' | 'shield' | 'shadow' | 'trap' | 'ult') => void;
}

interface SpiderWorldCanvasProps {
  mode: 'MENU_IDLE' | 'LEVEL_MATCH' | 'CITY_MATCH' | 'BOSS_ARENA';
  paused: boolean;
  save: PlayerSaveData;
  activeDirection: WebDirection;
  activeBoss: BossDef | null;
  activeLevel: LevelDef | null;
  runKey: number;
  onChangeDirection: (dir: WebDirection) => void;
  onHudUpdate: (snap: HudSnapshot3D) => void;
  onCollectOrb: (kind: 'orb' | 'gem' | 'secret') => void;
  onShootWebStat: () => void;
  onUseSkillStat: () => void;
  onDistanceStat: (meters: number) => void;
  onMatchVictory: (summary: { orbs: number; drones: number; coins: number; xp: number }) => void;
  onLevelCompleted: (level: LevelDef, stats: { orbs: number; enemies: number }) => void;
  onBossVictory: (boss: BossDef) => void;
  onPlayerDefeat: (fromBoss: boolean, reason?: string) => void;
  onTogglePause: () => void;
}

const MAX_WEATHER = 480;
const MAX_BURST = 96;

export const SpiderWorldCanvas = React.forwardRef<SpiderWorldHandle, SpiderWorldCanvasProps>(
  function SpiderWorldCanvas(props, ref) {
    const {
      mode,
      paused,
      save,
      activeDirection,
      activeBoss,
      activeLevel,
      runKey,
      onChangeDirection,
      onHudUpdate,
      onCollectOrb,
      onShootWebStat,
      onUseSkillStat,
      onDistanceStat,
      onMatchVictory,
      onLevelCompleted,
      onBossVictory,
      onPlayerDefeat,
      onTogglePause,
    } = props;

    const mountRef = useRef<HTMLDivElement>(null);

    // Live reactive refs read by the single WebGL animation loop
    const modeRef = useRef(mode);
    const pausedRef = useRef(paused);
    const saveRef = useRef(save);
    const dirRef = useRef(activeDirection);
    const bossRef = useRef(activeBoss);
    const levelRef = useRef(activeLevel);
    const callbacksRef = useRef({
      onChangeDirection,
      onHudUpdate,
      onCollectOrb,
      onShootWebStat,
      onUseSkillStat,
      onDistanceStat,
      onMatchVictory,
      onLevelCompleted,
      onBossVictory,
      onPlayerDefeat,
      onTogglePause,
    });

    modeRef.current = mode;
    pausedRef.current = paused;
    saveRef.current = save;
    dirRef.current = activeDirection;
    bossRef.current = activeBoss;
    levelRef.current = activeLevel;
    callbacksRef.current = {
      onChangeDirection,
      onHudUpdate,
      onCollectOrb,
      onShootWebStat,
      onUseSkillStat,
      onDistanceStat,
      onMatchVictory,
      onLevelCompleted,
      onBossVictory,
      onPlayerDefeat,
      onTogglePause,
    };

    // Imperative trigger bridge
    const actionQueueRef = useRef<Array<() => void>>([]);
    const manualPullRef = useRef(false);

    useImperativeHandle(ref, () => ({
      shootWeb: (overrideDir?: WebDirection) => {
        if (overrideDir) callbacksRef.current.onChangeDirection(overrideDir);
        actionQueueRef.current.push(() => fireWebInternalRef.current(overrideDir));
      },
      releaseWeb: () => {
        actionQueueRef.current.push(() => releaseWebInternalRef.current());
      },
      setPulling: (active: boolean) => {
        manualPullRef.current = active;
      },
      triggerJump: () => {
        actionQueueRef.current.push(() => jumpInternalRef.current());
      },
      triggerFight: () => {
        actionQueueRef.current.push(() => fightInternalRef.current());
      },
      triggerSkill: (kind) => {
        actionQueueRef.current.push(() => skillInternalRef.current(kind));
      },
    }));

    const fireWebInternalRef = useRef<(overrideDir?: WebDirection) => void>(() => {});
    const releaseWebInternalRef = useRef<() => void>(() => {});
    const jumpInternalRef = useRef<() => void>(() => {});
    const fightInternalRef = useRef<() => void>(() => {});
    const skillInternalRef = useRef<(k: 'dash' | 'shield' | 'shadow' | 'trap' | 'ult') => void>(() => {});
    const resetRunRef = useRef<() => void>(() => {});

    // Trigger reset when mode, runKey, activeBoss, or activeLevel changes
    const prevRunSignatureRef = useRef('');
    useEffect(() => {
      const sig = `${mode}:${runKey}:${activeBoss?.id || 'none'}:${activeLevel?.id || 'none'}`;
      if (prevRunSignatureRef.current !== sig) {
        prevRunSignatureRef.current = sig;
        resetRunRef.current();
      }
    }, [mode, runKey, activeBoss, activeLevel]);

    useEffect(() => {
      const container = mountRef.current;
      if (!container) return;

      // 1. Renderer & Software WebGL Probe (Three.js skill §3 + Ultra Mode)
      const probeCanvas = document.createElement('canvas');
      const glProbe = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
      const hwProbeCanvas = document.createElement('canvas');
      const hwGl =
        hwProbeCanvas.getContext('webgl2', { failIfMajorPerformanceCaveat: true }) ||
        hwProbeCanvas.getContext('webgl', { failIfMajorPerformanceCaveat: true });
      let isSoftwareGl = Boolean(glProbe && !hwGl) || Boolean(navigator.webdriver);
      if (glProbe) {
        const rendererParam = String(glProbe.getParameter(glProbe.RENDERER) || '');
        if (/SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(rendererParam)) {
          isSoftwareGl = true;
        }
        const dbg = glProbe.getExtension('WEBGL_debug_renderer_info');
        if (dbg) {
          const rStr = String(glProbe.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '');
          if (/SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(rStr)) {
            isSoftwareGl = true;
          }
        }
      }

      const renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: isSoftwareGl ? 'low-power' : 'high-performance',
      });
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 0.82;
      renderer.shadowMap.enabled = !isSoftwareGl && saveRef.current.settings.shadows;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      container.appendChild(renderer.domElement);

      let contextLost = false;
      const onContextLost = (e: Event) => {
        e.preventDefault();
        contextLost = true;
      };
      const onContextRestored = () => {
        contextLost = false;
      };
      renderer.domElement.addEventListener('webglcontextlost', onContextLost);
      renderer.domElement.addEventListener('webglcontextrestored', onContextRestored);

      // 2. Scene, Camera, RoomEnvironment IBL
      const scene = new THREE.Scene();
      const initialPal = getSeasonPalette(saveRef.current.settings.activeSeason);
      scene.background = new THREE.Color(initialPal.skyColor);
      scene.fog = new THREE.FogExp2(initialPal.fogColor, 0.0052);

      const pmrem = new THREE.PMREMGenerator(renderer);
      const envRT = pmrem.fromScene(new RoomEnvironment(), 0.04);
      scene.environment = envRT.texture;
      scene.environmentIntensity = 0.42;
      pmrem.dispose();

      const camera = new THREE.PerspectiveCamera(
        58,
        (container.clientWidth || 1280) / (container.clientHeight || 720),
        0.2,
        460
      );

      // Post-processing Bloom Pipeline (GPU-only so SwiftShader software captures stay instant)
      const initW = container.clientWidth || window.innerWidth;
      const initH = container.clientHeight || window.innerHeight;
      let composer: EffectComposer | null = null;
      let bloomPass: UnrealBloomPass | null = null;
      if (!isSoftwareGl) {
        composer = new EffectComposer(renderer);
        composer.addPass(new RenderPass(scene, camera));
        bloomPass = new UnrealBloomPass(new THREE.Vector2(initW, initH), 0.18, 0.28, 0.92);
        composer.addPass(bloomPass);
        composer.addPass(new OutputPass());
      }

      // Procedural Atmospheric Sky Dome & Glowing Sun Disc
      const skyTex = createSkyDomeTexture('#0A1833', initialPal.hemiSky, initialPal.fogColor);
      const skyDomeGeo = new THREE.SphereGeometry(295, 18, 12);
      const skyDomeMat = new THREE.MeshBasicMaterial({
        map: skyTex,
        side: THREE.BackSide,
        fog: false,
        depthWrite: false,
      });
      const skyDome = new THREE.Mesh(skyDomeGeo, skyDomeMat);
      skyDome.renderOrder = 1;
      scene.add(skyDome);

      const sunDiscGeo = new THREE.SphereGeometry(8.5, 18, 12);
      const sunDiscMat = new THREE.MeshBasicMaterial({
        color: initialPal.sunColor,
        fog: false,
      });
      const sunDisc = new THREE.Mesh(sunDiscGeo, sunDiscMat);
      scene.add(sunDisc);

      // 3. Lighting (Hemisphere + Sun Directional + Ambient Fill)
      const hemiLight = new THREE.HemisphereLight(initialPal.hemiSky, initialPal.hemiGround, 0.46);
      scene.add(hemiLight);

      const sunLight = new THREE.DirectionalLight(initialPal.sunColor, initialPal.sunIntensity);
      sunLight.position.set(42, 68, 36);
      sunLight.castShadow = !isSoftwareGl && saveRef.current.settings.shadows;
      sunLight.shadow.mapSize.set(1024, 1024);
      sunLight.shadow.camera.near = 5;
      sunLight.shadow.camera.far = 220;
      const d = 55;
      sunLight.shadow.camera.left = -d;
      sunLight.shadow.camera.right = d;
      sunLight.shadow.camera.top = d;
      sunLight.shadow.camera.bottom = -d;
      scene.add(sunLight);
      scene.add(sunLight.target);

      // 4. World, Procedural Textures & Player Spider Rig
      const maxAniso = isSoftwareGl ? 1 : Math.min(8, renderer.capabilities.getMaxAnisotropy());
      const textures = createProceduralTextures(maxAniso);
      const world = buildCityWorld(textures, saveRef.current.settings.activeSeason);
      scene.add(world.worldGroup);

      const initialSkin = SKIN_BY_ID[saveRef.current.equippedSkinId] || Object.values(SKIN_BY_ID)[0];
      const spider: SpiderRig3D = buildSpiderCharacter3D(initialSkin, textures.contactShadowMap);
      scene.add(spider.root);

      // 5. Active Web Beam Mesh + Projectile + Anchor Ring + Trap Snare Ring
      const webMat = new THREE.MeshBasicMaterial({ color: '#F1F5F9' });
      const webCylinder = new THREE.Mesh(
        new THREE.CylinderGeometry(0.055, 0.055, 1, 8),
        webMat
      );
      webCylinder.visible = false;
      scene.add(webCylinder);

      const webAnchorNode = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.32, 0),
        new THREE.MeshBasicMaterial({ color: '#38BDF8' })
      );
      webAnchorNode.visible = false;
      scene.add(webAnchorNode);

      const trapRing = new THREE.Mesh(
        new THREE.RingGeometry(2.6, 3.3, 32),
        new THREE.MeshBasicMaterial({
          color: '#E2E8F0',
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.72,
        })
      );
      trapRing.rotation.x = -Math.PI / 2;
      trapRing.visible = false;
      scene.add(trapRing);

      // 6. Pooled Weather Particles + Impact/Firework Burst Pool (zero runtime allocation)
      const weatherPositions = new Float32Array(MAX_WEATHER * 3);
      for (let i = 0; i < MAX_WEATHER; i++) {
        weatherPositions[i * 3] = (Math.random() - 0.5) * 90;
        weatherPositions[i * 3 + 1] = Math.random() * 44;
        weatherPositions[i * 3 + 2] = (Math.random() - 0.5) * 90;
      }
      const weatherGeo = new THREE.BufferGeometry();
      weatherGeo.setAttribute('position', new THREE.BufferAttribute(weatherPositions, 3));
      const weatherMat = new THREE.PointsMaterial({
        color: '#E0F2FE',
        size: 0.35,
        transparent: true,
        opacity: 0.75,
        depthWrite: false,
      });
      const weatherPoints = new THREE.Points(weatherGeo, weatherMat);
      scene.add(weatherPoints);

      // Soft circular spark/wind sprite texture (eliminates blocky square points near camera)
      const sparkCanvas = document.createElement('canvas');
      sparkCanvas.width = 32;
      sparkCanvas.height = 32;
      const sparkCtx = sparkCanvas.getContext('2d');
      if (sparkCtx) {
        const grad = sparkCtx.createRadialGradient(16, 16, 1, 16, 16, 15);
        grad.addColorStop(0, 'rgba(255,255,255,1)');
        grad.addColorStop(0.45, 'rgba(255,255,255,0.75)');
        grad.addColorStop(1, 'rgba(255,255,255,0)');
        sparkCtx.fillStyle = grad;
        sparkCtx.fillRect(0, 0, 32, 32);
      }
      const sparkTex = new THREE.CanvasTexture(sparkCanvas);

      const burstPositions = new Float32Array(MAX_BURST * 3);
      const burstVelocities = new Float32Array(MAX_BURST * 3);
      const burstLife = new Float32Array(MAX_BURST);
      const burstGeo = new THREE.BufferGeometry();
      burstGeo.setAttribute('position', new THREE.BufferAttribute(burstPositions, 3));
      const burstMat = new THREE.PointsMaterial({
        color: '#F5C451',
        map: sparkTex,
        size: 0.42,
        transparent: true,
        opacity: 0.92,
        depthWrite: false,
      });
      const burstPoints = new THREE.Points(burstGeo, burstMat);
      scene.add(burstPoints);

      // High-Speed Wind / Web-Trail Streak Pool
      const MAX_STREAK = 64;
      const streakPositions = new Float32Array(MAX_STREAK * 3);
      const streakGeo = new THREE.BufferGeometry();
      streakGeo.setAttribute('position', new THREE.BufferAttribute(streakPositions, 3));
      const streakMat = new THREE.PointsMaterial({
        color: '#7DD3FC',
        map: sparkTex,
        size: 0.34,
        transparent: true,
        opacity: 0.0,
        depthWrite: false,
      });
      const streakPoints = new THREE.Points(streakGeo, streakMat);
      scene.add(streakPoints);
      let streakCursor = 0;

      const spawnBurst = (cx: number, cy: number, cz: number, colorHex: string, speed = 11) => {
        burstMat.color.set(colorHex);
        for (let i = 0; i < MAX_BURST; i++) {
          const theta = (i * 2.39996) % (Math.PI * 2);
          const up = ((i % 7) - 2) * 0.35;
          burstPositions[i * 3] = cx;
          burstPositions[i * 3 + 1] = cy;
          burstPositions[i * 3 + 2] = cz;
          burstVelocities[i * 3] = Math.cos(theta) * speed * (0.4 + ((i * 13) % 10) * 0.08);
          burstVelocities[i * 3 + 1] = up * speed;
          burstVelocities[i * 3 + 2] = Math.sin(theta) * speed * (0.4 + ((i * 17) % 10) * 0.08);
          burstLife[i] = 0.55 + (i % 5) * 0.1;
        }
        burstGeo.attributes.position.needsUpdate = true;
      };

      // Boss Telegraphed Slam Ring
      const bossAttackRing = new THREE.Mesh(
        new THREE.RingGeometry(1.5, 2.2, 36),
        new THREE.MeshBasicMaterial({
          color: '#EF4444',
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.78,
        })
      );
      bossAttackRing.rotation.x = -Math.PI / 2;
      bossAttackRing.visible = false;
      scene.add(bossAttackRing);

      // Miles Morales Venom Bio-Electric Shockwave Ring
      const venomShockGeo = new THREE.RingGeometry(0.9, 1.65, 32);
      const venomShockMat = new THREE.MeshBasicMaterial({
        color: '#FF2E4D',
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.9,
        depthWrite: false,
      });
      const venomShockRing = new THREE.Mesh(venomShockGeo, venomShockMat);
      venomShockRing.rotation.x = -Math.PI / 2;
      venomShockRing.visible = false;
      scene.add(venomShockRing);
      let venomShockTimer = 0;
      let venomDashTrailTimer = 0;

      const isMilesActive = () =>
        SKIN_BY_ID[saveRef.current.equippedSkinId]?.variant === 'miles_morales';

      const triggerVenomShockwave = (cx: number, cy: number, cz: number, colorHex = '#FF2E4D') => {
        venomShockMat.color.set(colorHex);
        venomShockRing.position.set(cx, Math.max(0.18, cy + 0.35), cz);
        venomShockRing.scale.setScalar(0.8);
        venomShockRing.visible = true;
        venomShockTimer = 0.45;
      };

      // 7. Mutable Gameplay Simulation State
      const raycaster = new THREE.Raycaster();
      const tmpOrigin = new THREE.Vector3();
      const tmpDir = new THREE.Vector3();
      const tmpStart = new THREE.Vector3();
      const tmpEnd = new THREE.Vector3();
      const tmpCamPos = new THREE.Vector3();
      const tmpLookAt = new THREE.Vector3();
      const upVec = new THREE.Vector3(0, 1, 0);

      let activeBossRig: BossRig3D | null = null;
      let bossHp = 0;
      let bossMaxHp = 1000;
      let bossAttackTimer = 2.0;
      let bossTelegraphTimer = 0;
      let bossRingExpandTimer = 0;
      let bossRingOrigin = new THREE.Vector3();
      let bossDefeatedFlag = false;

      const playerPos = { x: 0, y: 0, z: 12 };
      const playerVel = { x: 0, y: 0, z: 0 };
      let playerYaw = 0;
      let camYaw = 0;
      let camPitch = 0.28;
      let grounded = true;
      let jumpsUsed = 0;
      let touchingWall = false;
      let landTimer = 0;
      let fightTimer = 0;
      let dodgeTimer = 0;
      let skillAnimTimer = 0;
      let victoryTimer = 0;
      let entranceTimer = 1.1;
      let matchFinished = false;

      let hp = 100;
      const maxHp = 100;
      let shieldTimer = 0;
      let shadowTimer = 0;
      let ultTimer = 0;
      let trapTimer = 0;
      let dashCooldown = 0;
      let strikeCooldown = 0;
      let trapCooldown = 0;
      let shieldCooldown = 0;
      let shadowCooldown = 0;
      let ultCooldown = 0;
      let invulnTimer = 0;

      // Web projectile + attachment + Spider Flight state
      let webFlightActive = false;
      let webAttached = false;
      let webRopeLength = 14;
      const webProjPos = new THREE.Vector3();
      const webProjVel = new THREE.Vector3();
      const webAnchorPos = new THREE.Vector3();
      const webStartOrigin = new THREE.Vector3();
      const webAimDir = new THREE.Vector3(0, 0, -1);
      let webFlightTimer = 0;
      let airLaunchTimer = 0;
      let playerBank = 0;
      let camBank = 0;
      let flightBannerShown = false;

      let orbsRun = 0;
      let dronesRun = 0;
      const matchTarget = 5;
      let secretFound = false;
      let distAccum = 0;
      let bannerText: string | null = null;
      let bannerTimer = 0;
      let animState: SpiderAnimState = 'entrance';
      let appliedSkinId = initialSkin.id;
      let appliedSeason = saveRef.current.settings.activeSeason;
      let appliedQualitySig = '';
      let fireworksCooldown = 2.5;
      let dayClock = 0.25; // start bright morning/midday
      let lastHudPush = 0;
      let fpsFrames = 0;
      let fpsWindowStart = performance.now();
      let measuredFps = 60;
      let lastRenderMs = performance.now();

      const setBanner = (msg: string, sec = 2.6) => {
        bannerText = msg;
        bannerTimer = sec;
      };

      let activeLevelWorld: BuiltLevelWorld3D | null = null;
      let portalTriggered = false;
      let portalWarpTimer = 0;

      const rebuildActiveBoss = () => {
        if (activeBossRig) {
          scene.remove(activeBossRig.root);
          activeBossRig = null;
        }
        const bDef = bossRef.current;
        if (modeRef.current === 'BOSS_ARENA' && bDef) {
          activeBossRig = buildBoss3D(bDef, textures.contactShadowMap);
          activeBossRig.root.position.set(0, 0.85, 118);
          scene.add(activeBossRig.root);
          bossHp = bDef.maxHp;
          bossMaxHp = bDef.maxHp;
          bossAttackTimer = bDef.attackInterval;
          bossTelegraphTimer = 0;
          bossRingExpandTimer = 0;
          bossDefeatedFlag = false;
          bossAttackRing.visible = false;
        }
      };

      const syncActiveWorld = () => {
        if (activeLevelWorld) {
          scene.remove(activeLevelWorld.worldGroup);
          activeLevelWorld.dispose();
          activeLevelWorld = null;
        }
        if (modeRef.current === 'LEVEL_MATCH' && levelRef.current) {
          world.worldGroup.visible = false;
          activeLevelWorld = buildAdventureLevel3D(levelRef.current, textures);
          scene.add(activeLevelWorld.worldGroup);
        } else {
          world.worldGroup.visible = true;
        }
      };

      const resetRunState = () => {
        syncActiveWorld();
        playerVel.x = 0;
        playerVel.y = 0;
        playerVel.z = 0;
        webFlightActive = false;
        webAttached = false;
        webCylinder.visible = false;
        webAnchorNode.visible = false;
        trapRing.visible = false;
        airLaunchTimer = 0;
        playerBank = 0;
        camBank = 0;
        flightBannerShown = false;
        spider.root.scale.setScalar(1);
        spider.root.rotation.z = 0;
        hp = maxHp;
        orbsRun = 0;
        dronesRun = 0;
        matchFinished = false;
        portalTriggered = false;
        portalWarpTimer = 0;
        victoryTimer = 0;
        entranceTimer = 1.0;
        shieldTimer = 0;
        shadowTimer = 0;
        ultTimer = 0;
        invulnTimer = 0.8;

        // Restore city world collectibles & drones cleanly
        world.collectibles.forEach((c) => {
          c.collected = false;
          c.mesh.visible = true;
        });
        world.drones.forEach((dr) => {
          dr.alive = true;
          dr.hp = dr.maxHp;
          dr.koTimer = 0;
          dr.group.visible = true;
          dr.group.position.copy(dr.origin);
        });

        if (modeRef.current === 'LEVEL_MATCH' && activeLevelWorld) {
          if (activeBossRig) {
            scene.remove(activeBossRig.root);
            activeBossRig = null;
          }
          const lvl = activeLevelWorld.levelDef;
          playerPos.x = lvl.startPos.x;
          playerPos.y = lvl.startPos.y;
          playerPos.z = lvl.startPos.z;
          camYaw = 0;
          playerYaw = 0;
          setBanner(`LEVEL ${lvl.id}: ${lvl.name.toUpperCase()} — REACH THE PORTAL!`, 3.4);
        } else if (modeRef.current === 'BOSS_ARENA') {
          playerPos.x = 0;
          playerPos.y = 0.85;
          playerPos.z = 86;
          camYaw = Math.PI; // look toward +Z boss at (0, 118)
          playerYaw = Math.PI;
          rebuildActiveBoss();
          setBanner(
            bossRef.current ? `BOSS ENCOUNTER: ${bossRef.current.name.toUpperCase()}` : 'BOSS ARENA',
            3.0
          );
        } else {
          if (activeBossRig) {
            scene.remove(activeBossRig.root);
            activeBossRig = null;
          }
          playerPos.x = 0;
          playerPos.y = 0;
          playerPos.z = 12;
          camYaw = 0; // look down -Z central skyline
          playerYaw = 0;
          if (modeRef.current === 'CITY_MATCH') {
            setBanner('COLLECT 5 ORBS OR DEFEAT DRONES — SWING WITH 1-5 + LMB / F', 3.4);
          }
        }
        spider.root.position.set(playerPos.x, playerPos.y, playerPos.z);
        spider.root.rotation.y = playerYaw;
      };

      resetRunRef.current = resetRunState;
      resetRunState();

      // 8. Input Listeners (Keyboard + Mouse Drag + Wheel + Click Shoot)
      const keys = new Set<string>();
      let mouseDragging = false;
      let dragMoved = false;
      let lastPointerX = 0;
      let lastPointerY = 0;

      const fireWeb = (overrideDir?: WebDirection) => {
        if (modeRef.current === 'MENU_IDLE' || pausedRef.current || matchFinished) return;
        const chosenDir = overrideDir || dirRef.current;
        const webDef = WEB_BY_ID[saveRef.current.equippedWebId] || Object.values(WEB_BY_ID)[0];
        const miles = isMilesActive();
        const fastSwingLvl = saveRef.current.skillLevels.fast_swing || 0;
        const vec = computeFiveDirectionVector(chosenDir, camYaw, camPitch);
        const speed = 132 * webDef.speedMultiplier * (1 + fastSwingLvl * 0.08);

        // Support fluid mid-air web-to-web chaining without losing flight/swing momentum
        if (webAttached) {
          webAttached = false;
          webAnchorNode.visible = false;
          playerVel.y = Math.max(playerVel.y, 5.2);
          airLaunchTimer = Math.max(airLaunchTimer, 1.4);
        }

        webStartOrigin.set(playerPos.x, playerPos.y + 1.5, playerPos.z);
        webAimDir.set(vec.x, vec.y, vec.z).normalize();
        webProjPos.copy(webStartOrigin);
        webProjVel.copy(webAimDir).multiplyScalar(speed);
        webFlightActive = true;
        webFlightTimer = 0.88;
        skillAnimTimer = 0.22;
        if (miles && webDef.id === 'web_classic') {
          webMat.color.set('#FF2E4D');
          (webAnchorNode.material as THREE.MeshBasicMaterial).color.set('#A855F7');
          spawnBurst(playerPos.x, playerPos.y + 1.4, playerPos.z, '#FF2E4D', 7);
        } else {
          webMat.color.set(webDef.color);
          (webAnchorNode.material as THREE.MeshBasicMaterial).color.set(webDef.glowColor);
        }
        audio3d.playWebShoot(webDef.soundPitch);
        callbacksRef.current.onShootWebStat();
      };

      const releaseWeb = () => {
        if (webAttached || webFlightActive) {
          const wasAttached = webAttached;
          webAttached = false;
          webFlightActive = false;
          webCylinder.visible = false;
          webAnchorNode.visible = false;
          if (wasAttached) {
            const swingLvl = saveRef.current.skillLevels.fast_swing || 0;
            const boosted = computeWebReleaseBoost(playerVel, camYaw, 1 + swingLvl * 0.1);
            playerVel.x = boosted.x;
            playerVel.y = boosted.y;
            playerVel.z = boosted.z;
            airLaunchTimer = 2.6;
            const webDef = WEB_BY_ID[saveRef.current.equippedWebId];
            spawnBurst(
              playerPos.x,
              playerPos.y + 1.2,
              playerPos.z,
              isMilesActive() ? '#A855F7' : webDef?.particleColor || '#38BDF8',
              11
            );
            if (!flightBannerShown) {
              flightBannerShown = true;
              setBanner('SPIDER FLIGHT ACTIVE — HOLD SPACE TO GLIDE & SHOOT NEXT WEB!', 2.6);
            }
          }
        }
      };

      const performJump = () => {
        if (modeRef.current === 'MENU_IDLE' || pausedRef.current || matchFinished) return;
        const miles = isMilesActive();
        if (webAttached) {
          releaseWeb();
          playerVel.y = Math.max(playerVel.y, miles ? 15.2 : 13.8);
          jumpsUsed = 1;
          airLaunchTimer = 2.6;
          if (miles) {
            triggerVenomShockwave(playerPos.x, playerPos.y, playerPos.z, '#C084FC');
            spawnBurst(playerPos.x, playerPos.y + 0.5, playerPos.z, '#FF2E4D', 12);
          }
          audio3d.playJump(false);
          return;
        }
        const superJumpLvl = saveRef.current.skillLevels.super_jump || 0;
        const dblJumpLvl = saveRef.current.skillLevels.double_jump || 1;
        if (grounded || touchingWall) {
          playerVel.y = 13.2 + superJumpLvl * 1.3 + (miles ? 1.8 : 0);
          grounded = false;
          jumpsUsed = 1;
          if (miles) {
            triggerVenomShockwave(playerPos.x, playerPos.y, playerPos.z, '#FF2E4D');
            spawnBurst(playerPos.x, playerPos.y + 0.35, playerPos.z, '#A855F7', 10);
          }
          audio3d.playJump(false);
        } else if (jumpsUsed < 2) {
          // Venom Jump electric explosion mid-air
          playerVel.y = 12.6 + dblJumpLvl * 1.25 + (miles ? 2.6 : 0);
          jumpsUsed = 2;
          airLaunchTimer = Math.max(airLaunchTimer, 1.6);
          audio3d.playJump(true);
          if (miles) {
            triggerVenomShockwave(playerPos.x, playerPos.y, playerPos.z, '#A855F7');
            spawnBurst(playerPos.x, playerPos.y + 0.4, playerPos.z, '#FF2E4D', 14);
            setBanner('VENOM JUMP SHOCKWAVE!', 1.3);
            for (const dr of world.drones) {
              if (!dr.alive || modeRef.current === 'LEVEL_MATCH') continue;
              if (Math.hypot(dr.group.position.x - playerPos.x, dr.group.position.z - playerPos.z) < 7.5) {
                dr.hp -= 55;
                if (dr.hp <= 0) {
                  dr.alive = false;
                  dr.group.visible = false;
                  dr.koTimer = 14;
                  dronesRun += 1;
                }
              }
            }
          } else {
            spawnBurst(playerPos.x, playerPos.y + 0.4, playerPos.z, '#38BDF8', 7);
          }
        }
      };

      const performFight = () => {
        if (modeRef.current === 'MENU_IDLE' || pausedRef.current || matchFinished) return;
        if (strikeCooldown > 0) return;
        const miles = isMilesActive();
        const strikeLvl = saveRef.current.skillLevels.spider_strike || 0;
        const ultMult = ultTimer > 0 ? 1.8 : 1.0;
        const skinPower = 1 + ((SKIN_BY_ID[saveRef.current.equippedSkinId]?.powerBonus || 0) / 100);
        const dmg = Math.round((45 + strikeLvl * 16) * ultMult * skinPower * (miles ? 1.32 : 1.0));
        strikeCooldown = 0.42;
        fightTimer = 0.36;
        audio3d.playStrike();
        const strikeX = playerPos.x - Math.sin(playerYaw) * 1.4;
        const strikeZ = playerPos.z - Math.cos(playerYaw) * 1.4;
        if (miles) {
          triggerVenomShockwave(strikeX, playerPos.y + 0.6, strikeZ, '#FF2E4D');
          spawnBurst(strikeX, playerPos.y + 1.2, strikeZ, '#A855F7', 13);
        } else {
          spawnBurst(strikeX, playerPos.y + 1.2, strikeZ, '#FB7185', 8);
        }

        // Hit nearby patrolling drones (City Match) — Venom Punch reaches slightly wider arc
        const hitRadius = miles ? 7.6 : 6.2;
        for (const dr of world.drones) {
          if (!dr.alive || modeRef.current === 'LEVEL_MATCH') continue;
          const dist = Math.hypot(dr.group.position.x - playerPos.x, dr.group.position.z - playerPos.z);
          if (dist < hitRadius && Math.abs(dr.group.position.y - playerPos.y) < 5) {
            dr.hp -= dmg;
            if (dr.hp <= 0) {
              dr.alive = false;
              dr.group.visible = false;
              dr.koTimer = 14;
              dronesRun += 1;
              audio3d.playPickup();
              spawnBurst(dr.group.position.x, dr.group.position.y, dr.group.position.z, '#FBBF24', 12);
              setBanner(
                `${miles ? 'VENOM PUNCH KO!' : 'DRONE NEUTRALIZED!'} (${orbsRun + dronesRun}/${matchTarget})`,
                1.8
              );
            }
          }
        }

        // Hit nearby enemies in 10-Level Adventure
        if (activeLevelWorld) {
          for (const en of activeLevelWorld.enemies) {
            if (!en.alive) continue;
            const dist = Math.hypot(en.rig.group.position.x - playerPos.x, en.rig.group.position.z - playerPos.z);
            if (dist < (miles ? 7.8 : 6.4) && Math.abs(en.rig.group.position.y - playerPos.y) < 5.5) {
              en.hp -= dmg;
              spawnBurst(
                en.rig.group.position.x,
                en.rig.group.position.y + 1.1,
                en.rig.group.position.z,
                miles ? '#FF2E4D' : '#FB7185',
                9
              );
              if (en.hp <= 0) {
                en.alive = false;
                en.rig.group.visible = false;
                en.koTimer = 18;
                dronesRun += 1;
                audio3d.playPickup();
                spawnBurst(en.rig.group.position.x, en.rig.group.position.y + 1.2, en.rig.group.position.z, '#FBBF24', 14);
                setBanner(`${miles ? 'VENOM K.O.!' : 'ENEMY DEFEATED!'} (+${dronesRun} KO)`, 1.6);
              }
            }
          }
        }

        // Hit Boss
        if (modeRef.current === 'BOSS_ARENA' && activeBossRig && !bossDefeatedFlag) {
          const dist = Math.hypot(
            activeBossRig.root.position.x - playerPos.x,
            activeBossRig.root.position.z - playerPos.z
          );
          if (dist < (miles ? 9.5 : 8.5)) {
            bossHp = Math.max(0, bossHp - dmg);
            spawnBurst(
              activeBossRig.root.position.x,
              activeBossRig.root.position.y + 2.2,
              activeBossRig.root.position.z,
              miles ? '#FF2E4D' : bossRef.current?.emissiveColor || '#F5C451',
              12
            );
            if (bossHp <= 0 && !bossDefeatedFlag && bossRef.current) {
              bossDefeatedFlag = true;
              victoryTimer = 2.6;
              audio3d.playVictory();
              spawnBurst(
                activeBossRig.root.position.x,
                activeBossRig.root.position.y + 3,
                activeBossRig.root.position.z,
                '#F5C451',
                18
              );
              callbacksRef.current.onBossVictory(bossRef.current);
            }
          }
        }
      };

      const performSkill = (kind: 'dash' | 'shield' | 'shadow' | 'trap' | 'ult') => {
        if (modeRef.current === 'MENU_IDLE' || pausedRef.current || matchFinished) return;
        const miles = isMilesActive();
        const lvls = saveRef.current.skillLevels;
        if (kind === 'dash' && dashCooldown <= 0) {
          const fx = -Math.sin(camYaw);
          const fz = -Math.cos(camYaw);
          const boost = 28 + (lvls.web_dash || 0) * 4 + (lvls.air_dash || 0) * 2.5 + (miles ? 6 : 0);
          playerVel.x = fx * boost;
          playerVel.z = fz * boost;
          playerVel.y = Math.max(playerVel.y, 4.5);
          dashCooldown = 3.2;
          skillAnimTimer = 0.4;
          audio3d.playSkill(false);
          if (miles) {
            venomDashTrailTimer = 0.75;
            triggerVenomShockwave(playerPos.x, playerPos.y + 0.5, playerPos.z, '#FF2E4D');
            spawnBurst(playerPos.x, playerPos.y + 1, playerPos.z, '#A855F7', 13);
            setBanner('VENOM DASH SURGE!', 1.4);
          } else {
            spawnBurst(playerPos.x, playerPos.y + 1, playerPos.z, '#FBBF24', 10);
          }
          // Electric arc AoE damage
          if (miles || (lvls.electric_attack || 0) > 0 || modeRef.current === 'BOSS_ARENA') {
            if (activeBossRig && !bossDefeatedFlag) {
              const dist = Math.hypot(
                activeBossRig.root.position.x - playerPos.x,
                activeBossRig.root.position.z - playerPos.z
              );
              if (dist < 10.5) {
                bossHp = Math.max(0, bossHp - (65 + (lvls.electric_attack || 0) * 25 + (miles ? 35 : 0)));
                if (bossHp <= 0 && bossRef.current) {
                  bossDefeatedFlag = true;
                  victoryTimer = 2.5;
                  callbacksRef.current.onBossVictory(bossRef.current);
                }
              }
            }
          }
          if (activeLevelWorld) {
            for (const en of activeLevelWorld.enemies) {
              if (!en.alive) continue;
              const dist = Math.hypot(en.rig.group.position.x - playerPos.x, en.rig.group.position.z - playerPos.z);
              if (dist < (miles ? 9.5 : 8.5)) {
                en.hp -= 60 + (lvls.electric_attack || 0) * 20 + (miles ? 30 : 0);
                if (en.hp <= 0) {
                  en.alive = false;
                  en.rig.group.visible = false;
                  en.koTimer = 18;
                  dronesRun += 1;
                  audio3d.playPickup();
                }
              }
            }
          }
          callbacksRef.current.onUseSkillStat();
        } else if (kind === 'shield' && shieldCooldown <= 0) {
          shieldTimer = 4.5 + (lvls.web_shield || 0) * 0.8;
          shieldCooldown = 10;
          skillAnimTimer = 0.35;
          audio3d.playSkill(true);
          setBanner('WEB SHIELD ACTIVE', 1.5);
          callbacksRef.current.onUseSkillStat();
        } else if (kind === 'shadow' && shadowCooldown <= 0) {
          shadowTimer = (miles ? 5.8 : 4.5) + (lvls.shadow_mode || 0) * 0.8;
          dodgeTimer = 0.45;
          shadowCooldown = 11;
          audio3d.playSkill(false);
          spawnBurst(playerPos.x, playerPos.y + 1, playerPos.z, miles ? '#A855F7' : '#64748B', 10);
          setBanner(miles ? 'CAMOUFLAGE ENGAGED — STEALTH INVISIBLE!' : 'SHADOW CLOAK ACTIVE', 1.8);
          callbacksRef.current.onUseSkillStat();
        } else if (kind === 'trap' && trapCooldown <= 0) {
          trapTimer = 5.0;
          trapCooldown = 8;
          trapRing.position.set(playerPos.x, playerPos.y + 0.15, playerPos.z);
          trapRing.visible = true;
          skillAnimTimer = 0.35;
          audio3d.playWebAttach(0.8);
          setBanner('WEB TRAP DEPLOYED', 1.5);
          callbacksRef.current.onUseSkillStat();
        } else if (kind === 'ult' && ultCooldown <= 0) {
          ultTimer = 8.0;
          ultCooldown = 18;
          skillAnimTimer = 0.7;
          hp = Math.min(maxHp, hp + 25);
          audio3d.playLevelUp();
          if (miles) {
            triggerVenomShockwave(playerPos.x, playerPos.y + 0.4, playerPos.z, '#FF2E4D');
            spawnBurst(playerPos.x, playerPos.y + 1.2, playerPos.z, '#A855F7', 16);
            setBanner('VENOM STRIKE OVERCHARGE!', 2.2);
            for (const dr of world.drones) {
              if (!dr.alive || modeRef.current === 'LEVEL_MATCH') continue;
              if (Math.hypot(dr.group.position.x - playerPos.x, dr.group.position.z - playerPos.z) < 13.5) {
                dr.hp -= 140;
                if (dr.hp <= 0) {
                  dr.alive = false;
                  dr.group.visible = false;
                  dr.koTimer = 14;
                  dronesRun += 1;
                }
              }
            }
            if (activeLevelWorld) {
              for (const en of activeLevelWorld.enemies) {
                if (!en.alive) continue;
                if (Math.hypot(en.rig.group.position.x - playerPos.x, en.rig.group.position.z - playerPos.z) < 13.5) {
                  en.hp -= 140;
                  if (en.hp <= 0) {
                    en.alive = false;
                    en.rig.group.visible = false;
                    en.koTimer = 18;
                    dronesRun += 1;
                  }
                }
              }
            }
            if (modeRef.current === 'BOSS_ARENA' && activeBossRig && !bossDefeatedFlag) {
              if (Math.hypot(activeBossRig.root.position.x - playerPos.x, activeBossRig.root.position.z - playerPos.z) < 14) {
                bossHp = Math.max(0, bossHp - 180);
                if (bossHp <= 0 && bossRef.current) {
                  bossDefeatedFlag = true;
                  victoryTimer = 2.6;
                  callbacksRef.current.onBossVictory(bossRef.current);
                }
              }
            }
          } else {
            spawnBurst(playerPos.x, playerPos.y + 1.2, playerPos.z, '#F5C451', 15);
            setBanner('ULTIMATE SPIDER POWER ACTIVATED!', 2.2);
          }
          callbacksRef.current.onUseSkillStat();
        }
      };

      fireWebInternalRef.current = fireWeb;
      releaseWebInternalRef.current = releaseWeb;
      jumpInternalRef.current = performJump;
      fightInternalRef.current = performFight;
      skillInternalRef.current = performSkill;

      const onKeyDown = (e: KeyboardEvent) => {
        if (e.code === 'Escape' || e.code === 'KeyP') {
          if (modeRef.current !== 'MENU_IDLE') {
            callbacksRef.current.onTogglePause();
          }
          return;
        }
        if (modeRef.current === 'MENU_IDLE' || pausedRef.current) return;
        keys.add(e.code);
        const kb = saveRef.current.settings.keyBindings || DEFAULT_KEY_BINDINGS;

        if (e.code === kb.web1) {
          dirRef.current = 'FORWARD';
          callbacksRef.current.onChangeDirection('FORWARD');
        } else if (e.code === kb.web2) {
          dirRef.current = 'BACKWARD';
          callbacksRef.current.onChangeDirection('BACKWARD');
        } else if (e.code === kb.web3) {
          dirRef.current = 'LEFT';
          callbacksRef.current.onChangeDirection('LEFT');
        } else if (e.code === kb.web4) {
          dirRef.current = 'RIGHT';
          callbacksRef.current.onChangeDirection('RIGHT');
        } else if (e.code === kb.web5) {
          dirRef.current = 'UPWARD';
          callbacksRef.current.onChangeDirection('UPWARD');
        } else if (e.code === kb.jump) {
          e.preventDefault();
          performJump();
        } else if (e.code === kb.shootWeb) {
          fireWeb();
        } else if (e.code === kb.releaseWeb) {
          releaseWeb();
        } else if (e.code === kb.fight) {
          performFight();
        } else if (e.code === kb.skill) {
          performSkill('dash');
        } else if (e.code === kb.interact) {
          if (!webAttached) performSkill('shield');
        } else if (e.code === 'KeyC') {
          performSkill('shadow');
        } else if (e.code === 'KeyX') {
          performSkill('trap');
        } else if (e.code === 'KeyV') {
          performSkill('ult');
        }
      };

      const onKeyUp = (e: KeyboardEvent) => {
        keys.delete(e.code);
      };

      const onPointerDown = (e: PointerEvent) => {
        if (e.target !== renderer.domElement) return;
        if (modeRef.current === 'MENU_IDLE' || pausedRef.current) return;
        mouseDragging = true;
        dragMoved = false;
        lastPointerX = e.clientX;
        lastPointerY = e.clientY;
        if (e.button === 2) {
          if (webAttached || webFlightActive) {
            releaseWeb();
          } else {
            performFight();
          }
        }
      };

      const onPointerMove = (e: PointerEvent) => {
        if (!mouseDragging || modeRef.current === 'MENU_IDLE' || pausedRef.current) return;
        const dx = e.clientX - lastPointerX;
        const dy = e.clientY - lastPointerY;
        if (Math.hypot(dx, dy) > 4) dragMoved = true;
        lastPointerX = e.clientX;
        lastPointerY = e.clientY;
        const sens =
          0.0048 *
          (saveRef.current.settings.cameraSensitivity || 1) *
          (saveRef.current.settings.mouseSensitivity ?? 1);
        camYaw -= dx * sens;
        camPitch = THREE.MathUtils.clamp(camPitch + dy * sens * 0.75, -0.25, 0.95);
      };

      const onPointerUp = (e: PointerEvent) => {
        if (e.button === 0 && !dragMoved && e.target === renderer.domElement) {
          if (modeRef.current !== 'MENU_IDLE' && !pausedRef.current) {
            fireWeb();
          }
        }
        mouseDragging = false;
      };

      const onContextMenu = (e: MouseEvent) => {
        if (e.target === renderer.domElement) e.preventDefault();
      };

      const onResize = () => {
        const w = container.clientWidth || window.innerWidth;
        const h = container.clientHeight || window.innerHeight;
        renderer.setSize(w, h);
        if (composer) composer.setSize(w, h);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      };

      window.addEventListener('keydown', onKeyDown);
      window.addEventListener('keyup', onKeyUp);
      window.addEventListener('pointerdown', onPointerDown);
      window.addEventListener('pointermove', onPointerMove);
      window.addEventListener('pointerup', onPointerUp);
      window.addEventListener('contextmenu', onContextMenu);
      window.addEventListener('resize', onResize);

      // 9. Animation Loop with Software-WebGL afterDraw Pacing
      let running = true;
      let prevMs = performance.now();
      let elapsed = 0;

      const afterDraw = (cb: () => void) => {
        if (!isSoftwareGl) {
          requestAnimationFrame(cb);
          return;
        }
        const gl = renderer.getContext() as WebGL2RenderingContext;
        if (typeof gl.fenceSync === 'function') {
          const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
          gl.flush();
          const poll = () => {
            if (!running) return;
            if (!sync || gl.clientWaitSync(sync, 0, 0) !== gl.TIMEOUT_EXPIRED) {
              if (sync) gl.deleteSync(sync);
              requestAnimationFrame(cb);
            } else {
              window.setTimeout(poll, 8);
            }
          };
          window.setTimeout(poll, 65);
        } else {
          window.setTimeout(() => requestAnimationFrame(cb), 80);
        }
      };

      const tick = () => {
        if (!running) return;
        if (document.hidden) {
          window.setTimeout(() => requestAnimationFrame(tick), 200);
          return;
        }

        const nowMs = performance.now();
        const rawDt = (nowMs - prevMs) / 1000;
        prevMs = nowMs;
        const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
        elapsed += dt;

        // Sync live skin, season, graphics preset, resolution scale, view distance & particle density
        const curSave = saveRef.current;
        const st = curSave.settings;
        const kb = st.keyBindings || DEFAULT_KEY_BINDINGS;
        if (curSave.equippedSkinId !== appliedSkinId) {
          appliedSkinId = curSave.equippedSkinId;
          const sk = SKIN_BY_ID[appliedSkinId];
          if (sk) spider.updateSkin(sk);
        }
        if (st.activeSeason !== appliedSeason) {
          appliedSeason = st.activeSeason;
          world.applySeason(appliedSeason);
        }
        const qSig = `${st.graphicsQuality}:${st.resolutionScale ?? 1}:${st.viewDistance ?? 'far'}:${st.particleQuality ?? 'high'}:${st.bloom ?? true}`;
        if (qSig !== appliedQualitySig) {
          appliedQualitySig = qSig;
          const baseMaxDpr =
            st.graphicsQuality === 'low'
              ? 1
              : st.graphicsQuality === 'medium'
                ? Math.min(window.devicePixelRatio || 1, 1.4)
                : Math.min(window.devicePixelRatio || 1, 2);
          const scale = THREE.MathUtils.clamp(st.resolutionScale ?? 1, 0.6, 1.25);
          const effectiveDpr = isSoftwareGl ? 1 : THREE.MathUtils.clamp(baseMaxDpr * scale, 0.6, 2.25);
          renderer.setPixelRatio(effectiveDpr);
          const curW = container.clientWidth || window.innerWidth;
          const curH = container.clientHeight || window.innerHeight;
          renderer.setSize(curW, curH);
          if (composer) {
            composer.setSize(curW, curH);
          }
          if (bloomPass) {
            bloomPass.strength =
              st.graphicsQuality === 'extreme'
                ? 0.28
                : st.graphicsQuality === 'ultra'
                  ? 0.22
                  : st.graphicsQuality === 'high'
                    ? 0.16
                    : 0.1;
          }
          const vd = st.viewDistance ?? 'far';
          camera.far = vd === 'near' ? 240 : vd === 'medium' ? 340 : vd === 'far' ? 460 : 620;
          camera.updateProjectionMatrix();
          if (scene.fog instanceof THREE.FogExp2) {
            scene.fog.density =
              vd === 'near' ? 0.0085 : vd === 'medium' ? 0.0062 : vd === 'far' ? 0.0048 : 0.0034;
          }
          const pq = st.particleQuality ?? 'high';
          const activeWeatherCount = pq === 'low' ? 120 : pq === 'medium' ? 280 : MAX_WEATHER;
          weatherGeo.setDrawRange(0, activeWeatherCount);
        }
        const allowShadows =
          !isSoftwareGl && st.shadows && st.graphicsQuality !== 'low';
        renderer.shadowMap.enabled = allowShadows;
        sunLight.castShadow = allowShadows;

        // Day/Night & Seasonal Atmosphere + Sky Dome & Sun Disc
        if (st.dayNightAuto) {
          dayClock = (dayClock + dt * 0.012) % 1;
        } else {
          dayClock = 0.25;
        }
        const sunWave = Math.sin(dayClock * Math.PI * 2); // -1 night .. +1 noon
        const timePhase: 'DAY' | 'DUSK' | 'NIGHT' =
          sunWave > 0.25 ? 'DAY' : sunWave > -0.25 ? 'DUSK' : 'NIGHT';
        const lvlAtmospheric = modeRef.current === 'LEVEL_MATCH' && activeLevelWorld ? activeLevelWorld.levelDef : null;
        const sPal = getSeasonPalette(appliedSeason);
        const dayFactor = THREE.MathUtils.clamp((sunWave + 1) * 0.5, 0.22, 1);
        const skyHex = lvlAtmospheric ? lvlAtmospheric.skyColor : sPal.skyColor;
        const fogHex = lvlAtmospheric ? lvlAtmospheric.fogColor : sPal.fogColor;
        const bgCol = new THREE.Color(skyHex).multiplyScalar(0.48 + dayFactor * 0.34);
        (scene.background as THREE.Color).copy(bgCol);
        skyDome.position.set(playerPos.x, 0, playerPos.z);
        skyDomeMat.color.copy(new THREE.Color('#FFFFFF').multiplyScalar(0.46 + dayFactor * 0.36));
        if (scene.fog instanceof THREE.FogExp2) {
          scene.fog.color.copy(new THREE.Color(fogHex).multiplyScalar(0.48 + dayFactor * 0.34));
        }
        sunLight.color.set(lvlAtmospheric ? lvlAtmospheric.sunColor : sPal.sunColor);
        sunLight.intensity = (lvlAtmospheric ? lvlAtmospheric.sunIntensity : sPal.sunIntensity) * (0.42 + dayFactor * 0.46);
        const sunOffX = Math.cos(dayClock * Math.PI * 2) * 58;
        const sunOffY = 28 + Math.max(0, sunWave) * 48;
        sunLight.position.set(playerPos.x + sunOffX, sunOffY, playerPos.z + 36);
        sunLight.target.position.set(playerPos.x, 0, playerPos.z);
        sunDisc.position.set(playerPos.x + sunOffX * 3.1, sunOffY * 2.2, playerPos.z - 160);
        sunDiscMat.color.set(lvlAtmospheric ? lvlAtmospheric.sunColor : sPal.sunColor);

        // Animate Clouds drifting across sky + Moving City Traffic Vehicles
        if (world.worldGroup.visible && !pausedRef.current) {
          world.updateWorld(elapsed, dt);
        }
        const activeClouds = activeLevelWorld ? activeLevelWorld.cloudsGroup : world.cloudsGroup;
        for (let i = 0; i < activeClouds.children.length; i++) {
          const c = activeClouds.children[i];
          c.position.x += dt * (1.2 + (i % 3) * 0.4);
          if (c.position.x > 130) c.position.x = -130;
        }

        // Update Weather Particle Pool
        const weatherMode = st.weather;
        weatherPoints.visible = weatherMode !== 'CLEAR';
        if (weatherPoints.visible) {
          weatherMat.color.set(
            weatherMode === 'RAIN' ? '#7DD3FC' : weatherMode === 'WIND' ? '#FDE68A' : '#F8FAFC'
          );
          weatherMat.size = weatherMode === 'RAIN' ? 0.25 : 0.42;
          const posAttr = weatherGeo.attributes.position as THREE.BufferAttribute;
          const arr = posAttr.array as Float32Array;
          const weatherLoopMax =
            st.particleQuality === 'low' ? 120 : st.particleQuality === 'medium' ? 280 : MAX_WEATHER;
          for (let i = 0; i < weatherLoopMax; i++) {
            const idx = i * 3;
            arr[idx] += (weatherMode === 'WIND' ? 18 : 1.4) * dt;
            arr[idx + 1] -= (weatherMode === 'RAIN' ? 26 : weatherMode === 'SNOW' ? 5.2 : 2.8) * dt;
            if (arr[idx + 1] < 0) {
              arr[idx + 1] = 38 + Math.random() * 8;
              arr[idx] = playerPos.x + (Math.random() - 0.5) * 84;
              arr[idx + 2] = playerPos.z + (Math.random() - 0.5) * 84;
            }
            if (arr[idx] > playerPos.x + 48) arr[idx] -= 96;
          }
          posAttr.needsUpdate = true;
        }

        // New Year Fireworks
        if (appliedSeason === 'NEW_YEAR' && modeRef.current !== 'BOSS_ARENA') {
          fireworksCooldown -= dt;
          if (fireworksCooldown <= 0) {
            fireworksCooldown = 3.2;
            const anch =
              world.fireworksAnchors[Math.floor(Math.random() * world.fireworksAnchors.length)];
            const colors = ['#F5C451', '#38BDF8', '#FB7185', '#34D399'];
            spawnBurst(
              anch.x,
              anch.y,
              anch.z,
              colors[Math.floor(Math.random() * colors.length)],
              14
            );
          }
        }

        // Update Particle Burst Pool
        let burstAny = false;
        const bPos = burstGeo.attributes.position as THREE.BufferAttribute;
        const bArr = bPos.array as Float32Array;
        for (let i = 0; i < MAX_BURST; i++) {
          if (burstLife[i] > 0) {
            burstAny = true;
            burstLife[i] -= dt;
            const k = i * 3;
            bArr[k] += burstVelocities[k] * dt;
            bArr[k + 1] += burstVelocities[k + 1] * dt;
            bArr[k + 2] += burstVelocities[k + 2] * dt;
            burstVelocities[k + 1] -= 12 * dt;
          } else {
            bArr[i * 3 + 1] = -200;
          }
        }
        if (burstAny) bPos.needsUpdate = true;

        // Flush imperative queued UI/button actions
        while (actionQueueRef.current.length > 0) {
          const fn = actionQueueRef.current.shift();
          if (fn) fn();
        }

        if (modeRef.current === 'MENU_IDLE') {
          // Showcase Idle Spider looking down the illuminated metropolis
          spider.root.position.set(0, 0, 12);
          spider.root.rotation.y = Math.sin(elapsed * 0.35) * 0.28;
          spider.animate('idle', elapsed, dt, 0, false, false);

          const orbitYaw = Math.sin(elapsed * 0.16) * 0.42;
          camera.position.set(Math.sin(orbitYaw) * 6.2, 3.0, 12 + Math.cos(orbitYaw) * 6.2);
          camera.lookAt(0, 2.75, -8);
        } else if (!pausedRef.current) {
          // Cooldowns & timers
          if (dashCooldown > 0) dashCooldown = Math.max(0, dashCooldown - dt);
          if (strikeCooldown > 0) strikeCooldown = Math.max(0, strikeCooldown - dt);
          if (trapCooldown > 0) trapCooldown = Math.max(0, trapCooldown - dt);
          if (shieldCooldown > 0) shieldCooldown = Math.max(0, shieldCooldown - dt);
          if (shadowCooldown > 0) shadowCooldown = Math.max(0, shadowCooldown - dt);
          if (ultCooldown > 0) ultCooldown = Math.max(0, ultCooldown - dt);
          if (shieldTimer > 0) shieldTimer = Math.max(0, shieldTimer - dt);
          if (shadowTimer > 0) shadowTimer = Math.max(0, shadowTimer - dt);
          if (ultTimer > 0) ultTimer = Math.max(0, ultTimer - dt);
          if (invulnTimer > 0) invulnTimer = Math.max(0, invulnTimer - dt);
          if (landTimer > 0) landTimer = Math.max(0, landTimer - dt);
          if (fightTimer > 0) fightTimer = Math.max(0, fightTimer - dt);
          if (dodgeTimer > 0) dodgeTimer = Math.max(0, dodgeTimer - dt);
          if (skillAnimTimer > 0) skillAnimTimer = Math.max(0, skillAnimTimer - dt);
          if (entranceTimer > 0) entranceTimer = Math.max(0, entranceTimer - dt);
          if (victoryTimer > 0) victoryTimer = Math.max(0, victoryTimer - dt);
          if (bannerTimer > 0) {
            bannerTimer -= dt;
            if (bannerTimer <= 0) bannerText = null;
          }
          if (trapTimer > 0) {
            trapTimer -= dt;
            trapRing.rotation.z += dt * 3;
            if (trapTimer <= 0) trapRing.visible = false;
          }
          if (venomShockTimer > 0) {
            venomShockTimer -= dt;
            const prog = 1 - Math.max(0, venomShockTimer / 0.45);
            venomShockRing.scale.setScalar(0.8 + prog * 7.2);
            venomShockMat.opacity = Math.max(0, 0.92 * (1 - prog));
            if (venomShockTimer <= 0) venomShockRing.visible = false;
          }
          if (venomDashTrailTimer > 0) venomDashTrailTimer = Math.max(0, venomDashTrailTimer - dt);

          if (airLaunchTimer > 0) airLaunchTimer = Math.max(0, airLaunchTimer - dt);

          // Camera keyboard turn with ArrowLeft/ArrowRight
          if (keys.has('ArrowLeft')) camYaw += 1.9 * dt;
          if (keys.has('ArrowRight')) camYaw -= 1.9 * dt;

          // Movement input vector relative to camera yaw (using customizable keybindings)
          let inF = 0;
          let inR = 0;
          if (keys.has(kb.forward) || keys.has('ArrowUp')) inF += 1;
          if (keys.has(kb.backward) || keys.has('ArrowDown')) inF -= 1;
          if (keys.has(kb.right)) inR += 1;
          if (keys.has(kb.left)) inR -= 1;

          const fX = -Math.sin(camYaw);
          const fZ = -Math.cos(camYaw);
          const rX = Math.cos(camYaw);
          const rZ = -Math.sin(camYaw);

          let wishX = fX * inF + rX * inR;
          let wishZ = fZ * inF + rZ * inR;
          const wLen = Math.hypot(wishX, wishZ);
          if (wLen > 0.001) {
            wishX /= wLen;
            wishZ /= wLen;
          }

          const skinData = SKIN_BY_ID[curSave.equippedSkinId];
          const speedSkill = curSave.skillLevels.spider_speed || 0;
          const isSprinting = keys.has(kb.sprint) || keys.has('ShiftRight');
          const baseSpeed =
            (isSprinting ? 17.5 : 11.2) *
            (1 + (skinData?.speedBonus || 0) + speedSkill * 0.07) *
            (shadowTimer > 0 ? 1.35 : 1) *
            (ultTimer > 0 ? 1.25 : 1);

          // Advance dynamic level obstacles BEFORE collision resolution so platforms carry delta cleanly
          if (modeRef.current === 'LEVEL_MATCH' && activeLevelWorld && !portalTriggered) {
            activeLevelWorld.updateDynamicObjects(elapsed, dt);
            activeLevelWorld.portal.animate(elapsed, dt, false);
          }

          const curColliders = activeLevelWorld ? activeLevelWorld.colliders : world.colliders;
          const curRaycastTargets = activeLevelWorld ? activeLevelWorld.raycastTargets : world.raycastTargets;
          const curGroundYAt = activeLevelWorld ? activeLevelWorld.groundYAt : world.groundYAt;

          // Advance Web Projectile Raycast in Flight with Skyscraper Cone Assist
          if (webFlightActive && !portalTriggered) {
            webFlightTimer -= dt;
            const prevP = webProjPos.clone();
            const stepVec = webProjVel.clone().multiplyScalar(dt);
            const stepLen = stepVec.length();
            let attachedPoint: THREE.Vector3 | null = null;
            if (stepLen > 0.001) {
              raycaster.set(prevP, stepVec.clone().normalize());
              raycaster.far = stepLen + 1.5;
              const hits = raycaster.intersectObjects(curRaycastTargets, false);
              const elevatedHit = hits.find(
                (h) => h.distance >= 0.4 && h.point.y >= Math.max(2.2, playerPos.y - 2.5)
              );
              if (elevatedHit) {
                attachedPoint = elevatedHit.point;
              } else {
                webProjPos.add(stepVec);
                if (webFlightTimer <= 0.74) {
                  const assist = findSkyscraperWebAnchor(
                    webStartOrigin,
                    webAimDir,
                    curColliders,
                    95
                  );
                  if (assist) {
                    attachedPoint = new THREE.Vector3(assist.x, assist.y, assist.z);
                  }
                }
              }
            }
            if (attachedPoint) {
              webAnchorPos.copy(attachedPoint);
              webFlightActive = false;
              webAttached = true;
              webRopeLength = Math.max(
                4.5,
                Math.min(
                  48,
                  webAnchorPos.distanceTo(tmpStart.set(playerPos.x, playerPos.y + 1.2, playerPos.z))
                )
              );
              webAnchorNode.position.copy(webAnchorPos);
              webAnchorNode.visible = true;
              const webDef = WEB_BY_ID[curSave.equippedWebId];
              audio3d.playWebAttach(webDef?.soundPitch || 1);
              spawnBurst(
                webAnchorPos.x,
                webAnchorPos.y,
                webAnchorPos.z,
                webDef?.particleColor || '#38BDF8',
                8
              );
              // Immediate swing lift & momentum nudge
              playerVel.y = Math.max(playerVel.y, 4.8);
            } else if (webFlightTimer <= 0 && webFlightActive) {
              webFlightActive = false;
              webCylinder.visible = false;
            }
          }

          const isPulling = keys.has(kb.interact) || manualPullRef.current;
          const prevGrounded = grounded;
          let standingColId: string | null = null;
          let onIce = false;

          if (portalTriggered && activeLevelWorld) {
            // Cinematic Teleportation Sequence inside Final Portal
            portalWarpTimer -= dt;
            activeLevelWorld.portal.animate(elapsed, dt, true);
            const pPos = activeLevelWorld.levelDef.portalPos;
            playerPos.x = THREE.MathUtils.lerp(playerPos.x, pPos.x, Math.min(1, dt * 6));
            playerPos.y = THREE.MathUtils.lerp(playerPos.y, pPos.y + 1.8, Math.min(1, dt * 5));
            playerPos.z = THREE.MathUtils.lerp(playerPos.z, pPos.z, Math.min(1, dt * 6));
            playerYaw += dt * 11;
            const shrink = Math.max(0.18, portalWarpTimer / 1.35);
            spider.root.scale.setScalar(shrink);
            if (portalWarpTimer <= 0 && !matchFinished) {
              matchFinished = true;
              spider.root.scale.setScalar(1);
              callbacksRef.current.onLevelCompleted(activeLevelWorld.levelDef, {
                orbs: orbsRun,
                enemies: dronesRun,
              });
            }
          } else if (webAttached) {
            const webDef = WEB_BY_ID[curSave.equippedWebId];
            const swingLvl = curSave.skillLevels.fast_swing || 0;
            const boost = (webDef?.pullForce || 1) * (1 + swingLvl * 0.12);
            const stepped = stepWebSwingPhysics(
              playerPos,
              playerVel,
              webAnchorPos,
              webRopeLength,
              { x: wishX, y: 0, z: wishZ },
              isPulling,
              boost,
              dt
            );
            playerVel.x = stepped.vel.x;
            playerVel.y = stepped.vel.y;
            playerVel.z = stepped.vel.z;
            webRopeLength = stepped.ropeLength;

            // Step against colliders safely
            const resolved = resolveCityCollision(
              playerPos,
              playerVel,
              0.55,
              2.0,
              curColliders,
              curGroundYAt,
              dt
            );
            playerPos.x = resolved.pos.x;
            playerPos.y = resolved.pos.y;
            playerPos.z = resolved.pos.z;
            playerVel.x = resolved.vel.x;
            playerVel.y = resolved.vel.y;
            playerVel.z = resolved.vel.z;
            grounded = resolved.grounded;
            touchingWall = resolved.touchingClimbableWall;
            standingColId = resolved.standingColliderId;
            onIce = resolved.onSlipperySurface;
            if (grounded && !isPulling && playerPos.y >= webAnchorPos.y - 1.0) {
              // Auto-detach cleanly once perched near anchor rooftop
              webAttached = false;
              webAnchorNode.visible = false;
              webCylinder.visible = false;
            }
          } else {
            if (grounded) {
              airLaunchTimer = 0;
              const accel = onIce ? 2.8 : 14;
              playerVel.x = THREE.MathUtils.lerp(
                playerVel.x,
                wLen > 0.01 ? wishX * baseSpeed : 0,
                Math.min(1, accel * dt)
              );
              playerVel.z = THREE.MathUtils.lerp(
                playerVel.z,
                wLen > 0.01 ? wishZ * baseSpeed : 0,
                Math.min(1, accel * dt)
              );
              playerVel.y -= 28 * dt;
            } else {
              const wallClimbLvl = curSave.skillLevels.wall_climb || 1;
              if (touchingWall && (keys.has(kb.forward) || keys.has('ArrowUp'))) {
                const climbBoost = baseSpeed * 0.7;
                playerVel.x = THREE.MathUtils.lerp(playerVel.x, wishX * climbBoost, Math.min(1, 8 * dt));
                playerVel.z = THREE.MathUtils.lerp(playerVel.z, wishZ * climbBoost, Math.min(1, 8 * dt));
                playerVel.y = 8.5 + wallClimbLvl * 1.4;
              } else {
                const glideHeld = keys.has(kb.jump);
                const airStepped = stepAirFlightPhysics(
                  playerVel,
                  { x: wishX, y: 0, z: wishZ },
                  wLen,
                  camYaw,
                  baseSpeed,
                  glideHeld,
                  isSprinting,
                  airLaunchTimer > 0,
                  dt
                );
                playerVel.x = airStepped.x;
                playerVel.y = airStepped.y;
                playerVel.z = airStepped.z;
              }
            }

            const prevX = playerPos.x;
            const prevZ = playerPos.z;
            const resolved = resolveCityCollision(
              playerPos,
              playerVel,
              0.55,
              2.0,
              curColliders,
              curGroundYAt,
              dt
            );
            playerPos.x = THREE.MathUtils.clamp(resolved.pos.x, -135, 135);
            playerPos.y = resolved.pos.y;
            playerPos.z = THREE.MathUtils.clamp(resolved.pos.z, -175, 134);
            playerVel.x = resolved.vel.x;
            playerVel.y = resolved.vel.y;
            playerVel.z = resolved.vel.z;
            grounded = resolved.grounded;
            touchingWall = resolved.touchingClimbableWall;
            standingColId = resolved.standingColliderId;
            onIce = resolved.onSlipperySurface;

            const stepDist = Math.hypot(playerPos.x - prevX, playerPos.z - prevZ);
            if (stepDist > 0.005) {
              distAccum += stepDist;
              if (distAccum >= 12) {
                callbacksRef.current.onDistanceStat(Math.floor(distAccum));
                distAccum %= 12;
              }
            }
          }

          if (grounded) {
            jumpsUsed = 0;
            if (!prevGrounded && playerVel.y <= -4) {
              landTimer = 0.22;
              audio3d.playLand();
            }
          }

          // Character facing
          const horizSpd = Math.hypot(playerVel.x, playerVel.z);
          if (horizSpd > 0.6) {
            const targetYaw = Math.atan2(-playerVel.x, -playerVel.z);
            let diff = targetYaw - playerYaw;
            while (diff > Math.PI) diff -= Math.PI * 2;
            while (diff < -Math.PI) diff += Math.PI * 2;
            playerYaw += diff * Math.min(1, dt * 11);
          }

          // Update visible web strand cylinder + animated anchor flare & special web trail colors
          if (webFlightActive || webAttached) {
            const eqWeb = WEB_BY_ID[curSave.equippedWebId];
            const milesNow = isMilesActive();
            if (eqWeb?.trailStyle === 'rainbow') {
              webMat.color.setHSL((elapsed * 0.85) % 1, 0.95, 0.62);
            } else if (eqWeb?.trailStyle === 'cosmic') {
              webMat.color.setHSL((0.72 + Math.sin(elapsed * 4) * 0.08) % 1, 0.9, 0.68);
            } else if (milesNow && eqWeb?.id === 'web_classic') {
              webMat.color.set(Math.sin(elapsed * 22) > 0 ? '#FF2E4D' : '#FB7185');
            }
            if (webAttached) {
              webAnchorNode.scale.setScalar(1.0 + Math.sin(elapsed * 16) * 0.22);
            }
            tmpStart.set(playerPos.x, playerPos.y + 1.42, playerPos.z);
            tmpEnd.copy(webAttached ? webAnchorPos : webProjPos);
            const segLen = tmpStart.distanceTo(tmpEnd);
            if (segLen > 0.1) {
              webCylinder.visible = true;
              webCylinder.position.copy(tmpStart).lerp(tmpEnd, 0.5);
              const pulseThick = webAttached && isPulling ? 1.55 : webAttached ? 1.15 : 1.0;
              webCylinder.scale.set(pulseThick, segLen, pulseThick);
              webCylinder.quaternion.setFromUnitVectors(
                upVec,
                tmpDir.copy(tmpEnd).sub(tmpStart).normalize()
              );
            }
          } else {
            webCylinder.visible = false;
            webAnchorNode.visible = false;
          }

          // Update high-speed wind, flight & Miles Morales red/purple Venom swing streak particles
          const totalSpd = Math.hypot(playerVel.x, playerVel.y, playerVel.z);
          const milesNow = isMilesActive();
          if (
            (webAttached || airLaunchTimer > 0 || venomDashTrailTimer > 0 || totalSpd > 13.5) &&
            st.particleQuality !== 'low' &&
            st.graphicsQuality !== 'low'
          ) {
            const eqWeb = WEB_BY_ID[curSave.equippedWebId];
            streakMat.color.set(
              milesNow
                ? Math.sin(elapsed * 26) > 0
                  ? '#FF2E4D'
                  : '#A855F7'
                : eqWeb?.trailStyle === 'rainbow'
                  ? new THREE.Color().setHSL((elapsed * 1.1) % 1, 0.95, 0.65)
                  : eqWeb?.particleColor || '#7DD3FC'
            );
            streakMat.opacity = Math.min(
              0.92,
              Math.max(
                0.32,
                (totalSpd - 9) * 0.055 + (webAttached || airLaunchTimer > 0 || venomDashTrailTimer > 0 ? 0.34 : 0)
              )
            );
            const emitCount = airLaunchTimer > 0 || venomDashTrailTimer > 0 ? 2 : 1;
            for (let e = 0; e < emitCount; e++) {
              const sIdx = (streakCursor % MAX_STREAK) * 3;
              streakPositions[sIdx] = playerPos.x + (Math.random() - 0.5) * 1.25;
              streakPositions[sIdx + 1] = playerPos.y + 0.5 + Math.random() * 1.4;
              streakPositions[sIdx + 2] = playerPos.z + (Math.random() - 0.5) * 1.25;
              streakCursor++;
            }
            streakGeo.attributes.position.needsUpdate = true;
          } else if (streakMat.opacity > 0.01) {
            streakMat.opacity = Math.max(0, streakMat.opacity - dt * 2.5);
          }

          // 10-Level Adventure: Moving Platforms, Collapsing Platforms, Wind, Hazards, Enemies, Orbs, & Physical Portal
          if (modeRef.current === 'LEVEL_MATCH' && activeLevelWorld && !portalTriggered && !matchFinished) {
            const lvl = activeLevelWorld.levelDef;

            // Carry player smoothly on moving/sliding platforms + trigger collapsing platforms
            for (const obs of activeLevelWorld.obstacles) {
              if (standingColId && obs.collider && obs.collider.id === standingColId) {
                playerPos.x += obs.deltaX;
                playerPos.y += obs.deltaY;
                playerPos.z += obs.deltaZ;
                if (obs.spec.kind === 'collapsing_platform' && obs.collapseTimer <= 0 && obs.respawnTimer <= 0) {
                  obs.collapseTimer = 0.65;
                  audio3d.playPlatformCollapse();
                  setBanner('PLATFORM COLLAPSING — JUMP!', 1.0);
                }
              }

              // Wind zone drift
              if (obs.spec.kind === 'wind_zone') {
                const s = obs.spec;
                if (
                  Math.abs(playerPos.x - s.x) < s.w * 0.5 &&
                  Math.abs(playerPos.y - s.y) < s.h * 0.5 &&
                  Math.abs(playerPos.z - s.z) < s.d * 0.5
                ) {
                  const wx = lvl.windForce?.x ?? 5.5;
                  const wz = lvl.windForce?.z ?? 0;
                  playerVel.x += wx * dt;
                  playerVel.z += wz * dt;
                }
              }

              // Lethal hazard AABB overlap check
              if (obs.spec.lethal && obs.activeDangerBox && invulnTimer <= 0) {
                const db = obs.activeDangerBox;
                const hitX = Math.abs(playerPos.x - db.x) < db.w * 0.5 + 0.42;
                const hitY = playerPos.y + 1.85 > db.y - db.h * 0.5 && playerPos.y < db.y + db.h * 0.5;
                const hitZ = Math.abs(playerPos.z - db.z) < db.d * 0.5 + 0.42;
                if (hitX && hitY && hitZ) {
                  if (shieldTimer > 0 || shadowTimer > 0) {
                    invulnTimer = 0.7;
                    setBanner('HAZARD DEFLECTED BY SHIELD / CLOAK!', 1.1);
                  } else {
                    hp = Math.max(0, hp - 55);
                    invulnTimer = 0.95;
                    playerVel.y = 7.5;
                    audio3d.playHazardHit();
                    spawnBurst(playerPos.x, playerPos.y + 1.0, playerPos.z, '#EF4444', 14);
                    if (hp <= 0) {
                      matchFinished = true;
                      callbacksRef.current.onPlayerDefeat(false, 'Struck by a deadly obstacle hazard!');
                    } else {
                      setBanner('HAZARD HIT! -55 HP', 1.2);
                    }
                  }
                }
              }
            }

            // Void pit fall -> Game Over
            if (lvl.hasVoidPit && playerPos.y < -14) {
              hp = 0;
              matchFinished = true;
              audio3d.playHazardHit();
              callbacksRef.current.onPlayerDefeat(false, 'Fell into the abyss below!');
            }

            // Level collectible orbs & gems
            for (const col of activeLevelWorld.orbs) {
              if (col.collected) continue;
              col.mesh.rotation.y += dt * 2.4;
              col.mesh.position.y = col.baseY + Math.sin(elapsed * 3.1 + col.mesh.position.x) * 0.22;
              const dCol = Math.hypot(
                col.mesh.position.x - playerPos.x,
                col.mesh.position.y - (playerPos.y + 1.0),
                col.mesh.position.z - playerPos.z
              );
              if (dCol < 2.4) {
                col.collected = true;
                col.mesh.visible = false;
                orbsRun += 1;
                audio3d.playPickup();
                spawnBurst(col.mesh.position.x, col.mesh.position.y, col.mesh.position.z, lvl.accentColor, 8);
                callbacksRef.current.onCollectOrb(col.kind);
              }
            }

            // 6 Enemy types AI (Patrol + Aggro Chase + Contact Damage)
            for (const en of activeLevelWorld.enemies) {
              if (!en.alive) {
                en.koTimer -= dt;
                if (en.koTimer <= 0) {
                  en.alive = true;
                  en.hp = en.maxHp;
                  en.rig.group.visible = true;
                  en.rig.group.position.copy(en.origin);
                }
                continue;
              }
              if (en.attackCooldown > 0) en.attackCooldown -= dt;
              const ex = en.rig.group.position.x;
              const ez = en.rig.group.position.z;
              const dx = playerPos.x - ex;
              const dz = playerPos.z - ez;
              const distP = Math.hypot(dx, dz) || 1;
              const trapSlow =
                trapTimer > 0 &&
                Math.hypot(trapRing.position.x - ex, trapRing.position.z - ez) < 4.5
                  ? 0.25
                  : 1.0;

              const aggroVisible = distP < 16 && shadowTimer <= 0;
              if (aggroVisible) {
                en.rig.group.position.x += (dx / distP) * en.speed * trapSlow * dt;
                en.rig.group.position.z += (dz / distP) * en.speed * trapSlow * dt;
                en.rig.group.rotation.y = Math.atan2(dx, dz);
              } else {
                const patAng = elapsed * 0.9 + en.origin.z;
                en.rig.group.position.x = en.origin.x + Math.sin(patAng) * Math.min(3.5, en.patrolRadius * 0.5);
                en.rig.group.position.z = en.origin.z + Math.cos(patAng) * Math.min(3.5, en.patrolRadius * 0.5);
                en.rig.group.rotation.y = patAng;
              }
              en.rig.animate(elapsed, dt, aggroVisible);

              if (
                distP < 1.85 &&
                Math.abs(playerPos.y - en.rig.group.position.y) < 2.6 &&
                en.attackCooldown <= 0 &&
                invulnTimer <= 0
              ) {
                en.attackCooldown = 1.4;
                if (shieldTimer > 0 || shadowTimer > 0) {
                  setBanner('ENEMY STRIKE BLOCKED!', 1.0);
                } else {
                  hp = Math.max(0, hp - en.damage);
                  invulnTimer = 0.7;
                  audio3d.playHurt();
                  if (hp <= 0) {
                    matchFinished = true;
                    callbacksRef.current.onPlayerDefeat(false, 'Overrun by enemy forces!');
                  }
                }
              }
            }

            // Physical Collision with Final Animated Portal
            if (checkPortalTrigger(playerPos, lvl.portalPos, 3.6)) {
              portalTriggered = true;
              portalWarpTimer = 1.35;
              webAttached = false;
              webFlightActive = false;
              webCylinder.visible = false;
              webAnchorNode.visible = false;
              audio3d.playPortalTeleport();
              spawnBurst(lvl.portalPos.x, lvl.portalPos.y + 2.2, lvl.portalPos.z, lvl.portalGlowColor, 20);
              setBanner('PORTAL ENTERED — TELEPORTING TO NEXT STAGE!', 1.6);
            }
          }

          // Collectibles & Secret Cave Detection (City Match)
          if (modeRef.current === 'CITY_MATCH') {
            if (!secretFound) {
              const dSec = Math.hypot(
                playerPos.x - world.secretZoneCenter.x,
                playerPos.z - world.secretZoneCenter.z
              );
              if (dSec < 8.5) {
                secretFound = true;
                setBanner('SECRET MOUNTAIN CAVERN DISCOVERED! +GEMS', 3.0);
                callbacksRef.current.onCollectOrb('secret');
              }
            }

            for (const col of world.collectibles) {
              if (col.collected) continue;
              col.mesh.rotation.y += dt * 2.2;
              col.mesh.position.y = col.baseY + Math.sin(elapsed * 3 + col.mesh.position.x) * 0.25;
              const dCol = Math.hypot(
                col.mesh.position.x - playerPos.x,
                col.mesh.position.y - (playerPos.y + 1.0),
                col.mesh.position.z - playerPos.z
              );
              if (dCol < 2.35) {
                col.collected = true;
                col.mesh.visible = false;
                orbsRun += 1;
                audio3d.playPickup();
                spawnBurst(
                  col.mesh.position.x,
                  col.mesh.position.y,
                  col.mesh.position.z,
                  col.kind === 'orb' ? '#38BDF8' : '#F5C451',
                  8
                );
                callbacksRef.current.onCollectOrb(col.kind);
                setBanner(
                  col.kind === 'secret'
                    ? 'SECRET VAULT CRYSTAL CLAIMED!'
                    : `ENERGY COLLECTED (${orbsRun + dronesRun}/${matchTarget})`,
                  1.6
                );
              }
            }

            // Drone Patrol AI (City Match)
            for (const dr of world.drones) {
              if (!dr.alive) {
                dr.koTimer -= dt;
                if (dr.koTimer <= 0) {
                  dr.alive = true;
                  dr.hp = dr.maxHp;
                  dr.group.visible = true;
                }
                continue;
              }
              const t = elapsed + dr.phaseOffset;
              dr.group.position.x = dr.origin.x + Math.sin(t * 0.9) * 6;
              dr.group.position.z = dr.origin.z + Math.cos(t * 0.9) * 6;
              dr.group.position.y = dr.origin.y + Math.sin(t * 2.6) * 0.35;
              dr.group.rotation.y += dt * 1.4;
            }
          }

          // Match Victory Threshold Check (City Match)
          if (
            modeRef.current === 'CITY_MATCH' &&
            !matchFinished &&
            orbsRun + dronesRun >= matchTarget
          ) {
            matchFinished = true;
            victoryTimer = 2.4;
            audio3d.playVictory();
            const earnedCoins = 260 + orbsRun * 35 + dronesRun * 55;
            const earnedXp = 220 + orbsRun * 25 + dronesRun * 40;
            callbacksRef.current.onMatchVictory({
              orbs: orbsRun,
              drones: dronesRun,
              coins: earnedCoins,
              xp: earnedXp,
            });
          }

          // Boss Arena AI & Telegraphed Shockwave Attacks
          if (modeRef.current === 'BOSS_ARENA' && activeBossRig && bossRef.current) {
            const bDef = bossRef.current;
            if (!bossDefeatedFlag && !matchFinished) {
              const bx = activeBossRig.root.position.x;
              const bz = activeBossRig.root.position.z;
              const dx = playerPos.x - bx;
              const dz = playerPos.z - bz;
              const dist = Math.hypot(dx, dz) || 1;
              const trapSlow =
                trapTimer > 0 &&
                Math.hypot(trapRing.position.x - bx, trapRing.position.z - bz) < 4.5
                  ? 0.35
                  : 1.0;

              if (bossTelegraphTimer <= 0 && dist > 4.2) {
                activeBossRig.root.position.x += (dx / dist) * bDef.speed * trapSlow * dt;
                activeBossRig.root.position.z += (dz / dist) * bDef.speed * trapSlow * dt;
              }
              activeBossRig.root.rotation.y = Math.atan2(-dx, -dz);

              if (bossTelegraphTimer > 0) {
                bossTelegraphTimer -= dt;
                bossAttackRing.visible = true;
                bossAttackRing.position.set(bx, 0.9, bz);
                const pulse = 1 + (0.85 - bossTelegraphTimer) * 1.8;
                bossAttackRing.scale.setScalar(pulse);
                if (bossTelegraphTimer <= 0) {
                  bossRingExpandTimer = 0.65;
                  bossRingOrigin.set(bx, 0.9, bz);
                  if (dist < 10.5 && playerPos.y < 3.2 && invulnTimer <= 0) {
                    if (shieldTimer > 0 || shadowTimer > 0) {
                      setBanner('ATTACK BLOCKED BY SHIELD / CLOAK!', 1.2);
                    } else {
                      hp = Math.max(0, hp - bDef.attackDamage);
                      invulnTimer = 0.9;
                      audio3d.playHurt();
                      if (hp <= 0) {
                        matchFinished = true;
                        callbacksRef.current.onPlayerDefeat(true);
                      }
                    }
                  }
                }
              } else {
                bossAttackTimer -= dt * trapSlow;
                if (bossAttackTimer <= 0 && dist < 13) {
                  bossTelegraphTimer = 0.85;
                  bossAttackTimer = bDef.attackInterval;
                } else if (bossRingExpandTimer > 0) {
                  bossRingExpandTimer -= dt;
                  bossAttackRing.visible = true;
                  bossAttackRing.position.copy(bossRingOrigin);
                  bossAttackRing.scale.setScalar(2.6 + (0.65 - bossRingExpandTimer) * 8);
                  if (bossRingExpandTimer <= 0) bossAttackRing.visible = false;
                } else {
                  bossAttackRing.visible = false;
                }
              }
            }
            activeBossRig.animate(
              elapsed,
              dt,
              bossTelegraphTimer > 0,
              bossDefeatedFlag
            );
          }

          // Determine Spider Animation State + Aerodynamic Banking
          const glideActiveNow = !grounded && !touchingWall && !webAttached && keys.has(kb.jump);
          const isFlyingNow =
            !grounded &&
            !touchingWall &&
            !webAttached &&
            (airLaunchTimer > 0 || horizSpd > 13.5 || (glideActiveNow && horizSpd > 7));

          if (hp <= 0) animState = 'defeat';
          else if (victoryTimer > 0) animState = 'victory';
          else if (entranceTimer > 0) animState = 'entrance';
          else if (fightTimer > 0) animState = 'fight';
          else if (dodgeTimer > 0) animState = 'dodge';
          else if (skillAnimTimer > 0) animState = 'skill';
          else if (webAttached) animState = 'webSwing';
          else if (webFlightActive) animState = 'webShoot';
          else if (touchingWall && !grounded) animState = 'wallClimb';
          else if (isFlyingNow) animState = 'webFly';
          else if (!grounded) animState = playerVel.y > 0.5 ? (jumpsUsed > 1 ? 'doubleJump' : 'jump') : 'fall';
          else if (landTimer > 0) animState = 'land';
          else if (horizSpd > 13.5) animState = 'sprint';
          else if (horizSpd > 7.5) animState = 'run';
          else if (horizSpd > 0.8) animState = 'walk';
          else animState = 'idle';

          // Compute character turn banking during flight & high-speed swings
          const latVel = playerVel.x * Math.cos(playerYaw) - playerVel.z * Math.sin(playerYaw);
          const targetBank =
            isFlyingNow || webAttached ? THREE.MathUtils.clamp(-latVel * 0.025, -0.42, 0.42) : 0;
          playerBank = THREE.MathUtils.damp(playerBank, targetBank, 8, dt);

          spider.root.position.set(playerPos.x, playerPos.y, playerPos.z);
          spider.root.rotation.y = playerYaw;
          spider.root.rotation.z = playerBank;
          // Project grounded contact shadow to ground height beneath spider
          const belowFloor = curGroundYAt(playerPos.x, playerPos.z);
          const heightAboveFloor = Math.max(0, playerPos.y - belowFloor);
          spider.contactShadow.position.y = -heightAboveFloor + 0.03;
          const shScale = Math.max(0.45, 1.0 - heightAboveFloor * 0.03);
          spider.contactShadow.scale.setScalar(shScale);

          spider.animate(
            animState,
            elapsed,
            dt,
            Math.min(1.4, horizSpd / 16),
            shieldTimer > 0,
            shadowTimer > 0
          );

          // Third-Person Camera with Dynamic Speed FOV, Exponential Damping, Bank Tilt & Pull-In Raycast
          const targetFov = THREE.MathUtils.clamp(
            58 + Math.max(0, horizSpd - 10) * 0.85 + (webAttached ? 4.5 : isFlyingNow ? 6.5 : 0),
            58,
            78
          );
          const nextFov = THREE.MathUtils.damp(camera.fov, targetFov, 5.5, dt);
          if (Math.abs(nextFov - camera.fov) > 0.05) {
            camera.fov = nextFov;
            camera.updateProjectionMatrix();
          }

          const camDist = isFlyingNow || webAttached ? 10.2 : 9.2;
          const camHeight = isFlyingNow ? 3.2 : 3.6;
          tmpLookAt.set(
            playerPos.x + playerVel.x * 0.045,
            playerPos.y + 1.65,
            playerPos.z + playerVel.z * 0.045
          );
          const offX = Math.sin(camYaw) * Math.cos(camPitch) * camDist;
          const offY = Math.sin(camPitch) * camDist + camHeight * 0.45;
          const offZ = Math.cos(camYaw) * Math.cos(camPitch) * camDist;
          tmpCamPos.set(tmpLookAt.x + offX, Math.max(0.8, tmpLookAt.y + offY), tmpLookAt.z + offZ);

          tmpOrigin.copy(tmpLookAt);
          tmpDir.copy(tmpCamPos).sub(tmpOrigin);
          const desiredDist = tmpDir.length();
          if (desiredDist > 0.1) {
            raycaster.set(tmpOrigin, tmpDir.normalize());
            raycaster.far = desiredDist;
            const camHits = raycaster.intersectObjects(curRaycastTargets, false);
            if (camHits.length > 0 && camHits[0].distance < desiredDist - 0.6) {
              const safeDist = Math.max(2.6, camHits[0].distance - 0.5);
              tmpCamPos.copy(tmpOrigin).addScaledVector(tmpDir, safeDist);
            }
          }
          camera.position.lerp(tmpCamPos, 1 - Math.exp(-10 * dt));
          camera.lookAt(tmpLookAt);
          camBank = THREE.MathUtils.damp(camBank, playerBank * 0.18, 6, dt);
          camera.rotateZ(camBank);
        }

        if (!contextLost) {
          const skip60Cap =
            !isSoftwareGl &&
            st.fpsMode === '60' &&
            nowMs - lastRenderMs < 15.8;
          if (!skip60Cap) {
            lastRenderMs = nowMs;
            const useBloom =
              !isSoftwareGl &&
              composer !== null &&
              (st.bloom ?? true) &&
              st.graphicsQuality !== 'low';
            if (useBloom && composer) {
              composer.render();
            } else {
              renderer.render(scene, camera);
            }
            fpsFrames += 1;
          }
        }

        const fpsElapsed = nowMs - fpsWindowStart;
        if (fpsElapsed >= 500) {
          measuredFps = Math.max(1, Math.round((fpsFrames * 1000) / fpsElapsed));
          fpsFrames = 0;
          fpsWindowStart = nowMs;
        }

        // Throttled HUD Snapshot (max ~12Hz)
        if (nowMs - lastHudPush > 82) {
          lastHudPush = nowMs;
          const activeLvlDef = modeRef.current === 'LEVEL_MATCH' ? levelRef.current : null;
          const portalDist = activeLvlDef
            ? Math.round(
                Math.hypot(
                  activeLvlDef.portalPos.x - playerPos.x,
                  activeLvlDef.portalPos.z - playerPos.z
                )
              )
            : null;
          const pullingNow = keys.has(curSave.settings.keyBindings?.interact || 'KeyE') || manualPullRef.current;
          const hSpeed = Math.hypot(playerVel.x, playerVel.z);
          const glideHudActive = !grounded && !touchingWall && !webAttached && keys.has(kb.jump);
          const flyingHudNow =
            !grounded &&
            !touchingWall &&
            !webAttached &&
            (airLaunchTimer > 0 || hSpeed > 13.5 || (glideHudActive && hSpeed > 7));
          const movementStyle = portalTriggered
            ? 'PORTAL WARP'
            : webAttached && pullingNow
              ? 'WEB PULLING'
              : webAttached && hSpeed > 18
                ? 'HIGH-SPEED SWING'
                : webAttached
                  ? 'WEB SWINGING'
                  : flyingHudNow && glideHudActive
                    ? 'WEB-WINGS GLIDE'
                    : flyingHudNow
                      ? 'SPIDER FLIGHT'
                      : touchingWall && !grounded
                        ? 'WALL CLIMB'
                        : grounded && hSpeed > 13.5
                          ? 'SPRINTING'
                          : 'GROUNDED';
          callbacksRef.current.onHudUpdate({
            hp,
            maxHp,
            shieldTimer,
            shadowTimer,
            ultTimer,
            dashCooldown,
            strikeCooldown,
            trapCooldown,
            shieldCooldown,
            shadowCooldown,
            ultCooldown,
            webAttached,
            webPulling: pullingNow,
            activeDirection: dirRef.current,
            matchScore: orbsRun + dronesRun,
            matchTarget,
            orbsRun,
            dronesRun,
            bossHp,
            bossMaxHp,
            bossTelegraph: bossTelegraphTimer > 0,
            timePhase,
            secretFound,
            animState,
            movementStyle,
            isFlying: flyingHudNow,
            altitude: Math.max(0, Math.round(playerPos.y)),
            speedKmh: Math.round(hSpeed * 3.6),
            bannerText,
            levelId: activeLvlDef ? activeLvlDef.id : null,
            levelName: activeLvlDef ? activeLvlDef.name : null,
            portalDistance: portalDist,
            warpingPortal: portalTriggered,
            fps: measuredFps,
          });
        }

        afterDraw(tick);
      };

      requestAnimationFrame(tick);

      return () => {
        running = false;
        renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
        renderer.domElement.removeEventListener('webglcontextrestored', onContextRestored);
        window.removeEventListener('keydown', onKeyDown);
        window.removeEventListener('keyup', onKeyUp);
        window.removeEventListener('pointerdown', onPointerDown);
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        window.removeEventListener('contextmenu', onContextMenu);
        window.removeEventListener('resize', onResize);
        if (activeLevelWorld) activeLevelWorld.dispose();
        world.dispose();
        textures.dispose();
        skyTex.dispose();
        skyDomeGeo.dispose();
        skyDomeMat.dispose();
        sunDiscGeo.dispose();
        sunDiscMat.dispose();
        envRT.dispose();
        webMat.dispose();
        weatherGeo.dispose();
        weatherMat.dispose();
        burstGeo.dispose();
        burstMat.dispose();
        streakGeo.dispose();
        streakMat.dispose();
        sparkTex.dispose();
        venomShockGeo.dispose();
        venomShockMat.dispose();
        if (bloomPass) bloomPass.dispose();
        if (composer) composer.dispose();
        renderer.dispose();
        if (renderer.domElement.parentNode === container) {
          container.removeChild(renderer.domElement);
        }
      };
    }, []);

    return (
      <div
        ref={mountRef}
        className="fixed inset-0 z-0 overflow-hidden bg-[#060912] select-none"
        data-testid="spider-world-3d-canvas"
      />
    );
  }
);
