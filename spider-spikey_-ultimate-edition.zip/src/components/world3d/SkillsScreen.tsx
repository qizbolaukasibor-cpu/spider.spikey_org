import React from 'react';
import { ArrowLeft, ArrowUpCircle, Coins, Gem, Lock, Shield } from 'lucide-react';
import { SKILL_CATALOG } from '../../data/world3dCatalog';
import { PlayerSaveData, SkillId } from '../../types/spider3d';

interface SkillsScreenProps {
  save: PlayerSaveData;
  onBack: () => void;
  onUpgradeSkill: (id: SkillId) => void;
}

export const SkillsScreen: React.FC<SkillsScreenProps> = ({ save, onBack, onUpgradeSkill }) => {
  return (
    <div className="fixed inset-0 z-30 bg-[#070B14] overflow-y-auto p-4 sm:p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> MENU
            </button>
            <div>
              <h1 className="font-display text-2xl font-extrabold text-white">
                SPIDER ABILITY &amp; SKILL TREE (15 SKILLS)
              </h1>
              <p className="text-xs text-slate-400 font-mono-num">
                Player Level: {save.level} · Coins: {save.coins.toLocaleString()} · Gems: {save.gems}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {SKILL_CATALOG.map((sk) => {
            const curLvl = save.skillLevels[sk.id] || 0;
            const maxed = curLvl >= sk.maxLevel;
            const levelLocked = save.level < sk.unlockLevel;
            const nextCoinCost = Math.round(sk.coinCost * (1 + curLvl * 0.65));
            const nextGemCost = Math.round(sk.gemCost * (1 + curLvl * 0.5));
            const canAfford = save.coins >= nextCoinCost && save.gems >= nextGemCost;

            return (
              <div
                key={sk.id}
                className="p-4 rounded-2xl bg-[#0B1120] border border-slate-800 flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className="px-2 py-0.5 rounded text-[11px] font-mono-num font-bold bg-slate-900 border"
                      style={{ color: sk.color, borderColor: sk.color }}
                    >
                      {sk.keyHint}
                    </span>
                    <span className="text-xs font-mono-num text-slate-400">
                      {sk.cooldownSec > 0 ? `CD: ${sk.cooldownSec}s` : 'PASSIVE / INSTANT'}
                    </span>
                  </div>

                  <h2 className="mt-2 font-display text-lg font-bold text-white flex items-center gap-2">
                    <Shield className="w-4 h-4" style={{ color: sk.color }} />
                    {sk.name}
                  </h2>
                  <p className="mt-1 text-xs text-slate-300 leading-relaxed">{sk.description}</p>

                  {/* Rank Pips */}
                  <div className="mt-3 flex items-center gap-1.5">
                    {Array.from({ length: sk.maxLevel }).map((_, i) => (
                      <div
                        key={i}
                        className={`h-2 flex-1 rounded-full ${
                          i < curLvl ? 'bg-emerald-400' : 'bg-slate-800'
                        }`}
                      />
                    ))}
                    <span className="text-xs font-mono-num text-slate-300 ml-1">
                      Lv.{curLvl}/{sk.maxLevel}
                    </span>
                  </div>
                </div>

                <div>
                  {maxed ? (
                    <div className="w-full py-2 rounded-xl bg-emerald-500/20 border border-emerald-400/50 text-emerald-300 text-xs font-bold text-center">
                      MAX RANK MASTERED
                    </div>
                  ) : levelLocked ? (
                    <div className="w-full py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 text-xs font-bold flex items-center justify-center gap-1.5">
                      <Lock className="w-3.5 h-3.5" /> REQUIRES LEVEL {sk.unlockLevel}
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onUpgradeSkill(sk.id)}
                      disabled={!canAfford}
                      data-testid={`upgrade-skill-${sk.id}`}
                      className={`w-full py-2 rounded-xl text-xs font-mono-num font-bold flex items-center justify-center gap-2 cursor-pointer ${
                        canAfford
                          ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      <ArrowUpCircle className="w-4 h-4" />
                      <span>UPGRADE</span>
                      <span className="flex items-center gap-0.5">
                        <Coins className="w-3 h-3" /> {nextCoinCost.toLocaleString()}
                      </span>
                      {nextGemCost > 0 && (
                        <span className="flex items-center gap-0.5">
                          <Gem className="w-3 h-3" /> {nextGemCost}
                        </span>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
