import React, { useMemo, useState } from 'react';
import { ArrowLeft, CheckCircle2, Coins, Clock, Gem, ShoppingBag, Sparkles } from 'lucide-react';
import {
  CASE_CATALOG,
  RARITY_CONFIG,
  SKIN_BY_ID,
  SKIN_CATALOG,
  WEB_BY_ID,
  WEB_CATALOG,
} from '../../data/world3dCatalog';
import { PlayerSaveData } from '../../types/spider3d';
import { getRotatingShopOfferIds } from '../../utils/spider3dStorage';

interface ShopScreenProps {
  save: PlayerSaveData;
  onBack: () => void;
  onBuySkin: (id: string) => void;
  onBuyWeb: (id: string) => void;
  onBuyCase: (id: string) => void;
  onUnlockPremiumPass: () => void;
  onGoSkills: () => void;
  onGoCases: () => void;
}

type ShopCategory = 'FEATURED' | 'SKINS' | 'WEBS' | 'CASES' | 'SEASONAL' | 'EXCLUSIVE';

export const ShopScreen: React.FC<ShopScreenProps> = ({
  save,
  onBack,
  onBuySkin,
  onBuyWeb,
  onBuyCase,
  onUnlockPremiumPass,
  onGoSkills,
  onGoCases,
}) => {
  const [cat, setCat] = useState<ShopCategory>('FEATURED');
  const [notice, setNotice] = useState<string | null>(null);

  const rotating = useMemo(() => getRotatingShopOfferIds(), []);
  const dailySkin = SKIN_BY_ID[rotating.dailySkinId];
  const weeklyWeb = WEB_BY_ID[rotating.weeklyWebId];

  const triggerNotice = (msg: string) => {
    setNotice(msg);
    window.setTimeout(() => setNotice(null), 2400);
  };

  return (
    <div className="fixed inset-0 z-30 bg-[#070B14] overflow-y-auto p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> MENU
            </button>
            <div>
              <h1 className="font-display text-2xl font-extrabold text-white flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-amber-400" /> SPIDER METROPOLIS MARKETPLACE
              </h1>
              <p className="text-xs text-slate-400">
                High-value Mythic, Secret &amp; Exclusive suits, elemental webs, and supply vaults.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 font-mono-num text-sm font-bold">
            <span className="px-3 py-1.5 rounded-xl bg-slate-900 border border-amber-500/40 text-amber-300 flex items-center gap-1.5">
              <Coins className="w-4 h-4" /> {save.coins.toLocaleString()}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 flex items-center gap-1.5">
              <Gem className="w-4 h-4" /> {save.gems.toLocaleString()}
            </span>
          </div>
        </div>

        {notice && (
          <div className="mt-4 px-4 py-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/50 text-emerald-200 text-sm font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" /> {notice}
          </div>
        )}

        {/* Category Tabs */}
        <div className="mt-4 flex flex-wrap items-center gap-2">
          {(['FEATURED', 'SKINS', 'WEBS', 'CASES', 'SEASONAL', 'EXCLUSIVE'] as ShopCategory[]).map(
            (c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCat(c)}
                className={`px-4 py-2 rounded-xl text-xs font-display font-bold cursor-pointer ${
                  cat === c
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-900 border border-slate-700 text-slate-300 hover:text-white'
                }`}
              >
                {c}
              </button>
            )
          )}
          <div className="ml-auto flex items-center gap-2">
            <button
              type="button"
              onClick={onGoCases}
              className="px-4 py-2 rounded-xl bg-pink-500/20 border border-pink-400/40 text-pink-200 text-xs font-bold cursor-pointer"
            >
              OPEN CASES VAULT →
            </button>
            <button
              type="button"
              onClick={onGoSkills}
              className="px-4 py-2 rounded-xl bg-sky-500/20 border border-sky-400/40 text-sky-300 text-xs font-bold cursor-pointer"
            >
              UPGRADE SKILLS →
            </button>
          </div>
        </div>

        {/* Rotating Daily & Weekly Offers */}
        {cat === 'FEATURED' && (
          <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/15 to-slate-900 border border-amber-400/50 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-mono-num text-amber-300">
                  <Clock className="w-3.5 h-3.5" /> DAILY ROTATING OFFER
                </div>
                <h2 className="mt-2 font-display text-xl font-extrabold text-white">
                  {dailySkin?.name}
                </h2>
                <p className="mt-1 text-xs text-slate-300">{dailySkin?.description}</p>
              </div>
              <button
                type="button"
                disabled={!dailySkin || save.ownedSkinIds.includes(dailySkin.id)}
                onClick={() => {
                  if (dailySkin) {
                    onBuySkin(dailySkin.id);
                    triggerNotice(`Purchased ${dailySkin.name}!`);
                  }
                }}
                className="mt-4 w-full py-2.5 rounded-xl bg-amber-400 disabled:bg-slate-800 disabled:text-slate-400 text-slate-950 font-bold text-xs cursor-pointer"
              >
                {dailySkin && save.ownedSkinIds.includes(dailySkin.id)
                  ? 'OWNED'
                  : `BUY · ${dailySkin?.coinPrice.toLocaleString()} COINS`}
              </button>
            </div>

            <div className="p-5 rounded-2xl bg-gradient-to-br from-cyan-500/15 to-slate-900 border border-cyan-400/50 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-mono-num text-cyan-300">
                  <Clock className="w-3.5 h-3.5" /> WEEKLY WEB OFFER
                </div>
                <h2 className="mt-2 font-display text-xl font-extrabold text-white">
                  {weeklyWeb?.name}
                </h2>
                <p className="mt-1 text-xs text-slate-300">{weeklyWeb?.description}</p>
              </div>
              <button
                type="button"
                disabled={!weeklyWeb || save.ownedWebIds.includes(weeklyWeb.id)}
                onClick={() => {
                  if (weeklyWeb) {
                    onBuyWeb(weeklyWeb.id);
                    triggerNotice(`Purchased ${weeklyWeb.name}!`);
                  }
                }}
                className="mt-4 w-full py-2.5 rounded-xl bg-cyan-400 disabled:bg-slate-800 disabled:text-slate-400 text-slate-950 font-bold text-xs cursor-pointer"
              >
                {weeklyWeb && save.ownedWebIds.includes(weeklyWeb.id)
                  ? 'OWNED'
                  : `BUY · ${weeklyWeb?.coinPrice.toLocaleString()} COINS`}
              </button>
            </div>

            <div className="p-5 rounded-2xl bg-gradient-to-br from-purple-500/15 to-slate-900 border border-purple-400/50 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-mono-num text-purple-300">
                  <Sparkles className="w-3.5 h-3.5" /> SEASON PASS PREMIUM
                </div>
                <h2 className="mt-2 font-display text-xl font-extrabold text-white">
                  100-TIER PREMIUM TRACK
                </h2>
                <p className="mt-1 text-xs text-slate-300">
                  Unlock Frost Sentinel, Cosmic Web, Secret Case, and Ultimate Spider Omega.
                </p>
              </div>
              <button
                type="button"
                disabled={save.seasonPremiumUnlocked || save.gems < 180}
                onClick={() => {
                  onUnlockPremiumPass();
                  triggerNotice('Season Pass Premium Unlocked!');
                }}
                className="mt-4 w-full py-2.5 rounded-xl bg-purple-500 disabled:bg-slate-800 disabled:text-slate-400 text-white font-bold text-xs cursor-pointer"
              >
                {save.seasonPremiumUnlocked ? 'PREMIUM ACTIVE' : 'UNLOCK · 180 GEMS'}
              </button>
            </div>
          </div>
        )}

        {/* Catalog Listings */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {(cat === 'CASES' || cat === 'FEATURED') &&
            CASE_CATALOG.map((c) => {
              const afford = save.coins >= c.coinPrice && save.gems >= c.gemPrice;
              const ownedCount = save.casesOwned[c.id] || 0;
              return (
                <div
                  key={c.id}
                  className="p-4 rounded-2xl bg-[#0B1120] border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span
                        className="px-2 py-0.5 rounded text-[10px] font-mono-num font-bold border"
                        style={{
                          color: RARITY_CONFIG[c.rarity].color,
                          borderColor: RARITY_CONFIG[c.rarity].border,
                        }}
                      >
                        CASE · {c.rarity}
                      </span>
                      <span className="text-[11px] font-mono-num text-amber-300 font-bold">
                        OWNED: {ownedCount}
                      </span>
                    </div>
                    <h3 className="mt-2 font-display text-lg font-bold text-white">{c.name}</h3>
                    <p className="mt-1 text-xs text-slate-400">{c.description}</p>
                  </div>
                  <div className="mt-4 flex flex-col gap-2">
                    <button
                      type="button"
                      disabled={!afford}
                      onClick={() => {
                        onBuyCase(c.id);
                        triggerNotice(`Added ${c.name} to Cases inventory.`);
                      }}
                      className={`w-full py-2 rounded-xl text-xs font-mono-num font-bold flex items-center justify-center gap-2 cursor-pointer ${
                        afford ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      <Coins className="w-3.5 h-3.5" /> {c.coinPrice.toLocaleString()}
                      {c.gemPrice > 0 && (
                        <span className="flex items-center gap-0.5">
                          <Gem className="w-3.5 h-3.5" /> {c.gemPrice}
                        </span>
                      )}
                    </button>
                    {ownedCount > 0 && (
                      <button
                        type="button"
                        onClick={onGoCases}
                        className="w-full py-1.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-display font-extrabold text-xs cursor-pointer"
                      >
                        OPEN IN CASES ({ownedCount})
                      </button>
                    )}
                  </div>
                </div>
              );
            })}

          {(cat === 'SKINS' || cat === 'SEASONAL' || cat === 'EXCLUSIVE') &&
            SKIN_CATALOG.filter((s) => {
              if (s.coinPrice === 0) return false;
              if (cat === 'SEASONAL') return s.category === 'Seasonal';
              if (cat === 'EXCLUSIVE')
                return s.rarity === 'MYTHIC' || s.rarity === 'SECRET' || s.rarity === 'EXCLUSIVE';
              return true;
            }).map((sk) => {
              const owned = save.ownedSkinIds.includes(sk.id);
              const afford = save.coins >= sk.coinPrice && save.gems >= sk.gemPrice;
              return (
                <div
                  key={sk.id}
                  className="p-4 rounded-2xl bg-[#0B1120] border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <span
                      className="px-2 py-0.5 rounded text-[10px] font-mono-num font-bold border"
                      style={{
                        color: RARITY_CONFIG[sk.rarity].color,
                        borderColor: RARITY_CONFIG[sk.rarity].border,
                      }}
                    >
                      SUIT · {sk.rarity}
                    </span>
                    <h3 className="mt-2 font-display text-lg font-bold text-white">{sk.name}</h3>
                    <p className="mt-1 text-xs text-slate-400">{sk.description}</p>
                  </div>
                  <button
                    type="button"
                    disabled={owned || !afford}
                    onClick={() => {
                      onBuySkin(sk.id);
                      triggerNotice(`Purchased ${sk.name}!`);
                    }}
                    className={`mt-4 w-full py-2 rounded-xl text-xs font-mono-num font-bold cursor-pointer ${
                      owned
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : afford
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {owned
                      ? 'OWNED'
                      : `${sk.coinPrice.toLocaleString()} COINS${
                          sk.gemPrice > 0 ? ` + ${sk.gemPrice} GEMS` : ''
                        }`}
                  </button>
                </div>
              );
            })}

          {(cat === 'WEBS' || cat === 'EXCLUSIVE') &&
            WEB_CATALOG.filter((w) => {
              if (w.coinPrice === 0) return false;
              if (cat === 'EXCLUSIVE')
                return w.rarity === 'MYTHIC' || w.rarity === 'SECRET' || w.rarity === 'EXCLUSIVE';
              return true;
            }).map((wb) => {
              const owned = save.ownedWebIds.includes(wb.id);
              const afford = save.coins >= wb.coinPrice && save.gems >= wb.gemPrice;
              return (
                <div
                  key={wb.id}
                  className="p-4 rounded-2xl bg-[#0B1120] border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <span
                      className="px-2 py-0.5 rounded text-[10px] font-mono-num font-bold border"
                      style={{
                        color: RARITY_CONFIG[wb.rarity].color,
                        borderColor: RARITY_CONFIG[wb.rarity].border,
                      }}
                    >
                      WEB · {wb.rarity}
                    </span>
                    <h3 className="mt-2 font-display text-lg font-bold text-white">{wb.name}</h3>
                    <p className="mt-1 text-xs text-slate-400">{wb.description}</p>
                  </div>
                  <button
                    type="button"
                    disabled={owned || !afford}
                    onClick={() => {
                      onBuyWeb(wb.id);
                      triggerNotice(`Purchased ${wb.name}!`);
                    }}
                    className={`mt-4 w-full py-2 rounded-xl text-xs font-mono-num font-bold cursor-pointer ${
                      owned
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : afford
                        ? 'bg-cyan-400 text-slate-950'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {owned
                      ? 'OWNED'
                      : `${wb.coinPrice.toLocaleString()} COINS${
                          wb.gemPrice > 0 ? ` + ${wb.gemPrice} GEMS` : ''
                        }`}
                  </button>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};
