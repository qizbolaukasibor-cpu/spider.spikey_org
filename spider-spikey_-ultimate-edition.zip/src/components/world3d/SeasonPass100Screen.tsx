import React, { useState } from 'react';
import { ArrowLeft, Check, Crown, Gem, Lock } from 'lucide-react';
import { SEASON_PASS_100 } from '../../data/world3dCatalog';
import { PlayerSaveData, SeasonPassTier } from '../../types/spider3d';
import { getSeasonPassLevel } from '../../utils/spider3dStorage';

interface SeasonPass100ScreenProps {
  save: PlayerSaveData;
  onBack: () => void;
  onClaimReward: (tier: SeasonPassTier, track: 'free' | 'premium') => void;
  onClaimAll: () => void;
  onUnlockPremium: () => void;
}

export const SeasonPass100Screen: React.FC<SeasonPass100ScreenProps> = ({
  save,
  onBack,
  onClaimReward,
  onClaimAll,
  onUnlockPremium,
}) => {
  const [onlyMilestones, setOnlyMilestones] = useState(false);
  const currentTier = getSeasonPassLevel(save.seasonPassXp);
  const nextTierObj = SEASON_PASS_100[Math.min(99, currentTier)];

  const tiersToShow = onlyMilestones
    ? SEASON_PASS_100.filter((t) => t.isMilestone)
    : SEASON_PASS_100;

  return (
    <div className="fixed inset-0 z-30 bg-[#070B14] overflow-y-auto p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> MENU
            </button>
            <div>
              <h1 className="font-display text-2xl font-extrabold text-white flex items-center gap-2">
                <Crown className="w-5 h-5 text-amber-400" /> SEASON PASS (100 LEVELS)
              </h1>
              <p className="text-xs text-slate-400 font-mono-num">
                Reached Level {currentTier}/100 · Season XP: {save.seasonPassXp.toLocaleString()} /{' '}
                {nextTierObj.xpRequired.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setOnlyMilestones((v) => !v)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold border cursor-pointer ${
                onlyMilestones
                  ? 'bg-sky-500 text-slate-950 border-sky-400'
                  : 'bg-slate-900 border-slate-700 text-slate-300'
              }`}
            >
              {onlyMilestones ? 'SHOWING MILESTONES' : 'ALL 100 LEVELS'}
            </button>
            <button
              type="button"
              onClick={onClaimAll}
              className="px-4 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 text-xs font-bold cursor-pointer"
            >
              CLAIM AVAILABLE
            </button>
            {!save.seasonPremiumUnlocked && (
              <button
                type="button"
                disabled={save.gems < 180}
                onClick={onUnlockPremium}
                className="px-4 py-2 rounded-xl bg-purple-500 disabled:bg-slate-800 disabled:text-slate-400 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Gem className="w-3.5 h-3.5" /> UNLOCK PREMIUM (180)
              </button>
            )}
          </div>
        </div>

        {/* 100-Level Tier Matrix */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {tiersToShow.map((tier) => {
            const unlocked = save.seasonPassXp >= tier.xpRequired;
            const freeClaimed = save.claimedFreePassLevels.includes(tier.level);
            const premClaimed = save.claimedPremiumPassLevels.includes(tier.level);

            return (
              <div
                key={tier.level}
                className={`p-3.5 rounded-2xl border flex flex-col gap-2.5 ${
                  tier.isMilestone
                    ? 'bg-gradient-to-b from-amber-500/12 to-[#0B1120] border-amber-400/50'
                    : 'bg-[#0B1120] border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between text-xs font-mono-num">
                  <span className="font-extrabold text-white">TIER {tier.level}</span>
                  <span className={unlocked ? 'text-emerald-400' : 'text-slate-500'}>
                    {tier.xpRequired.toLocaleString()} XP
                  </span>
                </div>

                {/* Free Track */}
                <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <div className="text-[10px] font-mono-num text-slate-400">FREE TRACK</div>
                    <div className="text-xs font-bold text-slate-100">{tier.freeLabel}</div>
                  </div>
                  {freeClaimed ? (
                    <span className="text-emerald-400 text-xs font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                    </span>
                  ) : (
                    <button
                      type="button"
                      disabled={!unlocked}
                      onClick={() => onClaimReward(tier, 'free')}
                      className="px-2.5 py-1 rounded-lg bg-amber-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 text-[11px] font-bold cursor-pointer"
                    >
                      {unlocked ? 'CLAIM' : 'LOCK'}
                    </button>
                  )}
                </div>

                {/* Premium Track */}
                <div className="p-2.5 rounded-xl bg-purple-950/35 border border-purple-500/35 flex items-center justify-between gap-2">
                  <div>
                    <div className="text-[10px] font-mono-num text-purple-300">PREMIUM TRACK</div>
                    <div className="text-xs font-bold text-amber-200">{tier.premiumLabel}</div>
                  </div>
                  {!save.seasonPremiumUnlocked ? (
                    <Lock className="w-3.5 h-3.5 text-purple-400" />
                  ) : premClaimed ? (
                    <span className="text-emerald-400 text-xs font-bold">
                      <Check className="w-3.5 h-3.5" />
                    </span>
                  ) : (
                    <button
                      type="button"
                      disabled={!unlocked}
                      onClick={() => onClaimReward(tier, 'premium')}
                      className="px-2.5 py-1 rounded-lg bg-purple-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-[11px] font-bold cursor-pointer"
                    >
                      {unlocked ? 'CLAIM' : 'LOCK'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
