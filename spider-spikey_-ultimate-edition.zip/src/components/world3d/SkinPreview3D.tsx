import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { buildSpiderCharacter3D, createProceduralTextures } from '../../game3d/proceduralModels';
import { SkinDef } from '../../types/spider3d';

interface SkinPreview3DProps {
  skin: SkinDef;
  height?: number;
}

export const SkinPreview3D: React.FC<SkinPreview3DProps> = ({ skin, height = 260 }) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const skinRef = useRef(skin);
  skinRef.current = skin;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const probeCanvas = document.createElement('canvas');
    const glProbe = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
    let isSoftwareGl = false;
    if (glProbe) {
      const dbg = glProbe.getExtension('WEBGL_debug_renderer_info');
      if (dbg) {
        isSoftwareGl = /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(
          String(glProbe.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '')
        );
      }
    }

    const w = host.clientWidth || 280;
    const h = height;
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      alpha: true,
      powerPreference: isSoftwareGl ? 'low-power' : 'high-performance',
    });
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(w, h);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.88;
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envRT = pmrem.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envRT.texture;
    scene.environmentIntensity = 0.45;
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(42, w / h, 0.2, 40);
    camera.position.set(0, 1.32, 3.85);
    camera.lookAt(0, 1.05, 0);

    scene.add(new THREE.HemisphereLight(0xdbeafe, 0x0f172a, 0.68));
    const key = new THREE.DirectionalLight(0xffffff, 1.45);
    key.position.set(2.5, 4, 3);
    scene.add(key);
    const rimCrimson = new THREE.DirectionalLight(0xf43f5e, 0.95);
    rimCrimson.position.set(-3, 2.5, -2.5);
    scene.add(rimCrimson);
    const rimPurple = new THREE.DirectionalLight(0xa855f7, 0.8);
    rimPurple.position.set(3, 1.5, -2.5);
    scene.add(rimPurple);

    const tex = createProceduralTextures(1);
    const rig = buildSpiderCharacter3D(skinRef.current, tex.contactShadowMap);
    scene.add(rig.root);

    let activeId = skinRef.current.id;
    let running = true;
    let prev = performance.now();
    let elapsed = 0;
    let manualYaw = -0.35;
    let dragging = false;
    let lastX = 0;

    const onDown = (e: PointerEvent) => {
      dragging = true;
      lastX = e.clientX;
    };
    const onMove = (e: PointerEvent) => {
      if (!dragging) return;
      manualYaw += (e.clientX - lastX) * 0.012;
      lastX = e.clientX;
    };
    const onUp = () => {
      dragging = false;
    };
    renderer.domElement.addEventListener('pointerdown', onDown);
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);

    const loop = () => {
      if (!running) return;
      if (document.hidden) {
        window.setTimeout(() => requestAnimationFrame(loop), 250);
        return;
      }
      const now = performance.now();
      const dt = Math.min((now - prev) / 1000, 0.05);
      prev = now;
      elapsed += dt;

      if (skinRef.current.id !== activeId) {
        activeId = skinRef.current.id;
        rig.updateSkin(skinRef.current);
      }

      if (!dragging) manualYaw += dt * 0.65;
      rig.root.rotation.y = manualYaw;
      rig.animate(
        skinRef.current.variant === 'miles_morales' ? 'previewSelect' : 'victory',
        elapsed,
        dt,
        0,
        false,
        false
      );
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        window.setTimeout(() => requestAnimationFrame(loop), 95);
      } else {
        requestAnimationFrame(loop);
      }
    };
    requestAnimationFrame(loop);

    return () => {
      running = false;
      renderer.domElement.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      tex.dispose();
      envRT.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === host) {
        host.removeChild(renderer.domElement);
      }
    };
  }, [height]);

  return (
    <div
      ref={hostRef}
      style={{ height }}
      data-testid="skin-preview-3d-canvas"
      className="w-full rounded-xl border border-slate-700/70 bg-gradient-to-b from-[#0C1224] to-[#070B14] overflow-hidden cursor-grab active:cursor-grabbing"
    />
  );
};
