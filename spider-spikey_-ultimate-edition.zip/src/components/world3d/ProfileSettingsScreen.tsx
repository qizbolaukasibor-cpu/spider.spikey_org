import React from 'react';
import { ArrowLeft, Keyboard, Maximize2, RotateCcw, Settings, User, Volume2, VolumeX } from 'lucide-react';
import {
  Game3DSettings,
  GraphicsPreset3D,
  KeyBindings3D,
  PlayerSaveData,
  SeasonTheme,
  WeatherMode,
} from '../../types/spider3d';
import {
  applyGraphicsPreset,
  DEFAULT_KEY_BINDINGS,
  getRankForPoints,
} from '../../utils/spider3dStorage';

interface ProfileSettingsScreenProps {
  initialTab: 'PROFILE' | 'SETTINGS';
  save: PlayerSaveData;
  onBack: () => void;
  onUpdateProfile: (patch: Partial<Pick<PlayerSaveData, 'playerName' | 'title' | 'avatarColor'>>) => void;
  onUpdateSettings: (patch: Partial<Game3DSettings>) => void;
  onResetSave: () => void;
}

const AVATAR_COLORS = ['#E11D48', '#2563EB', '#10B981', '#7C3AED', '#F59E0B', '#06B6D4'];

const BINDABLE_ACTIONS: Array<{ key: keyof KeyBindings3D; label: string }> = [
  { key: 'forward', label: 'Move Forward' },
  { key: 'backward', label: 'Move Backward' },
  { key: 'left', label: 'Strafe Left' },
  { key: 'right', label: 'Strafe Right' },
  { key: 'jump', label: 'Jump / Double Jump' },
  { key: 'sprint', label: 'Sprint' },
  { key: 'shootWeb', label: 'Shoot / Chain Web' },
  { key: 'releaseWeb', label: 'Release Web Boost' },
  { key: 'interact', label: 'Reel Pull / Shield' },
  { key: 'skill', label: 'Web Dash Skill' },
  { key: 'fight', label: 'Combat Strike' },
  { key: 'web1', label: 'Web 1 · Forward' },
  { key: 'web2', label: 'Web 2 · Backward' },
  { key: 'web3', label: 'Web 3 · Left' },
  { key: 'web4', label: 'Web 4 · Right' },
  { key: 'web5', label: 'Web 5 · Upward' },
];

function formatKeyLabel(code: string): string {
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  return code;
}

export const ProfileSettingsScreen: React.FC<ProfileSettingsScreenProps> = ({
  initialTab,
  save,
  onBack,
  onUpdateProfile,
  onUpdateSettings,
  onResetSave,
}) => {
  const [tab, setTab] = React.useState<'PROFILE' | 'SETTINGS'>(initialTab);
  const [listeningAction, setListeningAction] = React.useState<keyof KeyBindings3D | null>(null);
  const rank = getRankForPoints(save.rankPoints);
  const bindings = save.settings.keyBindings || DEFAULT_KEY_BINDINGS;

  React.useEffect(() => {
    if (!listeningAction) return;
    const onCaptureKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.code === 'Escape') {
        setListeningAction(null);
        return;
      }
      onUpdateSettings({
        keyBindings: {
          ...bindings,
          [listeningAction]: e.code,
        },
      });
      setListeningAction(null);
    };
    window.addEventListener('keydown', onCaptureKey, { capture: true });
    return () => window.removeEventListener('keydown', onCaptureKey, { capture: true });
  }, [listeningAction, bindings, onUpdateSettings]);

  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  return (
    <div className="fixed inset-0 z-30 bg-[#070B14] overflow-y-auto p-4 sm:p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> MENU
            </button>
            <h1 className="font-display text-2xl font-extrabold text-white">
              {tab === 'PROFILE' ? 'HERO PROFILE & CAREER STATS' : '3D ENGINE & AUDIO SETTINGS'}
            </h1>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setTab('PROFILE')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                tab === 'PROFILE'
                  ? 'bg-amber-400 text-slate-950'
                  : 'bg-slate-900 border border-slate-700 text-slate-300'
              }`}
            >
              <User className="w-3.5 h-3.5" /> PROFILE
            </button>
            <button
              type="button"
              onClick={() => setTab('SETTINGS')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                tab === 'SETTINGS'
                  ? 'bg-amber-400 text-slate-950'
                  : 'bg-slate-900 border border-slate-700 text-slate-300'
              }`}
            >
              <Settings className="w-3.5 h-3.5" /> SETTINGS
            </button>
          </div>
        </div>

        {tab === 'PROFILE' ? (
          <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800 space-y-4">
              <div>
                <label className="block text-xs font-mono-num text-slate-400 mb-1">
                  HERO CALLSIGN
                </label>
                <input
                  type="text"
                  value={save.playerName}
                  maxLength={18}
                  onChange={(e) => onUpdateProfile({ playerName: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-display font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-mono-num text-slate-400 mb-1.5">
                  AVATAR EMBLEM COLOR
                </label>
                <div className="flex items-center gap-2">
                  {AVATAR_COLORS.map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() => onUpdateProfile({ avatarColor: col })}
                      className={`w-8 h-8 rounded-lg border-2 cursor-pointer ${
                        save.avatarColor === col ? 'border-white scale-110' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: col }}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono-num text-slate-400 mb-1.5">
                  EQUIPPED TITLE
                </label>
                <div className="flex flex-wrap gap-2">
                  {save.unlockedTitles.map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => onUpdateProfile({ title: t })}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border cursor-pointer ${
                        save.title === t
                          ? 'bg-amber-400 text-slate-950 border-amber-300'
                          : 'bg-slate-900 text-slate-300 border-slate-700'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800 grid grid-cols-2 gap-3 text-xs font-mono-num">
              <StatTile label="PLAYER LEVEL" value={`${save.level}`} />
              <StatTile label="COMPETITIVE RANK" value={`${rank.current.name} (${save.rankPoints})`} />
              <StatTile label="MATCHES COMPLETED" value={`${save.matchesCompleted}`} />
              <StatTile label="TOTAL VICTORIES" value={`${save.wins}`} />
              <StatTile label="BOSSES DEFEATED" value={`${save.bossesDefeatedCount}`} />
              <StatTile label="WEBS SHOT" value={`${save.stats.websShot}`} />
              <StatTile label="ORBS COLLECTED" value={`${save.stats.orbsCollected}`} />
              <StatTile label="DISTANCE SWUNG" value={`${Math.round(save.stats.distanceMeters)} m`} />
            </div>
          </div>
        ) : (
          <div className="mt-5 space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800 space-y-4">
                <h2 className="font-display text-lg font-bold text-white">WORLD &amp; GRAPHICS</h2>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Graphics Preset (Low, Medium, High, Ultra, Extreme)
                  </label>
                  <div className="grid grid-cols-5 gap-1.5">
                    {(['low', 'medium', 'high', 'ultra', 'extreme'] as GraphicsPreset3D[]).map(
                      (q) => (
                        <button
                          key={q}
                          type="button"
                          data-testid={`preset-${q}`}
                          onClick={() => onUpdateSettings(applyGraphicsPreset(q))}
                          className={`py-2 rounded-xl text-[11px] font-bold uppercase cursor-pointer ${
                            save.settings.graphicsQuality === q
                              ? 'bg-sky-400 text-slate-950'
                              : 'bg-slate-900 text-slate-300 border border-slate-700'
                          }`}
                        >
                          {q}
                        </button>
                      )
                    )}
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>Resolution Scale</span>
                    <span>{Math.round((save.settings.resolutionScale ?? 1) * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.6}
                    max={1.25}
                    step={0.05}
                    value={save.settings.resolutionScale ?? 1}
                    onChange={(e) => onUpdateSettings({ resolutionScale: Number(e.target.value) })}
                    className="w-full accent-sky-400"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">View Distance</label>
                    <select
                      value={save.settings.viewDistance ?? 'far'}
                      onChange={(e) =>
                        onUpdateSettings({
                          viewDistance: e.target.value as Game3DSettings['viewDistance'],
                        })
                      }
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    >
                      <option value="near">Near (240m)</option>
                      <option value="medium">Medium (340m)</option>
                      <option value="far">Far (460m)</option>
                      <option value="ultra">Ultra (620m)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Particle Quality</label>
                    <select
                      value={save.settings.particleQuality ?? 'high'}
                      onChange={(e) =>
                        onUpdateSettings({
                          particleQuality: e.target.value as Game3DSettings['particleQuality'],
                        })
                      }
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Target FPS Mode</label>
                    <select
                      value={save.settings.fpsMode ?? 'auto'}
                      onChange={(e) =>
                        onUpdateSettings({
                          fpsMode: e.target.value as Game3DSettings['fpsMode'],
                        })
                      }
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    >
                      <option value="auto">Auto (Display Sync)</option>
                      <option value="60">60 FPS Cap</option>
                      <option value="120">120+ FPS Uncapped</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Active Season World</label>
                    <select
                      value={save.settings.activeSeason}
                      onChange={(e) => onUpdateSettings({ activeSeason: e.target.value as SeasonTheme })}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    >
                      <option value="WINTER">Winter Snow City</option>
                      <option value="NEW_YEAR">New Year Fireworks</option>
                      <option value="SPRING">Spring Blossom City</option>
                      <option value="SUMMER">Summer Sunny City</option>
                      <option value="AUTUMN">Autumn Amber City</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Weather System</label>
                  <select
                    value={save.settings.weather}
                    onChange={(e) => onUpdateSettings({ weather: e.target.value as WeatherMode })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  >
                    <option value="CLEAR">Clear Skies</option>
                    <option value="SNOW">Falling Snow</option>
                    <option value="RAIN">Metropolis Rain</option>
                    <option value="WIND">Wind &amp; Leaves</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-x-4 gap-y-2 pt-1">
                  <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                    <span>Dynamic Shadows</span>
                    <input
                      type="checkbox"
                      checked={save.settings.shadows}
                      onChange={(e) => onUpdateSettings({ shadows: e.target.checked })}
                      className="w-4 h-4 accent-amber-400"
                    />
                  </label>
                  <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                    <span>Bloom Glow</span>
                    <input
                      type="checkbox"
                      checked={save.settings.bloom ?? true}
                      onChange={(e) => onUpdateSettings({ bloom: e.target.checked })}
                      className="w-4 h-4 accent-amber-400"
                    />
                  </label>
                  <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                    <span>Day / Night Cycle</span>
                    <input
                      type="checkbox"
                      checked={save.settings.dayNightAuto}
                      onChange={(e) => onUpdateSettings({ dayNightAuto: e.target.checked })}
                      className="w-4 h-4 accent-amber-400"
                    />
                  </label>
                  <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                    <span>Show Real FPS</span>
                    <input
                      type="checkbox"
                      checked={save.settings.showFps ?? true}
                      onChange={(e) => onUpdateSettings({ showFps: e.target.checked })}
                      className="w-4 h-4 accent-emerald-400"
                    />
                  </label>
                </div>

                <button
                  type="button"
                  onClick={handleToggleFullscreen}
                  className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Maximize2 className="w-3.5 h-3.5" /> TOGGLE FULLSCREEN
                </button>
              </div>

              <div className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800 space-y-4">
                <h2 className="font-display text-lg font-bold text-white">AUDIO &amp; CAMERA</h2>

                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>Sound Effects Volume</span>
                    <span>{save.settings.soundVolume}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={save.settings.soundVolume}
                    onChange={(e) => onUpdateSettings({ soundVolume: Number(e.target.value) })}
                    className="w-full accent-amber-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>Music Volume</span>
                    <span>{save.settings.musicVolume}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={save.settings.musicVolume}
                    onChange={(e) => onUpdateSettings({ musicVolume: Number(e.target.value) })}
                    className="w-full accent-sky-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>Camera Orbit Sensitivity</span>
                    <span>{save.settings.cameraSensitivity.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min={0.4}
                    max={2.4}
                    step={0.1}
                    value={save.settings.cameraSensitivity}
                    onChange={(e) => onUpdateSettings({ cameraSensitivity: Number(e.target.value) })}
                    className="w-full accent-emerald-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>Mouse Aim Sensitivity</span>
                    <span>{(save.settings.mouseSensitivity ?? 1).toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min={0.4}
                    max={2.4}
                    step={0.1}
                    value={save.settings.mouseSensitivity ?? 1}
                    onChange={(e) => onUpdateSettings({ mouseSensitivity: Number(e.target.value) })}
                    className="w-full accent-cyan-400"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => onUpdateSettings({ muted: !save.settings.muted })}
                  className={`w-full py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border cursor-pointer ${
                    save.settings.muted
                      ? 'bg-rose-500/20 border-rose-500 text-rose-200'
                      : 'bg-slate-900 border-slate-700 text-white'
                  }`}
                >
                  {save.settings.muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  {save.settings.muted ? 'AUDIO MUTED (CLICK TO UNMUTE)' : 'MUTE ALL AUDIO'}
                </button>

                <div className="pt-4 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={onResetSave}
                    className="w-full py-2.5 rounded-xl bg-rose-600/20 border border-rose-500/40 hover:bg-rose-600/35 text-rose-200 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> RESET LOCAL SAVE DATA
                  </button>
                </div>
              </div>
            </div>

            {/* Customizable Keybindings Panel */}
            <div
              data-testid="custom-controls-panel"
              className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800"
            >
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div>
                  <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
                    <Keyboard className="w-5 h-5 text-amber-400" />
                    CUSTOMIZE CONTROLS (KEYBINDINGS)
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Click any key badge below, then press any keyboard key to rebind (Esc cancels). Mouse LMB shoots webs; RMB releases swing or strikes.
                  </p>
                </div>
                <button
                  type="button"
                  data-testid="reset-controls-btn"
                  onClick={() => onUpdateSettings({ keyBindings: { ...DEFAULT_KEY_BINDINGS } })}
                  className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-sky-400 text-xs font-bold text-slate-200 cursor-pointer"
                >
                  RESET DEFAULT CONTROLS
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                {BINDABLE_ACTIONS.map((item) => {
                  const isListening = listeningAction === item.key;
                  return (
                    <div
                      key={item.key}
                      className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-slate-900/90 border border-slate-800"
                    >
                      <span className="text-xs text-slate-300 font-medium truncate">
                        {item.label}
                      </span>
                      <button
                        type="button"
                        data-testid={`bind-btn-${item.key}`}
                        onClick={() => setListeningAction(isListening ? null : item.key)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-mono-num font-bold min-w-[68px] text-center border cursor-pointer ${
                          isListening
                            ? 'bg-amber-400 text-slate-950 border-amber-300'
                            : 'bg-slate-800 text-sky-300 border-slate-700 hover:border-amber-400'
                        }`}
                      >
                        {isListening ? 'PRESS KEY...' : formatKeyLabel(bindings[item.key])}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const StatTile: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
    <div className="text-[10px] text-slate-400">{label}</div>
    <div className="mt-1 text-sm font-bold text-white">{value}</div>
  </div>
);
