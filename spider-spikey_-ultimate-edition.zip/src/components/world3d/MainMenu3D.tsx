import React from 'react';
import {
  Award,
  Backpack,
  Box,
  Coins,
  Crown,
  Flame,
  Gem,
  Map,
  Play,
  Settings,
  Shield,
  ShoppingBag,
  Sparkles,
  Swords,
  Target,
  User,
  Zap,
} from 'lucide-react';
import { BOSS_CATALOG, SKIN_BY_ID, WEB_BY_ID } from '../../data/world3dCatalog';
import { LEVEL_BY_ID } from '../../data/levels3d';
import { PlayerSaveData, Screen3D, SeasonTheme } from '../../types/spider3d';
import { getRankForPoints, getSeasonPassLevel, xpForNextLevel } from '../../utils/spider3dStorage';

interface MainMenu3DProps {
  save: PlayerSaveData;
  onNavigate: (screen: Screen3D) => void;
  onStartCityMatch: () => void;
  onStartCityFreeRoam: () => void;
  onSelectSeason: (season: SeasonTheme) => void;
}

const SEASONS: Array<{ id: SeasonTheme; label: string }> = [
  { id: 'WINTER', label: 'Winter' },
  { id: 'NEW_YEAR', label: 'New Year' },
  { id: 'SPRING', label: 'Spring' },
  { id: 'SUMMER', label: 'Summer' },
  { id: 'AUTUMN', label: 'Autumn' },
];

export const MainMenu3D: React.FC<MainMenu3DProps> = ({
  save,
  onNavigate,
  onStartCityMatch,
  onStartCityFreeRoam,
  onSelectSeason,
}) => {
  const rank = getRankForPoints(save.rankPoints);
  const seasonLvl = getSeasonPassLevel(save.seasonPassXp);
  const nextLvlXp = xpForNextLevel(save.level);
  const xpPct = Math.min(100, Math.round((save.xp / nextLvlXp) * 100));
  const equippedSkin = SKIN_BY_ID[save.equippedSkinId];
  const equippedWeb = WEB_BY_ID[save.equippedWebId];
  const currentLvl = LEVEL_BY_ID[save.selectedLevelId || save.unlockedLevel || 1] || LEVEL_BY_ID[1];
  const nextBoss = BOSS_CATALOG[save.bossesDefeatedCount % BOSS_CATALOG.length];
  const matchesUntilBoss = 5 - (save.matchesCompleted % 5);
  const totalCases = Object.values(save.casesOwned).reduce((a, b) => a + b, 0);

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between p-4 sm:p-6 pointer-events-none">
      {/* Top Economy & Player Bar */}
      <header className="flex flex-wrap items-center justify-between gap-3 pointer-events-auto">
        <div className="flex items-center gap-3 px-4 py-2.5 rounded-xl bg-[#0A0F1D]/92 border border-slate-700/80 shadow-lg">
          <div
            className="w-10 h-10 rounded-lg flex items-center justify-center font-display font-extrabold text-white border border-white/20"
            style={{ backgroundColor: save.avatarColor }}
          >
            {save.playerName.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-white text-sm sm:text-base">
                {save.playerName}
              </span>
              <span
                className="px-2 py-0.5 rounded text-[11px] font-bold border"
                style={{ color: rank.current.color, borderColor: rank.current.color }}
              >
                {rank.current.name}
              </span>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs font-mono-num text-sky-300 font-bold">LV.{save.level}</span>
              <div className="w-28 h-2 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-sky-400" style={{ width: `${xpPct}%` }} />
              </div>
              <span className="text-[11px] font-mono-num text-slate-400">
                {save.xp}/{nextLvlXp}
              </span>
            </div>
          </div>
        </div>

        {/* Season Quick Switcher + Currencies */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="hidden md:flex items-center gap-1 p-1 rounded-xl bg-[#0A0F1D]/92 border border-slate-700/80">
            {SEASONS.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => onSelectSeason(s.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                  save.settings.activeSeason === s.id
                    ? 'bg-sky-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#0A0F1D]/92 border border-amber-500/40 font-mono-num text-sm font-bold text-amber-300">
            <Coins className="w-4 h-4 text-amber-400" />
            <span>{save.coins.toLocaleString()}</span>
          </div>

          <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#0A0F1D]/92 border border-cyan-500/40 font-mono-num text-sm font-bold text-cyan-300">
            <Gem className="w-4 h-4 text-cyan-400" />
            <span>{save.gems.toLocaleString()}</span>
          </div>
        </div>
      </header>

      {/* Main Layout: Left Hero CTA & Boss Cycle Tracker, Right Functional 13-Button Grid */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-end justify-between gap-5 my-auto lg:my-0 py-3">
        {/* Left: Game Identity + PLAY CTA */}
        <div className="pointer-events-auto max-w-md flex flex-col gap-3">
          <div className="bg-[#080C17]/90 border border-slate-700/80 rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center gap-2 text-xs font-mono-num text-amber-400 tracking-wider">
              <Flame className="w-4 h-4" />
              <span>STAGE {currentLvl.id}/10 · SEASON {seasonLvl}/100</span>
            </div>
            <h1 className="mt-1 font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              {currentLvl.name.toUpperCase()}
            </h1>
            <p className="mt-1.5 text-xs sm:text-sm text-slate-300">
              Suit: <strong className="text-white">{equippedSkin?.name}</strong> · Web:{' '}
              <strong className="text-sky-300">{equippedWeb?.name}</strong>
            </p>

            {/* 5-Match Boss Cycle Progress */}
            <div className="mt-4 p-3 rounded-xl bg-slate-900/90 border border-rose-500/35 flex items-center justify-between gap-3">
              <div>
                <div className="text-[11px] font-mono-num text-rose-300 uppercase">
                  Next Auto-Boss ({matchesUntilBoss} match{matchesUntilBoss === 1 ? '' : 'es'} left)
                </div>
                <div className="text-sm font-display font-bold text-white">{nextBoss.name}</div>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('BOSS_ARENA')}
                className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer"
              >
                ARENA
              </button>
            </div>

            <button
              type="button"
              onClick={onStartCityMatch}
              data-testid="menu-play-btn"
              className="mt-4 w-full py-3.5 px-6 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-display font-extrabold text-lg tracking-wide flex items-center justify-center gap-2.5 shadow-[0_0_24px_rgba(245,196,81,0.35)] transition active:scale-[0.98] cursor-pointer whitespace-nowrap"
            >
              <Play className="w-5 h-5 fill-slate-950" />
              PLAY LEVEL {currentLvl.id}
            </button>
            <button
              type="button"
              onClick={onStartCityFreeRoam}
              data-testid="menu-city-roam-btn"
              className="mt-2.5 w-full py-2.5 px-4 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-400/50 text-sky-200 font-display font-bold text-sm tracking-wide flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
            >
              <Map className="w-4 h-4 text-sky-300" />
              OPEN-WORLD CITY FREE ROAM
            </button>
          </div>
        </div>

        {/* Right: Complete 13-Button Functional Navigation Hub */}
        <nav
          aria-label="Main Menu Navigation"
          className="pointer-events-auto w-full lg:w-[580px] bg-[#080C17]/92 border border-slate-700/80 rounded-2xl p-4 shadow-2xl"
        >
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            <MenuTile
              icon={<Play className="w-4 h-4 text-amber-400" />}
              label="PLAY"
              sub={`Level ${currentLvl.id}`}
              accent="border-amber-400/50 bg-amber-500/10"
              onClick={onStartCityMatch}
              testId="nav-play"
            />
            <MenuTile
              icon={<Map className="w-4 h-4 text-emerald-400" />}
              label="LEVELS"
              sub={`${save.unlockedLevel}/10 Worlds`}
              accent="border-emerald-400/40 bg-emerald-500/10"
              onClick={() => onNavigate('LEVELS')}
              testId="nav-levels"
            />
            <MenuTile
              icon={<Backpack className="w-4 h-4 text-sky-400" />}
              label="INVENTORY"
              sub={`${save.ownedSkinIds.length} Suits`}
              onClick={() => onNavigate('INVENTORY')}
              testId="nav-inventory"
            />
            <MenuTile
              icon={<Sparkles className="w-4 h-4 text-purple-400" />}
              label="SKINS"
              sub={`${save.ownedSkinIds.length}/13`}
              onClick={() => onNavigate('SKINS')}
              testId="nav-skins"
            />
            <MenuTile
              icon={<Zap className="w-4 h-4 text-cyan-400" />}
              label="WEBS"
              sub={`${save.ownedWebIds.length}/13`}
              onClick={() => onNavigate('WEBS')}
              testId="nav-webs"
            />
            <MenuTile
              icon={<Shield className="w-4 h-4 text-emerald-400" />}
              label="SKILLS"
              sub="15 Abilities"
              onClick={() => onNavigate('SKILLS')}
              testId="nav-skills"
            />
            <MenuTile
              icon={<ShoppingBag className="w-4 h-4 text-amber-300" />}
              label="SHOP"
              sub="Daily & Vault"
              onClick={() => onNavigate('SHOP')}
              testId="nav-shop"
            />
            <MenuTile
              icon={<Crown className="w-4 h-4 text-yellow-400" />}
              label="SEASON PASS"
              sub={`Tier ${seasonLvl}/100`}
              onClick={() => onNavigate('SEASON_PASS')}
              testId="nav-season-pass"
            />
            <MenuTile
              icon={<Box className="w-4 h-4 text-pink-400" />}
              label="CASES"
              sub={`${totalCases} Ready`}
              onClick={() => onNavigate('CASES')}
              testId="nav-cases"
            />
            <MenuTile
              icon={<Swords className="w-4 h-4 text-rose-400" />}
              label="BOSS ARENA"
              sub="7 Bosses"
              onClick={() => onNavigate('BOSS_ARENA')}
              testId="nav-boss-arena"
            />
            <MenuTile
              icon={<Target className="w-4 h-4 text-teal-400" />}
              label="MISSIONS"
              sub="Rank & Goals"
              onClick={() => onNavigate('MISSIONS')}
              testId="nav-missions"
            />
            <MenuTile
              icon={<User className="w-4 h-4 text-indigo-400" />}
              label="PROFILE"
              sub={save.title}
              onClick={() => onNavigate('PROFILE')}
              testId="nav-profile"
            />
            <MenuTile
              icon={<Settings className="w-4 h-4 text-slate-300" />}
              label="SETTINGS"
              sub="Graphics & Audio"
              onClick={() => onNavigate('SETTINGS')}
              testId="nav-settings"
            />
          </div>
        </nav>
      </div>

      {/* Bottom Quick Bar */}
      <footer className="hidden sm:flex items-center justify-between text-xs text-slate-400 font-mono-num pointer-events-auto">
        <div className="bg-[#080C17]/85 px-3 py-1.5 rounded-lg border border-slate-800 flex items-center gap-2">
          <Award className="w-3.5 h-3.5 text-amber-400" />
          <span>
            Matches: {save.matchesCompleted} · Wins: {save.wins} · Bosses Defeated:{' '}
            {save.bossesDefeatedCount}
          </span>
        </div>
        <div className="bg-[#080C17]/85 px-3 py-1.5 rounded-lg border border-slate-800">
          DRAG MOUSE TO ROTATE CAMERA IN PLAY MODE · F OR CLICK TO SHOOT WEB
        </div>
      </footer>
    </div>
  );
};

interface MenuTileProps {
  icon: React.ReactNode;
  label: string;
  sub: string;
  accent?: string;
  onClick: () => void;
  testId: string;
}

const MenuTile: React.FC<MenuTileProps> = ({ icon, label, sub, accent, onClick, testId }) => (
  <button
    type="button"
    onClick={onClick}
    data-testid={testId}
    className={`flex flex-col items-start justify-between p-3 rounded-xl border text-left transition hover:border-amber-400/70 hover:bg-slate-800/90 active:scale-[0.98] cursor-pointer ${
      accent || 'border-slate-700/80 bg-slate-900/90'
    }`}
  >
    <div className="flex items-center justify-between w-full">
      {icon}
      <span className="text-[10px] font-mono-num text-slate-400">{sub}</span>
    </div>
    <div className="mt-2 font-display font-bold text-xs sm:text-sm text-white tracking-wide">
      {label}
    </div>
  </button>
);
