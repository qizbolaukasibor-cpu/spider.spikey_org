import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ChevronDown,
  ChevronUp,
  Coins,
  Gem,
  Pause,
  RotateCcw,
  Shield,
  Sparkles,
  Sun,
  Swords,
  Wind,
  Zap,
} from 'lucide-react';
import { WEB_BY_ID } from '../../data/world3dCatalog';
import { BossDef, LevelDef, PlayerSaveData, WebDirection } from '../../types/spider3d';
import { DEFAULT_KEY_BINDINGS } from '../../utils/spider3dStorage';
import { HudSnapshot3D } from './SpiderWorldCanvas';

function formatKeyShort(code: string | undefined, fallback: string): string {
  const raw = code || fallback;
  if (raw.startsWith('Key')) return raw.slice(3);
  if (raw.startsWith('Digit')) return raw.slice(5);
  if (raw === 'Space') return 'SPACE';
  if (raw === 'ShiftLeft' || raw === 'ShiftRight') return 'SHIFT';
  return raw.toUpperCase();
}

export type GameOutcome3D =
  | null
  | { type: 'MATCH_WIN'; orbs: number; drones: number; coins: number; xp: number; bossTriggered: boolean }
  | {
      type: 'LEVEL_WIN';
      level: LevelDef;
      orbs: number;
      enemies: number;
      coins: number;
      gems: number;
      xp: number;
      firstClear: boolean;
      unlockedNextLevel: number;
      bossTriggered: boolean;
    }
  | { type: 'BOSS_WIN'; boss: BossDef }
  | { type: 'DEFEAT'; fromBoss: boolean; reason?: string };

interface GameHud3DProps {
  mode: 'LEVEL_MATCH' | 'CITY_MATCH' | 'BOSS_ARENA';
  paused: boolean;
  save: PlayerSaveData;
  hud: HudSnapshot3D;
  activeBoss: BossDef | null;
  activeLevel: LevelDef | null;
  outcome: GameOutcome3D;
  onSelectDirection: (dir: WebDirection) => void;
  onShootWeb: () => void;
  onReleaseWeb: () => void;
  onPullChange: (active: boolean) => void;
  onJump: () => void;
  onFight: () => void;
  onSkill: (k: 'dash' | 'shield' | 'shadow' | 'trap' | 'ult') => void;
  onTogglePause: () => void;
  onExitToMenu: () => void;
  onReplay: () => void;
  onContinueNextLevel: () => void;
  onLaunchNextBoss: () => void;
}

const DIRS: Array<{ id: WebDirection; keyNum: string; label: string; icon: React.ReactNode }> = [
  { id: 'FORWARD', keyNum: '1', label: 'FRONT', icon: <ArrowUp className="w-3.5 h-3.5" /> },
  { id: 'BACKWARD', keyNum: '2', label: 'BACK', icon: <ArrowDown className="w-3.5 h-3.5" /> },
  { id: 'LEFT', keyNum: '3', label: 'LEFT', icon: <ArrowLeft className="w-3.5 h-3.5" /> },
  { id: 'RIGHT', keyNum: '4', label: 'RIGHT', icon: <ArrowRight className="w-3.5 h-3.5" /> },
  { id: 'UPWARD', keyNum: '5', label: 'UP', icon: <Sparkles className="w-3.5 h-3.5" /> },
];

export const GameHud3D: React.FC<GameHud3DProps> = ({
  mode,
  paused,
  save,
  hud,
  activeBoss,
  activeLevel,
  outcome,
  onSelectDirection,
  onShootWeb,
  onReleaseWeb,
  onPullChange,
  onJump,
  onFight,
  onSkill,
  onTogglePause,
  onExitToMenu,
  onReplay,
  onContinueNextLevel,
  onLaunchNextBoss,
}) => {
  const [flightGuideOpen, setFlightGuideOpen] = useState(true);
  const webDef = WEB_BY_ID[save.equippedWebId];
  const isMiles = save.equippedSkinId === 'skin_miles_morales';
  const kb = save.settings.keyBindings || DEFAULT_KEY_BINDINGS;
  const hpPct = Math.max(0, Math.min(100, Math.round((hud.hp / hud.maxHp) * 100)));
  const speedPct = Math.max(0, Math.min(100, Math.round((hud.speedKmh / 120) * 100)));
  const showSpeedLines = (hud.isFlying || hud.webAttached) && hud.speedKmh >= 42 && !paused && !outcome;
  const bossPct =
    hud.bossMaxHp > 0 ? Math.max(0, Math.min(100, Math.round((hud.bossHp / hud.bossMaxHp) * 100))) : 0;

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-3 sm:p-5">
      {/* Subtle Screen-Edge Wind & Speed Lines Overlay during Spider Flight / Fast Swing */}
      {showSpeedLines && (
        <div
          data-testid="hud-speed-lines"
          className="fixed inset-0 pointer-events-none z-10"
          style={{
            background: isMiles
              ? 'radial-gradient(circle at center, transparent 58%, rgba(239, 68, 68, 0.16) 86%, rgba(168, 85, 247, 0.24) 100%)'
              : 'radial-gradient(circle at center, transparent 58%, rgba(56, 189, 248, 0.14) 88%, rgba(251, 191, 36, 0.22) 100%)',
          }}
        />
      )}

      {/* Top Perimeter Bar */}
      <div className="flex flex-col gap-2">
        <div className="flex flex-wrap sm:flex-nowrap items-start justify-between gap-2 sm:gap-3">
          {/* Top-Left: Health, Speed Momentum, Shield, Currencies */}
          <div className="pointer-events-auto bg-[#080C17]/88 border border-slate-700/80 rounded-xl px-3 py-2 flex flex-col gap-1 min-w-[162px] sm:min-w-[235px]">
            <div className="flex items-center justify-between gap-2 text-[11px] sm:text-xs font-mono-num">
              <span className="font-bold text-white">HP {hud.hp}/{hud.maxHp}</span>
              <span
                data-testid="hud-movement-style"
                className={`font-bold ${
                  hud.movementStyle.includes('SWING') || hud.movementStyle.includes('FLY')
                    ? 'text-amber-300'
                    : 'text-sky-300'
                }`}
              >
                {hud.movementStyle}
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className={`h-full transition-all ${
                  hpPct > 40 ? 'bg-emerald-400' : 'bg-rose-500'
                }`}
                style={{ width: `${hpPct}%` }}
              />
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono-num text-slate-300">
              <span className="text-sky-300 font-bold w-14">{hud.speedKmh} km/h</span>
              <div className="flex-1 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-sky-400 to-amber-400 transition-all"
                  style={{ width: `${speedPct}%` }}
                />
              </div>
            </div>
            <div className="flex items-center gap-2.5 text-[11px] font-mono-num text-slate-300">
              <span className="flex items-center gap-1 text-amber-300">
                <Coins className="w-3 h-3" /> {save.coins.toLocaleString()}
              </span>
              <span className="flex items-center gap-1 text-cyan-300">
                <Gem className="w-3 h-3" /> {save.gems}
              </span>
              {hud.shieldTimer > 0 && <span className="text-teal-300 font-bold">SHIELD</span>}
              {hud.shadowTimer > 0 && (
                <span data-testid="hud-camouflage-badge" className="text-purple-300 font-bold">
                  CAMOUFLAGE
                </span>
              )}
            </div>
          </div>

          {/* Top-Center: Boss Bar OR Level Portal Objective OR City Patrol */}
          {mode === 'BOSS_ARENA' && activeBoss ? (
            <div className="pointer-events-auto order-3 sm:order-2 w-full sm:w-auto bg-[#080C17]/92 border border-rose-500/60 rounded-xl px-4 py-2 sm:min-w-[340px] text-center">
              <div className="text-[10px] sm:text-xs font-mono-num text-rose-300 tracking-wider uppercase">
                BOSS #{activeBoss.index} · {activeBoss.title}
              </div>
              <div className="font-display font-bold text-white text-sm sm:text-base">
                {activeBoss.name}
              </div>
              <div className="mt-1 w-full h-2.5 rounded-full bg-slate-900 overflow-hidden border border-rose-500/40">
                <div
                  className="h-full bg-gradient-to-r from-rose-600 to-amber-400 transition-all"
                  style={{ width: `${bossPct}%` }}
                />
              </div>
              <div className="mt-0.5 text-[10px] sm:text-[11px] font-mono-num text-slate-300">
                {hud.bossHp} / {hud.bossMaxHp} HP {hud.bossTelegraph ? '· SLAM INCOMING!' : ''}
              </div>
            </div>
          ) : mode === 'LEVEL_MATCH' && activeLevel ? (
            <div
              data-testid="hud-level-objective"
              className="pointer-events-auto order-3 sm:order-2 w-full sm:w-auto bg-[#080C17]/90 border border-sky-500/50 rounded-xl px-3.5 py-1.5 sm:px-5 sm:py-2 text-center"
            >
              <div className="text-[10px] sm:text-[11px] font-mono-num text-sky-300 tracking-wider uppercase">
                LEVEL {activeLevel.id} / 10 · {activeLevel.difficulty}
              </div>
              <div className="font-display font-bold text-white text-xs sm:text-base whitespace-nowrap">
                {activeLevel.name}
              </div>
              <div className="text-[10px] sm:text-[11px] font-mono-num text-amber-300 whitespace-nowrap">
                PORTAL: {hud.portalDistance ?? 0}m · ORBS {hud.orbsRun} · {hud.altitude}m ALT · {hud.speedKmh} km/h
              </div>
            </div>
          ) : (
            <div className="pointer-events-auto order-3 sm:order-2 w-full sm:w-auto bg-[#080C17]/88 border border-amber-500/45 rounded-xl px-3.5 py-1.5 sm:px-5 sm:py-2 text-center">
              <div className="text-[10px] sm:text-[11px] font-mono-num text-amber-300 tracking-wider">
                OPEN-WORLD CITY PATROL
              </div>
              <div className="font-display font-bold text-white text-xs sm:text-base whitespace-nowrap">
                {hud.matchScore} / {hud.matchTarget} TARGETS
              </div>
              <div className="text-[10px] sm:text-[11px] font-mono-num text-slate-400 whitespace-nowrap">
                {hud.altitude}m ALT · {hud.speedKmh} km/h
              </div>
            </div>
          )}

          {/* Top-Right: Real Measured FPS Counter, Environment Status & Pause */}
          <div className="pointer-events-auto flex items-center gap-2 sm:order-3">
            {save.settings.showFps !== false && (
              <div
                data-testid="hud-fps-counter"
                className="flex items-center gap-1.5 bg-[#080C17]/90 border border-slate-700/80 rounded-xl px-2.5 py-2 text-xs font-mono-num font-bold text-emerald-300 whitespace-nowrap"
              >
                <span>{hud.fps} FPS</span>
              </div>
            )}
            <div className="hidden sm:flex items-center gap-2 bg-[#080C17]/88 border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono-num text-slate-200 whitespace-nowrap">
              <Sun className="w-3.5 h-3.5 text-amber-300" />
              <span>{hud.timePhase}</span>
              <span className="text-slate-600">|</span>
              <span>{save.settings.weather}</span>
            </div>
            <button
              type="button"
              onClick={onTogglePause}
              data-testid="hud-pause-btn"
              className="p-2.5 rounded-xl bg-[#080C17]/90 border border-slate-700 hover:border-amber-400 text-white cursor-pointer"
              title="Pause (Esc)"
            >
              <Pause className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Transient Non-Blocking Event Toast tucked cleanly under top HUD */}
        {hud.bannerText && !paused && !outcome && (
          <div className="self-center px-4 py-1.5 rounded-full bg-amber-400 text-slate-950 font-display font-bold text-[11px] sm:text-xs tracking-wide shadow-lg max-w-[92vw] text-center">
            {hud.bannerText}
          </div>
        )}
      </div>

      {/* Collapsible On-Screen FLIGHT Tutorial (Middle-Right Perimeter) */}
      {!paused && !outcome && (
        <div className="self-end pointer-events-auto flex flex-col items-end gap-1.5 max-w-[260px] sm:max-w-[285px]">
          <button
            type="button"
            onClick={() => setFlightGuideOpen((prev) => !prev)}
            data-testid="flight-tutorial-toggle"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#080C17]/92 border border-sky-400/50 hover:border-amber-400 text-sky-200 text-[11px] font-mono-num font-bold shadow cursor-pointer"
          >
            <Wind className="w-3.5 h-3.5 text-amber-300" />
            <span>FLIGHT GUIDE</span>
            {flightGuideOpen ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5" />
            )}
          </button>

          {flightGuideOpen && (
            <div
              data-testid="flight-tutorial-panel"
              className="w-full rounded-xl bg-[#080C17]/90 border border-sky-500/45 p-2.5 text-[11px] text-slate-200 shadow-xl space-y-1.5"
            >
              <div className="flex items-center justify-between border-b border-slate-700/70 pb-1">
                <span className="font-display font-bold text-amber-300 tracking-wide text-xs">
                  WEB &amp; FLIGHT CONTROLS
                </span>
                <span className="font-mono-num text-[10px] text-sky-300 font-bold">
                  {hud.webAttached ? 'SWINGING' : hud.isFlying ? 'FLYING' : 'READY'}
                </span>
              </div>
              <div
                className={`flex items-start justify-between gap-2 px-1.5 py-1 rounded ${
                  !hud.webAttached && !hud.isFlying ? 'bg-sky-500/20 text-white' : 'text-slate-300'
                }`}
              >
                <span className="font-semibold">1. Jump / Air Jump</span>
                <span className="font-mono-num text-amber-300 font-bold shrink-0">
                  {formatKeyShort(kb.jump, 'Space')} ×2
                </span>
              </div>
              <div className="flex items-start justify-between gap-2 px-1.5 py-0.5 text-slate-300">
                <span className="font-semibold">2. Aim 5 Directions</span>
                <span className="font-mono-num text-sky-300 font-bold shrink-0">1–5</span>
              </div>
              <div
                className={`flex items-start justify-between gap-2 px-1.5 py-1 rounded ${
                  hud.webAttached ? 'bg-amber-400/20 text-amber-200' : 'text-slate-300'
                }`}
              >
                <span className="font-semibold">3. Swing &amp; Reel</span>
                <span className="font-mono-num text-amber-300 font-bold shrink-0">
                  LMB/{formatKeyShort(kb.shootWeb, 'KeyF')} · {formatKeyShort(kb.interact, 'KeyE')}
                </span>
              </div>
              <div
                className={`flex items-start justify-between gap-2 px-1.5 py-1 rounded ${
                  hud.isFlying ? 'bg-emerald-500/25 text-emerald-200' : 'text-slate-300'
                }`}
              >
                <span className="font-semibold">4. Release &amp; Fly</span>
                <span className="font-mono-num text-emerald-300 font-bold shrink-0">
                  RMB/{formatKeyShort(kb.releaseWeb, 'KeyR')}
                </span>
              </div>
              <div className="text-[10px] text-slate-400 pt-0.5 border-t border-slate-800 leading-snug">
                Hold <strong className="text-white">{formatKeyShort(kb.jump, 'Space')}</strong> to glide ·{' '}
                <strong className="text-white">WASD</strong> steer ·{' '}
                <strong className="text-white">{formatKeyShort(kb.sprint, 'ShiftLeft')}</strong> boost · shoot web mid-air to chain!
              </div>
            </div>
          )}
        </div>
      )}

      {/* Bottom Perimeter Bar: 5-Direction Web Selector & Action Abilities */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5">
        {/* 5-Direction Selector (1-5) */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-[#080C17]/92 border border-slate-700/80 rounded-xl p-1.5">
          {DIRS.map((d, idx) => {
            const active = hud.activeDirection === d.id;
            const customKey =
              idx === 0
                ? formatKeyShort(kb.web1, 'Digit1')
                : idx === 1
                  ? formatKeyShort(kb.web2, 'Digit2')
                  : idx === 2
                    ? formatKeyShort(kb.web3, 'Digit3')
                    : idx === 3
                      ? formatKeyShort(kb.web4, 'Digit4')
                      : formatKeyShort(kb.web5, 'Digit5');
            return (
              <button
                key={d.id}
                type="button"
                onClick={() => onSelectDirection(d.id)}
                data-testid={`web-dir-${d.id.toLowerCase()}`}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-mono-num font-bold transition cursor-pointer ${
                  active
                    ? 'bg-sky-400 text-slate-950 shadow scale-105'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span>{customKey}</span>
                {d.icon}
                <span className="hidden md:inline">{d.label}</span>
              </button>
            );
          })}
        </div>

        {/* Action & Skill Buttons */}
        <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-1.5 bg-[#080C17]/92 border border-slate-700/80 rounded-xl p-1.5">
          <button
            type="button"
            onClick={onShootWeb}
            data-testid="hud-shoot-web-btn"
            className="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-950 cursor-pointer"
            style={{ backgroundColor: webDef?.color || '#F1F5F9' }}
          >
            {hud.webAttached
              ? `CHAIN WEB (${formatKeyShort(kb.shootWeb, 'KeyF')})`
              : `SHOOT WEB (${formatKeyShort(kb.shootWeb, 'KeyF')})`}
          </button>

          {hud.webAttached && (
            <>
              <button
                type="button"
                onClick={onReleaseWeb}
                data-testid="hud-release-web-btn"
                className="px-3 py-1.5 rounded-lg bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer"
              >
                RELEASE (RMB/{formatKeyShort(kb.releaseWeb, 'KeyR')})
              </button>
              <button
                type="button"
                onMouseDown={() => onPullChange(true)}
                onMouseUp={() => onPullChange(false)}
                onMouseLeave={() => onPullChange(false)}
                className="px-3 py-1.5 rounded-lg bg-emerald-400 text-slate-950 text-xs font-bold cursor-pointer"
              >
                PULL ({formatKeyShort(kb.interact, 'KeyE')})
              </button>
            </>
          )}

          <button
            type="button"
            onClick={onJump}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-mono-num cursor-pointer"
          >
            JUMP ({formatKeyShort(kb.jump, 'Space')})
          </button>

          <button
            type="button"
            onClick={onFight}
            data-testid="hud-fight-btn"
            className="px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
          >
            <Swords className="w-3.5 h-3.5" />{' '}
            {isMiles ? 'VENOM PUNCH' : 'FIGHT'} ({formatKeyShort(kb.fight, 'KeyG')})
          </button>

          <SkillBtn
            label={
              isMiles
                ? `VENOM DASH (${formatKeyShort(kb.skill, 'KeyQ')})`
                : `DASH (${formatKeyShort(kb.skill, 'KeyQ')})`
            }
            cd={hud.dashCooldown}
            onClick={() => onSkill('dash')}
            icon={<Zap className="w-3 h-3" />}
            testId="hud-skill-dash-btn"
          />
          <SkillBtn
            label={isMiles ? 'CAMOUFLAGE (C)' : 'CLOAK (C)'}
            cd={hud.shadowCooldown}
            onClick={() => onSkill('shadow')}
            icon={<Sparkles className="w-3 h-3" />}
            testId="hud-skill-camouflage-btn"
          />
          <SkillBtn
            label={`SHIELD (${formatKeyShort(kb.interact, 'KeyE')})`}
            cd={hud.shieldCooldown}
            onClick={() => onSkill('shield')}
            icon={<Shield className="w-3 h-3" />}
          />
          <SkillBtn
            label={isMiles ? 'VENOM STRIKE (V)' : 'ULT (V)'}
            cd={hud.ultCooldown}
            onClick={() => onSkill('ult')}
            icon={<Sparkles className="w-3 h-3" />}
            testId="hud-skill-ult-btn"
          />
        </div>
      </div>

      {/* Cinematic Portal Teleportation Flash */}
      {hud.warpingPortal && !outcome && (
        <div
          data-testid="portal-warp-overlay"
          className="fixed inset-0 z-25 pointer-events-none flex items-center justify-center bg-sky-500/20"
        >
          <div className="px-8 py-4 rounded-2xl bg-[#080C17]/95 border-2 border-sky-400 text-center shadow-2xl">
            <div className="text-xs font-mono-num text-sky-300 tracking-widest uppercase">
              DIMENSIONAL VORTEX ENGAGED
            </div>
            <div className="mt-1 font-display text-2xl sm:text-3xl font-extrabold text-white">
              TELEPORTING...
            </div>
          </div>
        </div>
      )}

      {/* Pause Overlay */}
      {paused && !outcome && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/65 pointer-events-auto p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#0B101E] border border-slate-700 p-6 text-center shadow-2xl">
            <h2 className="font-display text-2xl font-extrabold text-white">GAME PAUSED</h2>
            <p className="mt-1 text-xs text-slate-400">
              Active Web: {webDef?.name} · Direction: {hud.activeDirection}
            </p>
            <div className="mt-5 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={onTogglePause}
                className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold cursor-pointer"
              >
                RESUME GAME
              </button>
              <button
                type="button"
                onClick={onReplay}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold cursor-pointer"
              >
                RESTART LEVEL
              </button>
              <button
                type="button"
                onClick={onExitToMenu}
                className="w-full py-2.5 rounded-xl bg-rose-600/20 border border-rose-500/40 hover:bg-rose-600/30 text-rose-200 font-semibold cursor-pointer"
              >
                MAIN MENU
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Outcome Modal (Level Completed / Match Win / Boss Win / Defeat) */}
      {outcome && (
        <div
          data-testid="game-outcome-modal"
          className="fixed inset-0 z-30 flex items-center justify-center bg-black/75 pointer-events-auto p-4"
        >
          <div className="w-full max-w-md rounded-2xl bg-[#0B101E] border border-amber-400/50 p-6 text-center shadow-2xl">
            {outcome.type === 'LEVEL_WIN' && (
              <>
                <div className="text-xs font-mono-num text-emerald-400 tracking-widest uppercase">
                  STAGE {outcome.level.id} / 10 CLEARED
                </div>
                <h2 className="mt-1 font-display text-3xl font-extrabold text-white">
                  LEVEL COMPLETED!
                </h2>
                <p className="mt-1 text-sm text-slate-300">
                  {outcome.level.name} · Orbs: {outcome.orbs} · Enemies K.O.: {outcome.enemies}
                </p>
                <div className="mt-4 grid grid-cols-3 gap-2 text-xs font-mono-num font-bold">
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700 text-amber-300">
                    +{outcome.coins} Coins
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700 text-cyan-300">
                    +{outcome.gems} Gems
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sky-300">
                    +{outcome.xp} XP
                  </div>
                </div>
                {outcome.firstClear && outcome.level.id < 10 && (
                  <div className="mt-3 p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-400/45 text-xs font-bold text-emerald-200">
                    LEVEL {outcome.unlockedNextLevel} UNLOCKED!
                  </div>
                )}
                {outcome.level.id === 10 && outcome.firstClear && (
                  <div className="mt-3 p-2.5 rounded-xl bg-amber-400/20 border border-amber-400 text-xs font-bold text-amber-200">
                    ALL 10 ADVENTURE LEVELS CONQUERED!
                  </div>
                )}
                {outcome.bossTriggered && (
                  <div className="mt-3 p-2.5 rounded-xl bg-rose-600/20 border border-rose-500/50 text-xs font-bold text-rose-200">
                    5-STAGE MILESTONE REACHED — BOSS ARENA READY!
                  </div>
                )}
                <div className="mt-5 flex flex-col gap-2">
                  {outcome.level.id < 10 && (
                    <button
                      type="button"
                      onClick={onContinueNextLevel}
                      data-testid="continue-next-level-btn"
                      className="w-full py-3 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-display font-extrabold cursor-pointer"
                    >
                      CONTINUE TO LEVEL {outcome.level.id + 1}
                    </button>
                  )}
                  {outcome.bossTriggered && (
                    <button
                      type="button"
                      onClick={onLaunchNextBoss}
                      className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-display font-bold cursor-pointer"
                    >
                      ENTER BOSS BATTLE NOW
                    </button>
                  )}
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={onReplay}
                      className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold cursor-pointer"
                    >
                      REPLAY LEVEL
                    </button>
                    <button
                      type="button"
                      onClick={onExitToMenu}
                      className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold cursor-pointer"
                    >
                      MAIN MENU
                    </button>
                  </div>
                </div>
              </>
            )}
            {outcome.type === 'MATCH_WIN' && (
              <>
                <div className="text-xs font-mono-num text-emerald-400 tracking-widest">
                  PATROL COMPLETE
                </div>
                <h2 className="mt-1 font-display text-3xl font-extrabold text-white">VICTORY!</h2>
                <p className="mt-2 text-sm text-slate-300">
                  Orbs Collected: {outcome.orbs} · Drones Defeated: {outcome.drones}
                </p>
                <div className="mt-4 flex items-center justify-center gap-4 text-sm font-mono-num font-bold">
                  <span className="text-amber-300">+{outcome.coins} Coins</span>
                  <span className="text-sky-300">+{outcome.xp} XP</span>
                </div>
                {outcome.bossTriggered && (
                  <div className="mt-4 p-3 rounded-xl bg-rose-600/20 border border-rose-500/50 text-xs font-bold text-rose-200">
                    5-MATCH CYCLE COMPLETE — BOSS ARENA UNLOCKED!
                  </div>
                )}
                <div className="mt-5 flex flex-col gap-2">
                  {outcome.bossTriggered && (
                    <button
                      type="button"
                      onClick={onLaunchNextBoss}
                      className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-display font-bold cursor-pointer"
                    >
                      ENTER BOSS BATTLE NOW
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={onReplay}
                    className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold cursor-pointer"
                  >
                    PLAY ANOTHER PATROL
                  </button>
                  <button
                    type="button"
                    onClick={onExitToMenu}
                    className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold cursor-pointer"
                  >
                    RETURN TO MENU
                  </button>
                </div>
              </>
            )}

            {outcome.type === 'BOSS_WIN' && (
              <>
                <div className="text-xs font-mono-num text-amber-400 tracking-widest">
                  BOSS CONQUERED
                </div>
                <h2 className="mt-1 font-display text-3xl font-extrabold text-white">
                  {outcome.boss.name} DEFEATED!
                </h2>
                <div className="mt-4 grid grid-cols-3 gap-2 text-xs font-mono-num">
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700 text-amber-300">
                    +{outcome.boss.coinReward} Coins
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700 text-cyan-300">
                    +{outcome.boss.gemReward} Gems
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700 text-sky-300">
                    +{outcome.boss.xpReward} XP
                  </div>
                </div>
                <p className="mt-3 text-xs text-emerald-300">
                  Unlocked Title: <strong>{outcome.boss.rewardTitle}</strong> + Bonus Supply Case!
                </p>
                <div className="mt-5 flex gap-2">
                  <button
                    type="button"
                    onClick={onReplay}
                    className="flex-1 py-2.5 rounded-xl bg-amber-400 text-slate-950 font-bold cursor-pointer"
                  >
                    REMATCH
                  </button>
                  <button
                    type="button"
                    onClick={onExitToMenu}
                    className="flex-1 py-2.5 rounded-xl bg-slate-800 text-white font-semibold cursor-pointer"
                  >
                    MAIN MENU
                  </button>
                </div>
              </>
            )}

            {outcome.type === 'DEFEAT' && (
              <>
                <div className="text-xs font-mono-num text-rose-400 tracking-widest uppercase">
                  GAME OVER
                </div>
                <h2 className="mt-1 font-display text-3xl font-extrabold text-white">
                  SUIT OVERLOADED
                </h2>
                <p className="mt-2 text-sm text-slate-300">
                  {outcome.reason || 'Upgrade Web Shield, Spider Speed, and Spider Strike to turn the tide.'}
                </p>
                <div className="mt-5 flex gap-2">
                  <button
                    type="button"
                    onClick={onReplay}
                    data-testid="restart-level-btn"
                    className="flex-1 py-2.5 rounded-xl bg-amber-400 text-slate-950 font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" /> RESTART LEVEL
                  </button>
                  <button
                    type="button"
                    onClick={onExitToMenu}
                    className="flex-1 py-2.5 rounded-xl bg-slate-800 text-white font-semibold cursor-pointer"
                  >
                    MAIN MENU
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const SkillBtn: React.FC<{
  label: string;
  cd: number;
  icon: React.ReactNode;
  onClick: () => void;
  testId?: string;
}> = ({ label, cd, icon, onClick, testId }) => (
  <button
    type="button"
    onClick={onClick}
    data-testid={testId}
    disabled={cd > 0.1}
    className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono-num font-bold flex items-center gap-1 cursor-pointer ${
      cd > 0.1
        ? 'bg-slate-900 text-slate-500 border border-slate-800'
        : 'bg-sky-500/20 text-sky-200 border border-sky-400/45 hover:bg-sky-500/35'
    }`}
  >
    {icon}
    <span>{cd > 0.1 ? `${Math.ceil(cd)}s` : label}</span>
  </button>
);
