import React, { useState } from 'react';
import { ArrowLeft, Award, Check, Coins, Gem, Target, Trophy } from 'lucide-react';
import {
  ACHIEVEMENT_CATALOG,
  MISSION_CATALOG,
  RANK_TIERS,
} from '../../data/world3dCatalog';
import { AchievementDef, MissionDef, PlayerSaveData } from '../../types/spider3d';
import { getRankForPoints } from '../../utils/spider3dStorage';

interface MissionsRankScreenProps {
  save: PlayerSaveData;
  onBack: () => void;
  onClaimMission: (m: MissionDef) => void;
  onClaimAchievement: (a: AchievementDef) => void;
}

export const MissionsRankScreen: React.FC<MissionsRankScreenProps> = ({
  save,
  onBack,
  onClaimMission,
  onClaimAchievement,
}) => {
  const [tab, setTab] = useState<'MISSIONS' | 'ACHIEVEMENTS' | 'RANKS'>('MISSIONS');
  const rank = getRankForPoints(save.rankPoints);

  const getMissionMetric = (m: MissionDef): number => {
    switch (m.metric) {
      case 'websShot':
        return save.stats.websShot;
      case 'matchesPlayed':
        return save.matchesCompleted;
      case 'bossesDefeated':
        return save.bossesDefeatedCount;
      case 'orbsCollected':
        return save.stats.orbsCollected;
      case 'distanceMeters':
        return Math.round(save.stats.distanceMeters);
      case 'skillsUsed':
        return save.stats.skillsUsed;
      case 'casesOpened':
        return save.stats.casesOpened;
      case 'secretVisited':
        return save.stats.secretVisited;
    }
  };

  const getAchMetric = (a: AchievementDef): number => {
    switch (a.metric) {
      case 'matchesPlayed':
        return save.matchesCompleted;
      case 'websShot':
        return save.stats.websShot;
      case 'bossesDefeated':
        return save.bossesDefeatedCount;
      case 'skinsOwned':
        return save.ownedSkinIds.length;
      case 'websOwned':
        return save.ownedWebIds.length;
      case 'level':
        return save.level;
      case 'casesOpened':
        return save.stats.casesOpened;
      case 'rankPoints':
        return save.rankPoints;
    }
  };

  const leaderboardEntries = [
    { name: 'OmegaSlinger', points: 5280, level: 68 },
    { name: 'AstralWeaver', points: 3940, level: 54 },
    { name: 'FrostArachnid', points: 2710, level: 41 },
    { name: save.playerName, points: save.rankPoints, level: save.level, isPlayer: true },
    { name: 'RooftopScout', points: 480, level: 12 },
  ].sort((a, b) => b.points - a.points);

  return (
    <div className="fixed inset-0 z-30 bg-[#070B14] overflow-y-auto p-4 sm:p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> MENU
            </button>
            <div>
              <h1 className="font-display text-2xl font-extrabold text-white">
                MISSIONS, ACHIEVEMENTS &amp; RANKINGS
              </h1>
              <p className="text-xs text-slate-400 font-mono-num">
                Rank: {rank.current.name} ({save.rankPoints} RP)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {(['MISSIONS', 'ACHIEVEMENTS', 'RANKS'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                className={`px-4 py-2 rounded-xl text-xs font-display font-bold cursor-pointer ${
                  tab === t
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-900 border border-slate-700 text-slate-300'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {tab === 'MISSIONS' && (
          <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
            {MISSION_CATALOG.map((m) => {
              const prog = getMissionMetric(m);
              const pct = Math.min(100, Math.round((prog / m.target) * 100));
              const done = prog >= m.target;
              const claimed = save.claimedMissionIds.includes(m.id);
              return (
                <div
                  key={m.id}
                  className="p-4 rounded-2xl bg-[#0B1120] border border-slate-800 flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs font-mono-num">
                      <span className="px-2 py-0.5 rounded bg-sky-500/15 text-sky-300 border border-sky-500/30">
                        {m.category.toUpperCase()}
                      </span>
                      <span className="text-slate-300">
                        {Math.min(prog, m.target)} / {m.target}
                      </span>
                    </div>
                    <h2 className="mt-2 font-display text-lg font-bold text-white flex items-center gap-2">
                      <Target className="w-4 h-4 text-teal-400" /> {m.title}
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5">{m.description}</p>
                    <div className="mt-3 w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div className="h-full bg-teal-400" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs font-mono-num pt-2 border-t border-slate-800">
                    <div className="flex items-center gap-3">
                      <span className="text-amber-300 flex items-center gap-1">
                        <Coins className="w-3.5 h-3.5" /> +{m.coinReward}
                      </span>
                      <span className="text-cyan-300 flex items-center gap-1">
                        <Gem className="w-3.5 h-3.5" /> +{m.gemReward}
                      </span>
                      <span className="text-purple-300">+{m.seasonXpReward} Pass XP</span>
                    </div>
                    {claimed ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> CLAIMED
                      </span>
                    ) : (
                      <button
                        type="button"
                        disabled={!done}
                        onClick={() => onClaimMission(m)}
                        className="px-3 py-1.5 rounded-lg bg-amber-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-bold cursor-pointer"
                      >
                        CLAIM
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === 'ACHIEVEMENTS' && (
          <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
            {ACHIEVEMENT_CATALOG.map((a) => {
              const prog = getAchMetric(a);
              const done = prog >= a.target;
              const claimed = save.claimedAchievementIds.includes(a.id);
              return (
                <div
                  key={a.id}
                  className="p-4 rounded-2xl bg-[#0B1120] border border-slate-800 flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs font-mono-num">
                      <span className="text-amber-300 font-bold">
                        TITLE REWARD: {a.rewardTitle}
                      </span>
                      <span className="text-slate-300">
                        {Math.min(prog, a.target)} / {a.target}
                      </span>
                    </div>
                    <h2 className="mt-2 font-display text-lg font-bold text-white flex items-center gap-2">
                      <Award className="w-4 h-4 text-amber-400" /> {a.title}
                    </h2>
                    <p className="text-xs text-slate-400">{a.description}</p>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs font-mono-num">
                    <span className="text-amber-300">
                      +{a.coinReward} Coins · +{a.gemReward} Gems
                    </span>
                    {claimed ? (
                      <span className="text-emerald-400 font-bold">UNLOCKED</span>
                    ) : (
                      <button
                        type="button"
                        disabled={!done}
                        onClick={() => onClaimAchievement(a)}
                        className="px-3 py-1.5 rounded-lg bg-amber-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-bold cursor-pointer"
                      >
                        CLAIM
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === 'RANKS' && (
          <div className="mt-5 grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800">
              <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 mb-4">
                <Trophy className="w-5 h-5 text-amber-400" /> 8-TIER COMPETITIVE LADDER
              </h2>
              <div className="space-y-2.5">
                {RANK_TIERS.map((r) => {
                  const active = rank.current.name === r.name;
                  return (
                    <div
                      key={r.name}
                      className={`px-3.5 py-2.5 rounded-xl border flex items-center justify-between text-xs font-mono-num ${
                        active
                          ? 'bg-amber-500/15 border-amber-400 text-white'
                          : 'bg-slate-900 border-slate-800 text-slate-300'
                      }`}
                    >
                      <span className="font-bold" style={{ color: r.color }}>
                        {r.name}
                      </span>
                      <span>{r.minPoints.toLocaleString()}+ RP</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-[#0B1120] border border-slate-800">
              <h2 className="font-display text-lg font-bold text-white mb-4">
                CITY LEADERBOARD STANDINGS
              </h2>
              <div className="space-y-2.5">
                {leaderboardEntries.map((entry, idx) => (
                  <div
                    key={entry.name}
                    className={`px-4 py-3 rounded-xl border flex items-center justify-between text-xs font-mono-num ${
                      entry.isPlayer
                        ? 'bg-sky-500/15 border-sky-400 text-white font-bold'
                        : 'bg-slate-900 border-slate-800 text-slate-300'
                    }`}
                  >
                    <span>
                      #{idx + 1} · {entry.name} (LV.{entry.level})
                    </span>
                    <span className="text-amber-300">{entry.points.toLocaleString()} RP</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
